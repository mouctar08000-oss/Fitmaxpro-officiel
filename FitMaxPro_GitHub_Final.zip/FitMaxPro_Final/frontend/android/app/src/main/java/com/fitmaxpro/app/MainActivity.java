package com.fitmaxpro.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
