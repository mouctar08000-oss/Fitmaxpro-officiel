# FitMaxPro - Application de Fitness Complète

Application de fitness professionnelle avec live streaming, appels vidéo 1-to-1, programmes d'entraînement, et gestion admin complète.

## 🚀 Fonctionnalités

### 🎥 Live Streaming & Appels Vidéo
- Streaming en direct avec LiveKit WebRTC
- Appels vidéo privés coach/client
- Chat en temps réel pendant les lives
- Notifications push pour les appels entrants

### 💪 Gestion Admin des Séances
- **NOUVEAU**: Créer, modifier, supprimer des séances
- **NOUVEAU**: Upload de vidéos et images
- Ajouter/modifier des exercices avec médias
- Organiser par niveau et type de programme

### 🏋️ Entraînements
- 138+ séances prédéfinies
- Plans prise de masse / perte de poids
- Programmes par groupe musculaire
- Lecteur vidéo d'exercices

### 🏃 Course à Pied & Gamification
- Suivi GPS des courses
- Classements et défis hebdomadaires
- Système de points et récompenses
- Hall of Fame

### 💳 Paiements
- Abonnements Stripe (web)
- Achats in-app RevenueCat (mobile)

## 📦 Installation

### Prérequis
- Node.js 18+
- Python 3.11+
- MongoDB 7.0+
- Compte LiveKit Cloud (gratuit)

### Backend

```bash
cd backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
# Éditez .env avec vos clés API
uvicorn server:app --host 0.0.0.0 --port 8001 --reload
```

### Frontend

```bash
cd frontend
yarn install
cp .env.example .env
# Éditez .env avec vos clés
yarn start
```

## 🐳 Docker

```bash
docker-compose up -d
```

L'application sera disponible sur:
- Frontend: http://localhost:3000
- Backend API: http://localhost:8001/docs

## 🔑 Comptes de Test

| Type | Email | Mot de passe |
|------|-------|--------------|
| Admin | admin@fitmaxpro.com | admin123 |
| User | testuser@test.com | password123 |

## 📁 Architecture

```
FitMaxPro/
├── backend/
│   ├── server.py           # Point d'entrée FastAPI
│   ├── routes/             # 18 modules de routes API
│   │   ├── auth.py         # Authentification JWT
│   │   ├── workouts.py     # Gestion séances + Upload
│   │   ├── lives.py        # Live streaming
│   │   ├── livekit.py      # WebRTC
│   │   └── ...
│   ├── uploads/            # Fichiers uploadés
│   │   ├── videos/
│   │   └── images/
│   └── utils/
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── admin/      # Composants admin
│   │   │   │   └── AdminWorkouts.js  # Gestion séances
│   │   │   └── ...
│   │   ├── pages/
│   │   └── hooks/
│   │       └── usePushNotifications.js
│   └── public/
└── docker-compose.yml
```

## 🔧 Configuration des Services

### LiveKit (Streaming Vidéo)
1. Créez un compte sur https://cloud.livekit.io
2. Créez un projet et copiez les clés
3. Ajoutez dans backend/.env

### Stripe (Paiements)
1. Dashboard: https://dashboard.stripe.com
2. Récupérez les clés API
3. Configurez le webhook vers /api/payments/webhook

### Push Notifications
Générez les clés VAPID:
```bash
npx web-push generate-vapid-keys
```

## 📝 Licence

Propriétaire - Tous droits réservés © 2025 FitMaxPro
