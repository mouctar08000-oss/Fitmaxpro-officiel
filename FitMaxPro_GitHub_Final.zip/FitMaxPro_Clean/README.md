# FitMaxPro - Application de Fitness Complète

Application de fitness professionnelle avec live streaming, appels vidéo 1-to-1, programmes d'entraînement, course à pied, gamification et plus encore.

## Fonctionnalités

### 🎥 Live Streaming & Appels
- Streaming en direct avec LiveKit WebRTC
- Appels vidéo 1-to-1 coach/client
- Chat en temps réel pendant les lives
- Notifications push pour les appels entrants

### 💪 Entraînements
- 72+ séances d'entraînement prédéfinies
- Plans prise de masse et perte de poids
- Programmes spécifiques par groupe musculaire
- Suivi des progrès

### 🏃 Course à Pied
- Suivi GPS des courses
- Classement entre utilisateurs
- Défis hebdomadaires

### 🎮 Gamification
- Système de points et récompenses
- Hall of Fame
- Badges de progression

### 💳 Paiements
- Abonnements Stripe (web)
- Achats in-app RevenueCat (mobile)

## Installation

### Prérequis
- Node.js 18+
- Python 3.11+
- MongoDB
- Compte LiveKit Cloud (gratuit)
- Compte Stripe (pour les paiements)

### Backend

```bash
cd backend
python -m venv venv
source venv/bin/activate  # Sur Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
# Éditer .env avec vos clés API
uvicorn server:app --host 0.0.0.0 --port 8001 --reload
```

### Frontend

```bash
cd frontend
yarn install
cp .env.example .env
# Éditer .env avec vos clés API
yarn start
```

## Configuration

### LiveKit (Streaming Vidéo)

1. Créez un compte sur https://cloud.livekit.io
2. Créez un nouveau projet
3. Copiez l'URL, API Key et API Secret dans `backend/.env`

### Stripe (Paiements)

1. Créez un compte sur https://stripe.com
2. Récupérez vos clés API depuis le dashboard
3. Configurez les webhooks vers `/api/payments/webhook`

## Architecture

```
FitMaxPro/
├── backend/
│   ├── server.py           # Point d'entrée FastAPI
│   ├── routes/             # 18 modules de routes
│   │   ├── auth.py         # Authentification
│   │   ├── lives.py        # Live streaming
│   │   ├── livekit.py      # WebRTC
│   │   ├── payments.py     # Stripe
│   │   └── ...
│   ├── utils/              # Configuration
│   └── models/             # Modèles Pydantic
├── frontend/
│   ├── src/
│   │   ├── components/     # Composants React
│   │   ├── pages/          # Pages
│   │   └── hooks/          # Hooks personnalisés
│   └── public/
└── docker-compose.yml      # Déploiement Docker
```

## Déploiement avec Docker

```bash
docker-compose up -d
```

L'application sera accessible sur:
- Frontend: http://localhost:3000
- Backend API: http://localhost:8001/docs

## Comptes de Test

- **Admin:** admin@fitmaxpro.com / admin123
- **Utilisateur:** testuser@test.com / password123

## Technologies

- **Backend:** FastAPI, Motor (MongoDB async), PyJWT, LiveKit SDK
- **Frontend:** React 18, Tailwind CSS, ShadcnUI, LiveKit React
- **Database:** MongoDB
- **Vidéo:** LiveKit Cloud (WebRTC)
- **Paiements:** Stripe, RevenueCat

## Licence

Propriétaire - Tous droits réservés
