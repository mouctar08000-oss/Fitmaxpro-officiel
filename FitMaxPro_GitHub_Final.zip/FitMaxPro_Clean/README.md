# FitMaxPro - Application de Fitness Complète

## Fonctionnalités

### Live Streaming & Appels Vidéo
- Streaming en direct avec LiveKit WebRTC
- Appels vidéo 1-to-1 coach/client
- Chat en temps réel

### Gestion Admin des Séances
- Créer, modifier, supprimer des séances
- Ajouter des exercices avec vidéos/images
- Organiser par niveau et programme

### Entraînements
- 72+ programmes prédéfinis
- Plans prise de masse / perte de poids
- Programmes par groupe musculaire

### Course à Pied & Gamification
- Suivi GPS
- Classements et défis
- Système de points et récompenses

## Installation

### Backend
```bash
cd backend
pip install -r requirements.txt
cp .env.example .env
# Éditer .env avec vos clés
uvicorn server:app --port 8001
```

### Frontend
```bash
cd frontend
yarn install
cp .env.example .env
yarn start
```

## Comptes de Test
- Admin: admin@fitmaxpro.com / admin123
- User: testuser@test.com / password123
