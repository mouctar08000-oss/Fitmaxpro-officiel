# FitMaxPro - Application Fitness Complète

![FitMaxPro](https://img.shields.io/badge/Version-3.1.0-blue)
![React](https://img.shields.io/badge/React-18-61DAFB)
![FastAPI](https://img.shields.io/badge/FastAPI-0.100+-green)
![MongoDB](https://img.shields.io/badge/MongoDB-6.0-47A248)

Application de fitness complète avec live streaming, entraînements personnalisés, suivi GPS, gamification, **mode hors-ligne**, **synchronisation multi-appareils** et **téléchargement automatique des favoris**.

## 🚀 Fonctionnalités

### Core
- **Authentification** - Login/Signup sécurisé avec JWT
- **Dashboard** - Vue d'ensemble personnalisée
- **Navigation responsive** - Mobile et desktop

### Live Streaming
- Streaming WebRTC avec LiveKit
- Appels vidéo 1-to-1 coach/client
- Chat en temps réel
- Lives programmés

### Entraînements
- 72+ séances prédéfinies
- Plans prise de masse / perte de poids
- Lecteur vidéo d'exercices
- **CRUD Admin** avec upload vidéo/image
- **Compression automatique** des vidéos (FFmpeg, H.264, 720p)
- **Routines échauffement & étirements**

### Mode Hors-ligne
- Téléchargement des séances pour accès hors-ligne
- Cache IndexedDB pour les données
- Cache Service Worker pour les images
- Indicateur de statut en ligne/hors-ligne
- Synchronisation automatique au retour en ligne

### Favoris & Téléchargement Automatique (NOUVEAU)
- Bouton coeur pour ajouter aux favoris
- Téléchargement automatique des favoris
- Gestion des paramètres auto-download
- Liste des favoris avec statut de téléchargement

### Synchronisation Multi-Appareils
- WebSocket pour sync en temps réel
- "Last write wins" pour gestion des conflits
- Suivi du nombre d'appareils connectés
- Synchronisation de la progression

### Course à Pied
- Suivi GPS
- Classements
- Défis hebdomadaires

### Gamification
- Points et récompenses
- Hall of Fame
- Badges

### Paiements
- Stripe (abonnements web)
- RevenueCat (achats in-app mobile)
- **Logique abonnement annuel** (blocage annulation avant 12 mois)

### Admin Panel
- Dashboard analytique
- Gestion abonnés
- Statistiques lives
- Gestion messages/avis
- Upload de fichiers

## 📦 Installation

### Prérequis
- Node.js 18+
- Python 3.10+
- MongoDB 6.0+
- FFmpeg (pour la compression vidéo)

### Backend

```bash
cd backend
pip install -r requirements.txt
cp .env.example .env
# Remplir les variables dans .env
python server.py
```

### Frontend

```bash
cd frontend
npm install
cp .env.example .env
# Remplir les variables dans .env
npm start
```

## 🔧 Configuration

### Variables d'environnement requises

**Backend (.env):**
- `MONGO_URL` - URL MongoDB
- `STRIPE_API_KEY` - Clé secrète Stripe
- `LIVEKIT_URL`, `LIVEKIT_API_KEY`, `LIVEKIT_API_SECRET` - LiveKit
- `RESEND_API_KEY` - Service email
- `REVENUECAT_API_KEY` - Achats in-app
- `VAPID_*` - Notifications push

**Frontend (.env):**
- `REACT_APP_BACKEND_URL` - URL de l'API
- `REACT_APP_STRIPE_PUBLIC_KEY` - Clé publique Stripe

## 🏗️ Architecture

```
/
├── backend/
│   ├── routes/           # 20 modules de routes
│   │   ├── auth.py
│   │   ├── workouts.py   # + upload + compression
│   │   ├── routines.py   # Échauffement & étirements
│   │   ├── sync.py       # WebSocket sync
│   │   └── ...
│   ├── models/           # Schémas Pydantic
│   ├── utils/            # Configuration
│   ├── tests/            # Tests Pytest
│   └── uploads/          # Fichiers uploadés
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── OfflineManager.js  # Gestion hors-ligne + favoris
│   │   │   └── ...
│   │   ├── hooks/
│   │   │   ├── useOffline.js      # Hook hors-ligne + favoris
│   │   │   ├── useSync.js         # Hook WebSocket
│   │   │   └── ...
│   │   ├── services/
│   │   │   └── offlineStorage.js  # IndexedDB + favoris
│   │   └── pages/
│   └── public/
│       └── sw.js         # Service Worker + cache
├── docker-compose.yml
└── README.md
```

## 🧪 Tests

```bash
# Backend
cd backend
pytest

# Frontend
cd frontend
npm test
```

## 📱 Mobile

L'application utilise Capacitor pour les builds mobiles.

```bash
cd frontend
npx cap sync android
npx cap open android
```

## 📝 Comptes de test

| Type | Email | Mot de passe |
|------|-------|--------------|
| Admin | admin@fitmaxpro.com | admin123 |
| User | testuser@test.com | password123 |

## 📄 Licence

Propriétaire - Tous droits réservés

## 👤 Contact

Pour toute question, contactez l'équipe FitMaxPro.
