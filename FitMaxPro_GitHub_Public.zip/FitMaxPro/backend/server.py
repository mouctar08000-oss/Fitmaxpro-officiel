from fastapi import FastAPI, APIRouter, HTTPException, Request, Response, Depends, Header, UploadFile, File
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
import json
import asyncio
import aiofiles
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict, EmailStr
from typing import List, Optional, Dict
import uuid
from datetime import datetime, timezone, timedelta
import httpx
from passlib.context import CryptContext
from emergentintegrations.payments.stripe.checkout import StripeCheckout, CheckoutSessionResponse, CheckoutStatusResponse, CheckoutSessionRequest
import resend

# LiveKit WebRTC Integration
try:
    from livekit import api as livekit_api
    LIVEKIT_AVAILABLE = True
except ImportError:
    LIVEKIT_AVAILABLE = False
    print("Warning: livekit not available")

# Web Push Notifications
try:
    from pywebpush import webpush, WebPushException
    WEBPUSH_AVAILABLE = True
except ImportError:
    WEBPUSH_AVAILABLE = False
    print("Warning: pywebpush not available")

# VAPID Keys for Push Notifications (replace with your own in production)
VAPID_PRIVATE_KEY = "Bmw7bEZI0X6QZkQQJ1Y9TWFU7h_sA_Tz5t8mKlkMfms"
VAPID_PUBLIC_KEY = "BEl62iUYgUivxIkv69yViEuiBIa-Ib9-SkvMeAtA3LFgDzkrxZJjSgSnfckjBJuBkr3qBUYIHBQFLXYp5Nksh8U"
VAPID_CLAIMS = {"sub": "mailto:admin@fitmaxpro.com"}

# Password hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Resend Email setup
resend.api_key = os.environ.get('RESEND_API_KEY', '')
SENDER_EMAIL = os.environ.get('SENDER_EMAIL', 'onboarding@resend.dev')
APP_URL = os.environ.get('APP_URL', 'https://fitmax-gains.preview.emergentagent.com')

app = FastAPI()
api_router = APIRouter(prefix="/api")

stripe_api_key = os.environ.get('STRIPE_API_KEY')

# Models
class User(BaseModel):
    model_config = ConfigDict(extra="ignore")
    user_id: str
    email: str
    name: str
    picture: Optional[str] = None
    subscription_tier: str = "none"
    subscription_status: str = "inactive"
    role: Optional[str] = None
    subscription: Optional[dict] = None
    created_at: datetime

class UserSession(BaseModel):
    model_config = ConfigDict(extra="ignore")
    user_id: str
    session_token: str
    expires_at: datetime
    created_at: datetime

class RegisterRequest(BaseModel):
    email: EmailStr
    password: str
    name: str

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class SessionRequest(BaseModel):
    session_id: str

class SessionResponse(BaseModel):
    user: User
    session_token: str

class Workout(BaseModel):
    model_config = ConfigDict(extra="ignore")
    workout_id: str
    title: str
    description: str
    level: str
    program_type: str
    exercises: List[Dict]
    duration: int
    language: str
    image_url: Optional[str] = None

class Supplement(BaseModel):
    model_config = ConfigDict(extra="ignore")
    supplement_id: str
    title: str
    description: str
    program_type: str
    nutrients: List[Dict]
    meals: Optional[List[Dict]] = None
    language: str
    image_url: Optional[str] = None
    video_url: Optional[str] = None

# Model for recipe
class Recipe(BaseModel):
    ingredients: List[str] = []
    steps: List[str] = []
    prep_time: Optional[str] = None
    cook_time: Optional[str] = None
    servings: Optional[int] = None

class MealRecipeUpdate(BaseModel):
    recipe: Recipe

class CheckoutRequest(BaseModel):
    tier: str
    billing_cycle: str
    origin_url: str

# Model for tracking workout sessions
class WorkoutSession(BaseModel):
    model_config = ConfigDict(extra="ignore")
    session_id: str
    user_id: str
    workout_id: str
    workout_title: str
    started_at: datetime
    ended_at: Optional[datetime] = None
    duration_seconds: int = 0
    completed: bool = False

# Model for admin subscription management
class SubscriptionUpdate(BaseModel):
    user_id: str
    subscription_tier: str
    subscription_status: str

# Auth Helper
async def get_current_user(request: Request, authorization: Optional[str] = Header(None)) -> User:
    session_token = request.cookies.get("session_token")
    
    if not session_token and authorization:
        if authorization.startswith("Bearer "):
            session_token = authorization.split(" ")[1]
    
    if not session_token:
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    session_doc = await db.user_sessions.find_one({"session_token": session_token}, {"_id": 0})
    if not session_doc:
        raise HTTPException(status_code=401, detail="Invalid session")
    
    expires_at = session_doc["expires_at"]
    if isinstance(expires_at, str):
        expires_at = datetime.fromisoformat(expires_at)
    if expires_at.tzinfo is None:
        expires_at = expires_at.replace(tzinfo=timezone.utc)
    
    if expires_at < datetime.now(timezone.utc):
        await db.user_sessions.delete_one({"session_token": session_token})
        raise HTTPException(status_code=401, detail="Session expired")
    
    # Auto-renew session on activity (extend by another year)
    # This keeps the user logged in as long as they're active
    new_expires_at = (datetime.now(timezone.utc) + timedelta(days=365)).isoformat()
    await db.user_sessions.update_one(
        {"session_token": session_token},
        {"$set": {
            "expires_at": new_expires_at,
            "last_activity": datetime.now(timezone.utc).isoformat()
        }}
    )
    
    user_doc = await db.users.find_one({"user_id": session_doc["user_id"]}, {"_id": 0})
    if not user_doc:
        raise HTTPException(status_code=404, detail="User not found")
    
    if isinstance(user_doc["created_at"], str):
        user_doc["created_at"] = datetime.fromisoformat(user_doc["created_at"])
    
    return User(**user_doc)

# Auth Endpoints
@api_router.post("/auth/session", response_model=SessionResponse)
async def create_session(request: SessionRequest, response: Response):
    try:
        async with httpx.AsyncClient() as client:
            resp = await client.get(
                "https://demobackend.emergentagent.com/auth/v1/env/oauth/session-data",
                headers={"X-Session-ID": request.session_id}
            )
            resp.raise_for_status()
            data = resp.json()
        
        existing_user = await db.users.find_one({"email": data["email"]}, {"_id": 0})
        
        if existing_user:
            user_id = existing_user["user_id"]
            await db.users.update_one(
                {"user_id": user_id},
                {"$set": {
                    "name": data["name"],
                    "picture": data.get("picture")
                }}
            )
        else:
            user_id = f"user_{uuid.uuid4().hex[:12]}"
            user_doc = {
                "user_id": user_id,
                "email": data["email"],
                "name": data["name"],
                "picture": data.get("picture"),
                "subscription_tier": "none",
                "subscription_status": "inactive",
                "created_at": datetime.now(timezone.utc).isoformat()
            }
            await db.users.insert_one(user_doc)
        
        session_token = data["session_token"]
        session_doc = {
            "user_id": user_id,
            "session_token": session_token,
            "expires_at": (datetime.now(timezone.utc) + timedelta(days=365)).isoformat(),  # 1 year - permanent until logout
            "created_at": datetime.now(timezone.utc).isoformat(),
            "last_activity": datetime.now(timezone.utc).isoformat()
        }
        await db.user_sessions.insert_one(session_doc)
        
        response.set_cookie(
            key="session_token",
            value=session_token,
            httponly=True,
            secure=True,
            samesite="none",
            path="/",
            max_age=365*24*60*60  # 1 year
        )
        
        user = await db.users.find_one({"user_id": user_id}, {"_id": 0})
        if isinstance(user["created_at"], str):
            user["created_at"] = datetime.fromisoformat(user["created_at"])
        
        return SessionResponse(user=User(**user), session_token=session_token)
    except Exception as e:
        logging.error(f"Session creation error: {e}")
        raise HTTPException(status_code=400, detail=str(e))

@api_router.get("/auth/me", response_model=User)
async def get_me(current_user: User = Depends(get_current_user)):
    return current_user

@api_router.post("/auth/logout")
async def logout(response: Response, current_user: User = Depends(get_current_user)):
    session_token = None
    await db.user_sessions.delete_many({"user_id": current_user.user_id})
    response.delete_cookie(key="session_token", path="/")
    return {"message": "Logged out successfully"}

# Email/Password Auth Endpoints
@api_router.post("/auth/register", response_model=SessionResponse)
async def register(request: RegisterRequest, response: Response):
    try:
        # Check if user already exists
        existing_user = await db.users.find_one({"email": request.email}, {"_id": 0})
        if existing_user:
            raise HTTPException(status_code=400, detail="Email already registered")
        
        # Hash password
        hashed_password = pwd_context.hash(request.password)
        
        # Create user
        user_id = f"user_{uuid.uuid4().hex[:12]}"
        user_doc = {
            "user_id": user_id,
            "email": request.email,
            "name": request.name,
            "password": hashed_password,
            "picture": None,
            "subscription_tier": "none",
            "subscription_status": "inactive",
            "created_at": datetime.now(timezone.utc).isoformat()
        }
        await db.users.insert_one(user_doc)
        
        # Create session
        session_token = f"session_{uuid.uuid4().hex}"
        session_doc = {
            "user_id": user_id,
            "session_token": session_token,
            "expires_at": (datetime.now(timezone.utc) + timedelta(days=365)).isoformat(),  # 1 year - permanent until logout
            "created_at": datetime.now(timezone.utc).isoformat()
        }
        await db.user_sessions.insert_one(session_doc)
        
        # Set cookie
        response.set_cookie(
            key="session_token",
            value=session_token,
            httponly=True,
            secure=True,
            samesite="none",
            path="/",
            max_age=365*24*60*60  # 1 year
        )
        
        # Return user (without password)
        user = await db.users.find_one({"user_id": user_id}, {"_id": 0, "password": 0})
        if isinstance(user["created_at"], str):
            user["created_at"] = datetime.fromisoformat(user["created_at"])
        
        return SessionResponse(user=User(**user), session_token=session_token)
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Registration error: {e}")
        raise HTTPException(status_code=400, detail=str(e))

@api_router.post("/auth/login", response_model=SessionResponse)
async def login(request: LoginRequest, response: Response):
    try:
        # Find user
        user_doc = await db.users.find_one({"email": request.email}, {"_id": 0})
        if not user_doc:
            raise HTTPException(status_code=401, detail="Invalid email or password")
        
        # Check if user has password (OAuth users don't have password)
        if "password" not in user_doc:
            raise HTTPException(status_code=401, detail="Please login with Google")
        
        # Verify password
        if not pwd_context.verify(request.password, user_doc["password"]):
            raise HTTPException(status_code=401, detail="Invalid email or password")
        
        user_id = user_doc["user_id"]
        
        # Create session
        session_token = f"session_{uuid.uuid4().hex}"
        session_doc = {
            "user_id": user_id,
            "session_token": session_token,
            "expires_at": (datetime.now(timezone.utc) + timedelta(days=365)).isoformat(),  # 1 year - permanent until logout
            "created_at": datetime.now(timezone.utc).isoformat()
        }
        await db.user_sessions.insert_one(session_doc)
        
        # Set cookie
        response.set_cookie(
            key="session_token",
            value=session_token,
            httponly=True,
            secure=True,
            samesite="none",
            path="/",
            max_age=365*24*60*60  # 1 year
        )
        
        # Return user (without password)
        user = await db.users.find_one({"user_id": user_id}, {"_id": 0, "password": 0})
        if isinstance(user["created_at"], str):
            user["created_at"] = datetime.fromisoformat(user["created_at"])
        
        return SessionResponse(user=User(**user), session_token=session_token)
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Login error: {e}")
        raise HTTPException(status_code=400, detail=str(e))

class ForgotPasswordRequest(BaseModel):
    email: str

@api_router.post("/auth/forgot-password")
async def forgot_password(request: ForgotPasswordRequest):
    """Send password reset email"""
    try:
        user = await db.users.find_one({"email": request.email})
        
        if user:
            # Generate reset token
            reset_token = f"reset_{uuid.uuid4().hex}"
            expires_at = (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
            
            # Store reset token
            await db.password_resets.update_one(
                {"user_id": user["user_id"]},
                {"$set": {
                    "user_id": user["user_id"],
                    "token": reset_token,
                    "expires_at": expires_at,
                    "created_at": datetime.now(timezone.utc).isoformat()
                }},
                upsert=True
            )
            
            # Send email with reset link (using Resend if configured)
            app_url = os.environ.get("APP_URL", "https://fitmax-gains.preview.emergentagent.com")
            reset_link = f"{app_url}/reset-password?token={reset_token}"
            
            # Try to send email
            try:
                resend_key = os.environ.get("RESEND_API_KEY")
                sender_email = os.environ.get("SENDER_EMAIL", "onboarding@resend.dev")
                
                if resend_key:
                    import resend
                    resend.api_key = resend_key
                    
                    resend.Emails.send({
                        "from": f"FitMaxPro <{sender_email}>",
                        "to": request.email,
                        "subject": "Réinitialisation de votre mot de passe FitMaxPro",
                        "html": f"""
                        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                            <h2 style="color: #EF4444;">FitMaxPro</h2>
                            <p>Bonjour {user.get('name', '')},</p>
                            <p>Vous avez demandé la réinitialisation de votre mot de passe.</p>
                            <p>Cliquez sur le lien ci-dessous pour créer un nouveau mot de passe :</p>
                            <p><a href="{reset_link}" style="background-color: #EF4444; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; display: inline-block;">Réinitialiser mon mot de passe</a></p>
                            <p style="color: #666; font-size: 12px;">Ce lien expire dans 1 heure.</p>
                            <p style="color: #666; font-size: 12px;">Si vous n'avez pas demandé cette réinitialisation, ignorez cet email.</p>
                        </div>
                        """
                    })
            except Exception as email_error:
                logging.error(f"Email send error: {email_error}")
        
        # Always return success (security - don't reveal if email exists)
        return {"message": "If an account exists with this email, a reset link has been sent."}
    except Exception as e:
        logging.error(f"Forgot password error: {e}")
        return {"message": "If an account exists with this email, a reset link has been sent."}

# Payment Endpoints
import stripe

# Configuration des prix Stripe (à créer dans le dashboard Stripe ou dynamiquement)
PACKAGES = {
    "standard_monthly": {"amount": 699, "tier": "standard", "billing": "monthly", "interval": "month"},
    "standard_annual": {"amount": 6999, "tier": "standard", "billing": "annual", "interval": "year"},
    "vip_monthly": {"amount": 999, "tier": "vip", "billing": "monthly", "interval": "month"},
    "vip_annual": {"amount": 9999, "tier": "vip", "billing": "annual", "interval": "year"},
    "supplements_monthly": {"amount": 499, "tier": "supplements", "billing": "monthly", "interval": "month"}
}

# Durée de l'essai gratuit en jours
FREE_TRIAL_DAYS = 7

@api_router.post("/payments/checkout")
async def create_checkout(checkout_req: CheckoutRequest, current_user: User = Depends(get_current_user)):
    # Handle supplements as a special case
    if checkout_req.tier == "supplements":
        package_key = "supplements_monthly"
    else:
        package_key = f"{checkout_req.tier}_{checkout_req.billing_cycle}"
    
    if package_key not in PACKAGES:
        raise HTTPException(status_code=400, detail="Invalid package")
    
    package = PACKAGES[package_key]
    
    success_url = f"{checkout_req.origin_url}/success?session_id={{CHECKOUT_SESSION_ID}}"
    cancel_url = f"{checkout_req.origin_url}/pricing"
    
    try:
        # Configure Stripe
        stripe.api_key = stripe_api_key
        
        # Create a Stripe Checkout Session with subscription mode and free trial
        session = stripe.checkout.Session.create(
            payment_method_types=['card'],
            mode='subscription',
            line_items=[{
                'price_data': {
                    'currency': 'eur',
                    'product_data': {
                        'name': f"FitMaxPro - {checkout_req.tier.upper()} ({checkout_req.billing_cycle})",
                        'description': f"Abonnement {checkout_req.tier} avec 7 jours d'essai gratuit"
                    },
                    'unit_amount': package["amount"],  # Amount in cents
                    'recurring': {
                        'interval': package["interval"]
                    }
                },
                'quantity': 1,
            }],
            subscription_data={
                'trial_period_days': FREE_TRIAL_DAYS,
                'metadata': {
                    'user_id': current_user.user_id,
                    'tier': package["tier"],
                    'billing_cycle': package["billing"]
                }
            },
            success_url=success_url,
            cancel_url=cancel_url,
            metadata={
                'user_id': current_user.user_id,
                'tier': package["tier"],
                'billing_cycle': package["billing"]
            },
            customer_email=current_user.email
        )
        
        payment_doc = {
            "session_id": session.id,
            "user_id": current_user.user_id,
            "amount": package["amount"] / 100,  # Convert to euros
            "currency": "eur",
            "tier": package["tier"],
            "billing_cycle": package["billing"],
            "payment_status": "pending",
            "has_trial": True,
            "trial_days": FREE_TRIAL_DAYS,
            "created_at": datetime.now(timezone.utc).isoformat()
        }
        await db.payment_transactions.insert_one(payment_doc)
        
        return {"url": session.url, "session_id": session.id}
    except Exception as e:
        logging.error(f"Checkout error: {e}")
        raise HTTPException(status_code=400, detail=str(e))

@api_router.get("/payments/status/{session_id}")
async def get_payment_status(session_id: str, current_user: User = Depends(get_current_user)):
    try:
        stripe.api_key = stripe_api_key
        
        # Retrieve the checkout session from Stripe
        session = stripe.checkout.Session.retrieve(session_id)
        
        payment_doc = await db.payment_transactions.find_one({"session_id": session_id}, {"_id": 0})
        if not payment_doc:
            raise HTTPException(status_code=404, detail="Payment not found")
        
        # Check if session is complete (subscription started with trial)
        if session.status == "complete" and payment_doc["payment_status"] != "paid":
            await db.payment_transactions.update_one(
                {"session_id": session_id},
                {"$set": {"payment_status": "paid", "subscription_id": session.subscription}}
            )
            
            tier = payment_doc["tier"]
            billing_cycle = payment_doc["billing_cycle"]
            
            # Calculate trial end date
            trial_end = datetime.now(timezone.utc) + timedelta(days=FREE_TRIAL_DAYS)
            
            await db.users.update_one(
                {"user_id": current_user.user_id},
                {"$set": {
                    "subscription_tier": tier,
                    "subscription_status": "trialing",
                    "trial_ends_at": trial_end.isoformat()
                }}
            )
            
            subscription_doc = {
                "user_id": current_user.user_id,
                "tier": tier,
                "billing_cycle": billing_cycle,
                "status": "trialing",
                "trial_ends_at": trial_end.isoformat(),
                "started_at": datetime.now(timezone.utc).isoformat(),
                "stripe_subscription_id": session.subscription,
                "auto_renew": True,
                "created_at": datetime.now(timezone.utc).isoformat()
            }
            await db.user_subscriptions.insert_one(subscription_doc)
        
        return {
            "status": session.status,
            "payment_status": session.payment_status or "trialing",
            "amount_total": session.amount_total,
            "currency": session.currency,
            "trial_days": FREE_TRIAL_DAYS
        }
    except Exception as e:
        logging.error(f"Payment status error: {e}")
        raise HTTPException(status_code=400, detail=str(e))

@api_router.post("/webhook/stripe")
async def stripe_webhook(request: Request):
    body = await request.body()
    signature = request.headers.get("Stripe-Signature")
    
    try:
        stripe.api_key = stripe_api_key
        webhook_secret = os.environ.get('STRIPE_WEBHOOK_SECRET', '')
        
        # Verify webhook signature if secret is configured
        if webhook_secret:
            event = stripe.Webhook.construct_event(body, signature, webhook_secret)
        else:
            event = stripe.Event.construct_from(
                json.loads(body.decode('utf-8')), stripe.api_key
            )
        
        # Handle different event types
        if event['type'] == 'customer.subscription.trial_will_end':
            # Trial ending soon - could send notification email
            subscription = event['data']['object']
            logging.info(f"Trial ending soon for subscription: {subscription['id']}")
            
        elif event['type'] == 'customer.subscription.updated':
            subscription = event['data']['object']
            user_id = subscription.get('metadata', {}).get('user_id')
            
            if user_id:
                new_status = "active" if subscription['status'] == 'active' else subscription['status']
                await db.users.update_one(
                    {"user_id": user_id},
                    {"$set": {"subscription_status": new_status}}
                )
                
        elif event['type'] == 'customer.subscription.deleted':
            subscription = event['data']['object']
            user_id = subscription.get('metadata', {}).get('user_id')
            
            if user_id:
                await db.users.update_one(
                    {"user_id": user_id},
                    {"$set": {
                        "subscription_tier": "free",
                        "subscription_status": "cancelled"
                    }}
                )
        
        elif event['type'] == 'invoice.payment_succeeded':
            # Payment successful after trial
            invoice = event['data']['object']
            subscription_id = invoice.get('subscription')
            
            if subscription_id:
                await db.user_subscriptions.update_one(
                    {"stripe_subscription_id": subscription_id},
                    {"$set": {"status": "active"}}
                )
        
        elif event['type'] == 'invoice.payment_failed':
            # Payment failed
            invoice = event['data']['object']
            subscription_id = invoice.get('subscription')
            
            if subscription_id:
                await db.user_subscriptions.update_one(
                    {"stripe_subscription_id": subscription_id},
                    {"$set": {"status": "past_due"}}
                )
        
        return {"status": "success"}
    except Exception as e:
        logging.error(f"Webhook error: {e}")
        raise HTTPException(status_code=400, detail=str(e))

# Workouts Endpoints
@api_router.get("/workouts", response_model=List[Workout])
async def get_workouts(level: Optional[str] = None, program_type: Optional[str] = None, language: str = "fr"):
    query = {"language": language}
    if level:
        query["level"] = level
    if program_type:
        query["program_type"] = program_type
    
    workouts = await db.workouts.find(query, {"_id": 0}).to_list(100)
    return [Workout(**w) for w in workouts]

@api_router.get("/workouts/{workout_id}", response_model=Workout)
async def get_workout(workout_id: str, language: str = "fr"):
    # First try to find with exact language match
    workout = await db.workouts.find_one({"workout_id": workout_id, "language": language}, {"_id": 0})
    if not workout:
        # If not found, try to find by ID only (fallback to any language version)
        workout = await db.workouts.find_one({"workout_id": workout_id}, {"_id": 0})
    if not workout:
        raise HTTPException(status_code=404, detail="Workout not found")
    return Workout(**workout)

# Supplements Endpoints
@api_router.get("/supplements", response_model=List[Supplement])
async def get_supplements(program_type: Optional[str] = None, language: str = "fr"):
    query = {"language": language}
    if program_type:
        query["program_type"] = program_type
    
    supplements = await db.supplements.find(query, {"_id": 0}).to_list(100)
    return [Supplement(**s) for s in supplements]

# User Subscription Endpoints
@api_router.get("/user/subscription")
async def get_user_subscription(current_user: User = Depends(get_current_user)):
    subscription = await db.user_subscriptions.find_one({"user_id": current_user.user_id, "status": "active"}, {"_id": 0})
    return subscription or {"tier": "none", "status": "inactive"}

@api_router.post("/user/subscription/cancel")
async def cancel_subscription(current_user: User = Depends(get_current_user)):
    result = await db.user_subscriptions.update_many(
        {"user_id": current_user.user_id, "status": "active", "billing_cycle": "monthly"},
        {"$set": {"status": "cancelled", "auto_renew": False}}
    )
    
    if result.modified_count > 0:
        await db.users.update_one(
            {"user_id": current_user.user_id},
            {"$set": {"subscription_status": "cancelled"}}
        )
        return {"message": "Subscription cancelled successfully"}
    else:
        raise HTTPException(status_code=400, detail="No active monthly subscription found")

# Health check endpoint (required for deployment)
@app.get("/health")
async def health_check():
    try:
        # Test MongoDB connection
        await db.command('ping')
        return {
            "status": "healthy",
            "service": "fitmaxpro-backend",
            "database": "connected"
        }
    except Exception as e:
        logging.error(f"Health check failed: {e}")
        return {
            "status": "unhealthy",
            "service": "fitmaxpro-backend",
            "error": str(e)
        }

# Router will be included after all endpoints are defined

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

# ==========================================
# ADMIN ENDPOINTS - Gestion des médias
# ==========================================

class ExerciseUpdate(BaseModel):
    name: str
    sets: int
    reps: str
    rest: str
    description: Optional[str] = None
    image_url: Optional[str] = None
    video_url: Optional[str] = None

class WorkoutUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    image_url: Optional[str] = None
    exercises: Optional[List[ExerciseUpdate]] = None

class NutrientUpdate(BaseModel):
    name: str
    dosage: str
    timing: str
    description: Optional[str] = None
    image_url: Optional[str] = None
    video_url: Optional[str] = None

class MealUpdate(BaseModel):
    name: str
    description: str
    calories: int
    proteins: int
    carbs: int
    fats: int
    image_url: Optional[str] = None
    video_url: Optional[str] = None

class SupplementUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    image_url: Optional[str] = None
    video_url: Optional[str] = None
    nutrients: Optional[List[NutrientUpdate]] = None
    meals: Optional[List[MealUpdate]] = None

async def verify_admin(current_user: User = Depends(get_current_user)):
    """Vérifie que l'utilisateur est admin (VIP)"""
    if current_user.subscription_tier != "vip":
        raise HTTPException(status_code=403, detail="Admin access required (VIP)")
    return current_user

# ==================== VIDEO UPLOAD SYSTEM ====================

UPLOAD_DIR = ROOT_DIR / "uploads" / "videos"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

# Allowed video formats
ALLOWED_VIDEO_TYPES = {
    "video/mp4": ".mp4",
    "video/webm": ".webm",
    "video/quicktime": ".mov",
    "video/x-msvideo": ".avi",
    "video/x-matroska": ".mkv"
}

MAX_VIDEO_SIZE = 500 * 1024 * 1024  # 500 MB

@api_router.post("/admin/upload-video")
async def admin_upload_video(
    file: UploadFile = File(...),
    admin: User = Depends(verify_admin)
):
    """Admin: Upload a video file for exercises"""
    content_type = file.content_type
    if content_type not in ALLOWED_VIDEO_TYPES:
        raise HTTPException(
            status_code=400, 
            detail=f"Type de fichier non supporté. Utilisez: MP4, WebM, MOV, AVI, MKV"
        )
    
    extension = ALLOWED_VIDEO_TYPES[content_type]
    video_id = f"video_{uuid.uuid4().hex[:12]}"
    filename = f"{video_id}{extension}"
    filepath = UPLOAD_DIR / filename
    
    try:
        total_size = 0
        async with aiofiles.open(filepath, 'wb') as out_file:
            while chunk := await file.read(1024 * 1024):
                total_size += len(chunk)
                if total_size > MAX_VIDEO_SIZE:
                    await out_file.close()
                    filepath.unlink(missing_ok=True)
                    raise HTTPException(status_code=400, detail=f"Fichier trop volumineux. Maximum: 500 MB")
                await out_file.write(chunk)
        
        video_doc = {
            "video_id": video_id,
            "filename": filename,
            "original_name": file.filename,
            "content_type": content_type,
            "size": total_size,
            "uploaded_by": admin.user_id,
            "uploaded_at": datetime.now(timezone.utc).isoformat(),
            "url": f"/api/videos/{video_id}"
        }
        await db.uploaded_videos.insert_one(video_doc)
        video_doc.pop("_id", None)
        
        return {
            "success": True,
            "video_id": video_id,
            "url": f"/api/videos/{video_id}",
            "filename": file.filename,
            "size": total_size
        }
    except HTTPException:
        raise
    except Exception as e:
        filepath.unlink(missing_ok=True)
        logging.error(f"Video upload error: {e}")
        raise HTTPException(status_code=500, detail="Erreur lors de l'upload")

@api_router.get("/videos/{video_id}")
async def get_video(video_id: str, request: Request):
    """Stream a video file with range support for seeking"""
    video = await db.uploaded_videos.find_one({"video_id": video_id})
    if not video:
        raise HTTPException(status_code=404, detail="Vidéo non trouvée")
    
    filepath = UPLOAD_DIR / video["filename"]
    if not filepath.exists():
        raise HTTPException(status_code=404, detail="Fichier vidéo non trouvé")
    
    file_size = filepath.stat().st_size
    content_type = video.get("content_type", "video/mp4")
    range_header = request.headers.get("range")
    
    if range_header:
        range_match = range_header.replace("bytes=", "").split("-")
        start = int(range_match[0]) if range_match[0] else 0
        end = int(range_match[1]) if range_match[1] else file_size - 1
        
        if start >= file_size:
            raise HTTPException(status_code=416, detail="Range not satisfiable")
        
        chunk_size = end - start + 1
        
        async def stream_video():
            async with aiofiles.open(filepath, 'rb') as video_file:
                await video_file.seek(start)
                remaining = chunk_size
                while remaining > 0:
                    read_size = min(remaining, 1024 * 1024)
                    chunk = await video_file.read(read_size)
                    if not chunk:
                        break
                    remaining -= len(chunk)
                    yield chunk
        
        from starlette.responses import StreamingResponse
        return StreamingResponse(
            stream_video(),
            status_code=206,
            headers={
                "Content-Range": f"bytes {start}-{end}/{file_size}",
                "Accept-Ranges": "bytes",
                "Content-Length": str(chunk_size),
                "Content-Type": content_type,
            }
        )
    else:
        return FileResponse(
            filepath,
            media_type=content_type,
            headers={"Accept-Ranges": "bytes", "Content-Length": str(file_size)}
        )

@api_router.get("/admin/videos")
async def admin_list_videos(admin: User = Depends(verify_admin)):
    """Admin: List all uploaded videos"""
    videos = await db.uploaded_videos.find({}, {"_id": 0}).sort("uploaded_at", -1).to_list(100)
    return {"videos": videos}

@api_router.delete("/admin/videos/{video_id}")
async def admin_delete_video(video_id: str, admin: User = Depends(verify_admin)):
    """Admin: Delete an uploaded video"""
    video = await db.uploaded_videos.find_one({"video_id": video_id})
    if not video:
        raise HTTPException(status_code=404, detail="Vidéo non trouvée")
    
    filepath = UPLOAD_DIR / video["filename"]
    filepath.unlink(missing_ok=True)
    await db.uploaded_videos.delete_one({"video_id": video_id})
    
    return {"success": True, "message": "Vidéo supprimée"}

# --- WORKOUTS ADMIN ---

@api_router.get("/admin/workouts")
async def admin_get_all_workouts(admin: User = Depends(verify_admin)):
    """Liste tous les workouts pour l'admin"""
    workouts = await db.workouts.find({}, {"_id": 0}).to_list(1000)
    return workouts

@api_router.get("/admin/workouts/{workout_id}")
async def admin_get_workout(workout_id: str, language: str = "fr", admin: User = Depends(verify_admin)):
    """Récupère un workout spécifique"""
    workout = await db.workouts.find_one(
        {"workout_id": workout_id, "language": language}, 
        {"_id": 0}
    )
    if not workout:
        raise HTTPException(status_code=404, detail="Workout not found")
    return workout

@api_router.put("/admin/workouts/{workout_id}")
async def admin_update_workout(
    workout_id: str, 
    update: WorkoutUpdate, 
    language: str = "fr",
    admin: User = Depends(verify_admin)
):
    """Met à jour un workout (titre, description, image, exercices)"""
    update_data = {}
    
    if update.title is not None:
        update_data["title"] = update.title
    if update.description is not None:
        update_data["description"] = update.description
    if update.image_url is not None:
        update_data["image_url"] = update.image_url
    if update.exercises is not None:
        update_data["exercises"] = [ex.model_dump() for ex in update.exercises]
    
    if not update_data:
        raise HTTPException(status_code=400, detail="No update data provided")
    
    result = await db.workouts.update_one(
        {"workout_id": workout_id, "language": language},
        {"$set": update_data}
    )
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Workout not found")
    
    return {"message": "Workout updated successfully", "modified": result.modified_count}

@api_router.put("/admin/workouts/{workout_id}/exercise/{exercise_index}")
async def admin_update_exercise(
    workout_id: str,
    exercise_index: int,
    exercise: ExerciseUpdate,
    language: str = "fr",
    admin: User = Depends(verify_admin)
):
    """Met à jour un exercice spécifique dans un workout"""
    workout = await db.workouts.find_one(
        {"workout_id": workout_id, "language": language}
    )
    
    if not workout:
        raise HTTPException(status_code=404, detail="Workout not found")
    
    exercises = workout.get("exercises", [])
    if exercise_index < 0 or exercise_index >= len(exercises):
        raise HTTPException(status_code=400, detail="Invalid exercise index")
    
    exercises[exercise_index] = exercise.model_dump()
    
    await db.workouts.update_one(
        {"workout_id": workout_id, "language": language},
        {"$set": {"exercises": exercises}}
    )
    
    return {"message": "Exercise updated successfully"}

# --- CRÉATION ET GESTION COMPLÈTE DES WORKOUTS ---

class NewWorkout(BaseModel):
    title: str
    description: str
    level: str  # beginner, intermediate, advanced
    program_type: str  # mass_gain, weight_loss, legs_glutes
    duration: int
    language: str
    image_url: Optional[str] = None
    exercises: List[Dict] = []

class NewExercise(BaseModel):
    name: str
    description: str
    sets: int
    reps: str
    rest: str
    image_url: Optional[str] = None
    video_url: Optional[str] = None

@api_router.post("/admin/workouts")
async def admin_create_workout(workout: NewWorkout, admin: User = Depends(verify_admin)):
    """Créer une nouvelle séance d'entraînement"""
    workout_data = workout.model_dump()
    workout_data["workout_id"] = f"workout_{uuid.uuid4().hex[:12]}"
    
    await db.workouts.insert_one(workout_data)
    
    return {"message": "Workout created successfully", "workout_id": workout_data["workout_id"]}

@api_router.put("/admin/workouts/{workout_id}/full")
async def admin_update_workout_full(workout_id: str, workout: NewWorkout, admin: User = Depends(verify_admin)):
    """Mettre à jour une séance complète"""
    result = await db.workouts.update_one(
        {"workout_id": workout_id},
        {"$set": workout.model_dump()}
    )
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Workout not found")
    
    return {"message": "Workout updated successfully"}

@api_router.delete("/admin/workouts/{workout_id}")
async def admin_delete_workout(workout_id: str, admin: User = Depends(verify_admin)):
    """Supprimer une séance"""
    result = await db.workouts.delete_one({"workout_id": workout_id})
    
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Workout not found")
    
    return {"message": "Workout deleted successfully"}

@api_router.post("/admin/workouts/{workout_id}/exercises")
async def admin_add_exercise(workout_id: str, exercise: NewExercise, admin: User = Depends(verify_admin)):
    """Ajouter un exercice à une séance"""
    workout = await db.workouts.find_one({"workout_id": workout_id})
    
    if not workout:
        raise HTTPException(status_code=404, detail="Workout not found")
    
    exercises = workout.get("exercises", [])
    exercises.append(exercise.model_dump())
    
    await db.workouts.update_one(
        {"workout_id": workout_id},
        {"$set": {"exercises": exercises}}
    )
    
    return {"message": "Exercise added successfully", "exercise_index": len(exercises) - 1}

@api_router.delete("/admin/workouts/{workout_id}/exercises/{exercise_index}")
async def admin_delete_exercise(workout_id: str, exercise_index: int, admin: User = Depends(verify_admin)):
    """Supprimer un exercice d'une séance"""
    workout = await db.workouts.find_one({"workout_id": workout_id})
    
    if not workout:
        raise HTTPException(status_code=404, detail="Workout not found")
    
    exercises = workout.get("exercises", [])
    
    if exercise_index < 0 or exercise_index >= len(exercises):
        raise HTTPException(status_code=400, detail="Invalid exercise index")
    
    exercises.pop(exercise_index)
    
    await db.workouts.update_one(
        {"workout_id": workout_id},
        {"$set": {"exercises": exercises}}
    )
    
    return {"message": "Exercise deleted successfully"}

# --- SUPPLEMENTS ADMIN ---

@api_router.get("/admin/supplements")
async def admin_get_all_supplements(admin: User = Depends(verify_admin)):
    """Liste tous les suppléments pour l'admin"""
    supplements = await db.supplements.find({}, {"_id": 0}).to_list(100)
    return supplements

@api_router.get("/admin/supplements/{supplement_id}")
async def admin_get_supplement(supplement_id: str, admin: User = Depends(verify_admin)):
    """Récupère un supplément spécifique"""
    supplement = await db.supplements.find_one(
        {"supplement_id": supplement_id}, 
        {"_id": 0}
    )
    if not supplement:
        raise HTTPException(status_code=404, detail="Supplement not found")
    return supplement

@api_router.put("/admin/supplements/{supplement_id}")
async def admin_update_supplement(
    supplement_id: str, 
    update: SupplementUpdate,
    admin: User = Depends(verify_admin)
):
    """Met à jour un supplément (titre, description, image, nutrients, meals)"""
    update_data = {}
    
    if update.title is not None:
        update_data["title"] = update.title
    if update.description is not None:
        update_data["description"] = update.description
    if update.image_url is not None:
        update_data["image_url"] = update.image_url
    if update.video_url is not None:
        update_data["video_url"] = update.video_url
    if update.nutrients is not None:
        update_data["nutrients"] = [n.model_dump() for n in update.nutrients]
    if update.meals is not None:
        update_data["meals"] = [m.model_dump() for m in update.meals]
    
    if not update_data:
        raise HTTPException(status_code=400, detail="No update data provided")
    
    result = await db.supplements.update_one(
        {"supplement_id": supplement_id},
        {"$set": update_data}
    )
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Supplement not found")
    
    return {"message": "Supplement updated successfully", "modified": result.modified_count}

@api_router.put("/admin/supplements/{supplement_id}/nutrient/{nutrient_index}")
async def admin_update_nutrient(
    supplement_id: str,
    nutrient_index: int,
    nutrient: NutrientUpdate,
    admin: User = Depends(verify_admin)
):
    """Met à jour un nutriment spécifique"""
    supplement = await db.supplements.find_one({"supplement_id": supplement_id})
    
    if not supplement:
        raise HTTPException(status_code=404, detail="Supplement not found")
    
    nutrients = supplement.get("nutrients", [])
    if nutrient_index < 0 or nutrient_index >= len(nutrients):
        raise HTTPException(status_code=400, detail="Invalid nutrient index")
    
    nutrients[nutrient_index] = nutrient.model_dump()
    
    await db.supplements.update_one(
        {"supplement_id": supplement_id},
        {"$set": {"nutrients": nutrients}}
    )
    
    return {"message": "Nutrient updated successfully"}

@api_router.put("/admin/supplements/{supplement_id}/meal/{meal_index}")
async def admin_update_meal(
    supplement_id: str,
    meal_index: int,
    meal: MealUpdate,
    admin: User = Depends(verify_admin)
):
    """Met à jour un repas spécifique"""
    supplement = await db.supplements.find_one({"supplement_id": supplement_id})
    
    if not supplement:
        raise HTTPException(status_code=404, detail="Supplement not found")
    
    meals = supplement.get("meals", [])
    if meal_index < 0 or meal_index >= len(meals):
        raise HTTPException(status_code=400, detail="Invalid meal index")
    
    meals[meal_index] = meal.model_dump()
    
    await db.supplements.update_one(
        {"supplement_id": supplement_id},
        {"$set": {"meals": meals}}
    )
    
    return {"message": "Meal updated successfully"}

@api_router.put("/admin/supplements/{supplement_id}/meal/{meal_index}/recipe")
async def admin_update_meal_recipe(
    supplement_id: str,
    meal_index: int,
    recipe_data: MealRecipeUpdate,
    admin: User = Depends(verify_admin)
):
    """Met à jour la recette d'un repas spécifique"""
    supplement = await db.supplements.find_one({"supplement_id": supplement_id})
    
    if not supplement:
        raise HTTPException(status_code=404, detail="Supplement not found")
    
    meals = supplement.get("meals", [])
    if meal_index < 0 or meal_index >= len(meals):
        raise HTTPException(status_code=400, detail="Invalid meal index")
    
    # Add recipe to the meal
    meals[meal_index]["recipe"] = recipe_data.recipe.model_dump()
    
    await db.supplements.update_one(
        {"supplement_id": supplement_id},
        {"$set": {"meals": meals}}
    )
    
    return {"message": "Recipe updated successfully"}

@api_router.post("/admin/supplements/{supplement_id}/meals")
async def admin_add_meal(
    supplement_id: str,
    meal: MealUpdate,
    admin: User = Depends(verify_admin)
):
    """Ajoute un nouveau repas à un plan nutritionnel"""
    supplement = await db.supplements.find_one({"supplement_id": supplement_id})
    if not supplement:
        raise HTTPException(status_code=404, detail="Supplement not found")
    
    meals = supplement.get("meals", [])
    meals.append(meal.model_dump())
    
    await db.supplements.update_one(
        {"supplement_id": supplement_id},
        {"$set": {"meals": meals}}
    )
    
    return {"message": "Meal added successfully", "meal_index": len(meals) - 1}

@api_router.delete("/admin/supplements/{supplement_id}/meals/{meal_index}")
async def admin_delete_meal(
    supplement_id: str,
    meal_index: int,
    admin: User = Depends(verify_admin)
):
    """Supprime un repas d'un plan nutritionnel"""
    supplement = await db.supplements.find_one({"supplement_id": supplement_id})
    if not supplement:
        raise HTTPException(status_code=404, detail="Supplement not found")
    
    meals = supplement.get("meals", [])
    if meal_index < 0 or meal_index >= len(meals):
        raise HTTPException(status_code=400, detail="Invalid meal index")
    
    meals.pop(meal_index)
    
    await db.supplements.update_one(
        {"supplement_id": supplement_id},
        {"$set": {"meals": meals}}
    )
    
    return {"message": "Meal deleted successfully"}

# --- STATS ADMIN ---

@api_router.get("/admin/stats")
async def admin_get_stats(admin: User = Depends(verify_admin)):
    """Statistiques pour l'admin"""
    users_count = await db.users.count_documents({})
    workouts_count = await db.workouts.count_documents({})
    supplements_count = await db.supplements.count_documents({})
    subscriptions_count = await db.user_subscriptions.count_documents({})
    
    # Compter par tier
    vip_count = await db.users.count_documents({"subscription_tier": "vip"})
    standard_count = await db.users.count_documents({"subscription_tier": "standard"})
    supplements_tier_count = await db.users.count_documents({"subscription_tier": "supplements"})
    
    # Statistiques des séances
    total_sessions = await db.workout_sessions.count_documents({})
    completed_sessions = await db.workout_sessions.count_documents({"completed": True})
    
    # Temps total passé sur les séances
    pipeline = [
        {"$group": {"_id": None, "total_duration": {"$sum": "$duration_seconds"}}}
    ]
    duration_result = await db.workout_sessions.aggregate(pipeline).to_list(1)
    total_duration = duration_result[0]["total_duration"] if duration_result else 0
    
    return {
        "total_users": users_count,
        "total_workouts": workouts_count,
        "total_supplements": supplements_count,
        "total_subscriptions": subscriptions_count,
        "vip_users": vip_count,
        "standard_users": standard_count,
        "supplements_users": supplements_tier_count,
        "total_workout_sessions": total_sessions,
        "completed_workout_sessions": completed_sessions,
        "total_workout_duration_seconds": total_duration
    }

# ==================== ADMIN - GESTION DES ABONNÉS ====================

@api_router.get("/admin/subscribers")
async def admin_get_subscribers(admin: User = Depends(verify_admin)):
    """Récupérer la liste complète des abonnés avec leurs détails"""
    users = await db.users.find(
        {},
        {"_id": 0, "password": 0}
    ).to_list(1000)
    
    # Enrichir avec les statistiques de séances pour chaque utilisateur
    for user in users:
        user_id = user.get("user_id")
        
        # Nombre de séances effectuées
        sessions_count = await db.workout_sessions.count_documents({"user_id": user_id})
        completed_count = await db.workout_sessions.count_documents({"user_id": user_id, "completed": True})
        
        # Temps total passé
        pipeline = [
            {"$match": {"user_id": user_id}},
            {"$group": {"_id": None, "total_duration": {"$sum": "$duration_seconds"}}}
        ]
        duration_result = await db.workout_sessions.aggregate(pipeline).to_list(1)
        total_duration = duration_result[0]["total_duration"] if duration_result else 0
        
        user["stats"] = {
            "total_sessions": sessions_count,
            "completed_sessions": completed_count,
            "total_duration_seconds": total_duration,
            "total_duration_formatted": f"{total_duration // 3600}h {(total_duration % 3600) // 60}m"
        }
    
    return {"subscribers": users, "total": len(users)}

@api_router.get("/admin/subscriber/{user_id}")
async def admin_get_subscriber_detail(user_id: str, admin: User = Depends(verify_admin)):
    """Récupérer les détails complets d'un abonné"""
    user = await db.users.find_one({"user_id": user_id}, {"_id": 0, "password": 0})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Récupérer toutes les séances de l'utilisateur
    sessions = await db.workout_sessions.find(
        {"user_id": user_id},
        {"_id": 0}
    ).sort("started_at", -1).to_list(100)
    
    # Statistiques détaillées
    total_sessions = len(sessions)
    completed_sessions = sum(1 for s in sessions if s.get("completed"))
    total_duration = sum(s.get("duration_seconds", 0) for s in sessions)
    
    # Séances par workout
    workout_stats = {}
    for session in sessions:
        wid = session.get("workout_id")
        if wid not in workout_stats:
            workout_stats[wid] = {
                "workout_title": session.get("workout_title", "Unknown"),
                "launches": 0,
                "completed": 0,
                "total_duration": 0
            }
        workout_stats[wid]["launches"] += 1
        if session.get("completed"):
            workout_stats[wid]["completed"] += 1
        workout_stats[wid]["total_duration"] += session.get("duration_seconds", 0)
    
    return {
        "user": user,
        "stats": {
            "total_sessions": total_sessions,
            "completed_sessions": completed_sessions,
            "total_duration_seconds": total_duration,
            "total_duration_formatted": f"{total_duration // 3600}h {(total_duration % 3600) // 60}m"
        },
        "workout_stats": list(workout_stats.values()),
        "recent_sessions": sessions[:20]
    }

@api_router.put("/admin/subscriber/{user_id}/subscription")
async def admin_update_subscription(user_id: str, update: SubscriptionUpdate, admin: User = Depends(verify_admin)):
    """Modifier l'abonnement d'un utilisateur (Admin seulement)"""
    result = await db.users.update_one(
        {"user_id": user_id},
        {"$set": {
            "subscription_tier": update.subscription_tier,
            "subscription_status": update.subscription_status
        }}
    )
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="User not found")
    
    return {"success": True, "message": f"Subscription updated for user {user_id}"}

@api_router.delete("/admin/subscriber/{user_id}")
async def admin_delete_subscriber(user_id: str, admin: User = Depends(verify_admin)):
    """Supprimer un abonné (Admin seulement)"""
    # Vérifier que ce n'est pas l'admin lui-même
    if user_id == admin.user_id:
        raise HTTPException(status_code=400, detail="Cannot delete your own account")
    
    result = await db.users.delete_one({"user_id": user_id})
    
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Supprimer aussi les sessions et données associées
    await db.user_sessions.delete_many({"user_id": user_id})
    await db.workout_sessions.delete_many({"user_id": user_id})
    await db.user_subscriptions.delete_many({"user_id": user_id})
    
    return {"success": True, "message": f"User {user_id} deleted successfully"}

# ==================== TRACKING DES SÉANCES ====================

@api_router.post("/workout/start")
async def start_workout_session(workout_id: str, user: User = Depends(get_current_user)):
    """Démarrer une séance d'entraînement"""
    # Récupérer le workout pour avoir le titre
    workout = await db.workouts.find_one({"workout_id": workout_id}, {"_id": 0})
    if not workout:
        raise HTTPException(status_code=404, detail="Workout not found")
    
    session_id = str(uuid.uuid4())
    session_data = {
        "session_id": session_id,
        "user_id": user.user_id,
        "workout_id": workout_id,
        "workout_title": workout.get("title", "Unknown"),
        "started_at": datetime.now(timezone.utc).isoformat(),
        "ended_at": None,
        "duration_seconds": 0,
        "completed": False
    }
    
    await db.workout_sessions.insert_one(session_data)
    
    return {"session_id": session_id, "message": "Workout session started"}

@api_router.post("/workout/end")
async def end_workout_session(session_id: str, completed: bool = True, user: User = Depends(get_current_user)):
    """Terminer une séance d'entraînement"""
    session = await db.workout_sessions.find_one(
        {"session_id": session_id, "user_id": user.user_id},
        {"_id": 0}
    )
    
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    started_at = session.get("started_at")
    if isinstance(started_at, str):
        started_at = datetime.fromisoformat(started_at.replace('Z', '+00:00'))
    
    ended_at = datetime.now(timezone.utc)
    duration_seconds = int((ended_at - started_at).total_seconds())
    
    await db.workout_sessions.update_one(
        {"session_id": session_id},
        {"$set": {
            "ended_at": ended_at.isoformat(),
            "duration_seconds": duration_seconds,
            "completed": completed
        }}
    )
    
    # ==================== AUTOMATISATION DES POINTS WORKOUT ====================
    points_earned = 0
    points_breakdown = []
    
    if completed:
        # Base points for completing a workout
        points_earned += 15
        points_breakdown.append("+15 pts (séance complétée)")
        
        # Bonus for duration (longer workouts = more points)
        duration_bonus = min(duration_seconds // 60, 30)  # Max 30 points for duration
        if duration_bonus > 0:
            points_earned += duration_bonus
            points_breakdown.append(f"+{duration_bonus} pts (durée {duration_seconds // 60}min)")
        
        # Check if first workout of the day
        today_start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
        todays_sessions = await db.workout_sessions.count_documents({
            "user_id": user.user_id,
            "completed": True,
            "ended_at": {"$gte": today_start.isoformat()}
        })
        
        if todays_sessions <= 1:  # This is the first (or only) completed session today
            points_earned += 25
            points_breakdown.append("+25 pts (premier workout du jour)")
        
        # Check for consecutive days streak
        yesterday = (datetime.now(timezone.utc) - timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
        yesterday_sessions = await db.workout_sessions.count_documents({
            "user_id": user.user_id,
            "completed": True,
            "ended_at": {
                "$gte": yesterday.isoformat(),
                "$lt": today_start.isoformat()
            }
        })
        
        if yesterday_sessions > 0:
            # User worked out yesterday too - streak bonus!
            # Calculate current streak
            streak_days = 1
            check_date = yesterday
            for i in range(30):  # Check up to 30 days back
                prev_day_start = (check_date - timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
                prev_sessions = await db.workout_sessions.count_documents({
                    "user_id": user.user_id,
                    "completed": True,
                    "ended_at": {
                        "$gte": prev_day_start.isoformat(),
                        "$lt": check_date.isoformat()
                    }
                })
                if prev_sessions > 0:
                    streak_days += 1
                    check_date = prev_day_start
                else:
                    break
            
            if streak_days >= 2:
                streak_bonus = min(streak_days * 5, 50)  # 5 pts per day, max 50
                points_earned += streak_bonus
                points_breakdown.append(f"+{streak_bonus} pts (série de {streak_days} jours)")
        
        # Award the points
        if points_earned > 0:
            await add_points(user.user_id, points_earned, "workout_completed", session_id)
    
    return {
        "message": "Workout session ended",
        "duration_seconds": duration_seconds,
        "duration_formatted": f"{duration_seconds // 60}m {duration_seconds % 60}s",
        "completed": completed,
        "points_earned": points_earned,
        "points_breakdown": points_breakdown
    }

@api_router.get("/workout/my-sessions")
async def get_my_sessions(user: User = Depends(get_current_user)):
    """Récupérer l'historique de mes séances"""
    sessions = await db.workout_sessions.find(
        {"user_id": user.user_id},
        {"_id": 0}
    ).sort("started_at", -1).to_list(50)
    
    total_duration = sum(s.get("duration_seconds", 0) for s in sessions)
    completed_count = sum(1 for s in sessions if s.get("completed"))
    
    return {
        "sessions": sessions,
        "stats": {
            "total_sessions": len(sessions),
            "completed_sessions": completed_count,
            "total_duration_seconds": total_duration,
            "total_duration_formatted": f"{total_duration // 3600}h {(total_duration % 3600) // 60}m"
        }
    }

@api_router.post("/workout/pause/start")
async def start_pause(session_id: str, user: User = Depends(get_current_user)):
    """Démarrer une pause dans la séance"""
    session = await db.workout_sessions.find_one(
        {"session_id": session_id, "user_id": user.user_id},
        {"_id": 0}
    )
    
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    pause_id = str(uuid.uuid4())
    pause_data = {
        "pause_id": pause_id,
        "started_at": datetime.now(timezone.utc).isoformat()
    }
    
    # Ajouter la pause au tableau des pauses
    await db.workout_sessions.update_one(
        {"session_id": session_id},
        {
            "$push": {"pauses": pause_data},
            "$set": {"is_paused": True, "current_pause_id": pause_id}
        }
    )
    
    return {"pause_id": pause_id, "message": "Pause started"}

@api_router.post("/workout/pause/end")
async def end_pause(session_id: str, pause_id: str, user: User = Depends(get_current_user)):
    """Terminer une pause dans la séance"""
    session = await db.workout_sessions.find_one(
        {"session_id": session_id, "user_id": user.user_id},
        {"_id": 0}
    )
    
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    pauses = session.get("pauses", [])
    pause_found = None
    pause_index = -1
    
    for i, pause in enumerate(pauses):
        if pause.get("pause_id") == pause_id:
            pause_found = pause
            pause_index = i
            break
    
    if not pause_found:
        raise HTTPException(status_code=404, detail="Pause not found")
    
    started_at = pause_found.get("started_at")
    if isinstance(started_at, str):
        started_at = datetime.fromisoformat(started_at.replace('Z', '+00:00'))
    
    ended_at = datetime.now(timezone.utc)
    duration_seconds = int((ended_at - started_at).total_seconds())
    
    # Mettre à jour la pause
    await db.workout_sessions.update_one(
        {"session_id": session_id},
        {
            "$set": {
                f"pauses.{pause_index}.ended_at": ended_at.isoformat(),
                f"pauses.{pause_index}.duration_seconds": duration_seconds,
                "is_paused": False,
                "current_pause_id": None
            },
            "$inc": {"total_pause_seconds": duration_seconds}
        }
    )
    
    return {
        "message": "Pause ended",
        "pause_duration_seconds": duration_seconds,
        "pause_duration_formatted": f"{duration_seconds // 60}m {duration_seconds % 60}s"
    }

@api_router.get("/workout/session/{session_id}")
async def get_session_details(session_id: str, user: User = Depends(get_current_user)):
    """Récupérer les détails d'une séance en cours ou terminée"""
    session = await db.workout_sessions.find_one(
        {"session_id": session_id, "user_id": user.user_id},
        {"_id": 0}
    )
    
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    return session

# ==================== ADMIN - STATISTIQUES AVANCÉES ====================

@api_router.get("/admin/workout-analytics")
async def admin_get_workout_analytics(admin: User = Depends(verify_admin)):
    """Statistiques détaillées sur les séances par workout"""
    pipeline = [
        {"$group": {
            "_id": "$workout_id",
            "workout_title": {"$first": "$workout_title"},
            "total_launches": {"$sum": 1},
            "completed_count": {"$sum": {"$cond": ["$completed", 1, 0]}},
            "total_duration": {"$sum": "$duration_seconds"},
            "avg_duration": {"$avg": "$duration_seconds"}
        }},
        {"$sort": {"total_launches": -1}}
    ]
    
    results = await db.workout_sessions.aggregate(pipeline).to_list(100)
    
    for r in results:
        r["workout_id"] = r.pop("_id")
        r["avg_duration_formatted"] = f"{int(r['avg_duration'] // 60)}m {int(r['avg_duration'] % 60)}s" if r['avg_duration'] else "0m"
        r["total_duration_formatted"] = f"{r['total_duration'] // 3600}h {(r['total_duration'] % 3600) // 60}m"
        r["completion_rate"] = f"{(r['completed_count'] / r['total_launches'] * 100):.1f}%" if r['total_launches'] > 0 else "0%"
    
    return {"workout_analytics": results}

@api_router.get("/admin/daily-activity")
async def admin_get_daily_activity(days: int = 30, admin: User = Depends(verify_admin)):
    """Activité quotidienne des 30 derniers jours"""
    start_date = datetime.now(timezone.utc) - timedelta(days=days)
    
    pipeline = [
        {"$match": {"started_at": {"$gte": start_date.isoformat()}}},
        {"$group": {
            "_id": {"$substr": ["$started_at", 0, 10]},
            "sessions_count": {"$sum": 1},
            "unique_users": {"$addToSet": "$user_id"},
            "total_duration": {"$sum": "$duration_seconds"}
        }},
        {"$project": {
            "date": "$_id",
            "sessions_count": 1,
            "unique_users_count": {"$size": "$unique_users"},
            "total_duration": 1
        }},
        {"$sort": {"_id": -1}}
    ]
    
    results = await db.workout_sessions.aggregate(pipeline).to_list(days)
    
    return {"daily_activity": results}

# ==================== ADMIN - STATISTIQUES PAR UTILISATEUR ====================

@api_router.get("/admin/user/{user_id}/sessions")
async def admin_get_user_sessions(user_id: str, admin: User = Depends(verify_admin)):
    """Récupérer toutes les séances d'un utilisateur spécifique"""
    user = await db.users.find_one({"user_id": user_id}, {"_id": 0})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    sessions = await db.workout_sessions.find(
        {"user_id": user_id},
        {"_id": 0}
    ).sort("started_at", -1).to_list(100)
    
    total_duration = sum(s.get("duration_seconds", 0) for s in sessions)
    completed_count = sum(1 for s in sessions if s.get("completed"))
    total_pause = sum(s.get("total_pause_seconds", 0) for s in sessions)
    
    # Calculate average session duration
    avg_duration = total_duration / len(sessions) if sessions else 0
    
    return {
        "user": {
            "user_id": user.get("user_id"),
            "name": user.get("name"),
            "email": user.get("email"),
            "subscription_tier": user.get("subscription_tier")
        },
        "sessions": sessions,
        "stats": {
            "total_sessions": len(sessions),
            "completed_sessions": completed_count,
            "completion_rate": f"{(completed_count / len(sessions) * 100):.1f}%" if sessions else "0%",
            "total_duration_seconds": total_duration,
            "total_duration_formatted": f"{total_duration // 3600}h {(total_duration % 3600) // 60}m",
            "avg_session_duration": f"{int(avg_duration // 60)}m {int(avg_duration % 60)}s",
            "total_pause_time": f"{total_pause // 60}m {total_pause % 60}s"
        }
    }

@api_router.get("/admin/all-user-progress")
async def admin_get_all_user_progress(admin: User = Depends(verify_admin)):
    """Récupérer les statistiques de progression de tous les utilisateurs"""
    pipeline = [
        {"$group": {
            "_id": "$user_id",
            "total_sessions": {"$sum": 1},
            "completed_sessions": {"$sum": {"$cond": ["$completed", 1, 0]}},
            "total_duration": {"$sum": "$duration_seconds"},
            "total_pause": {"$sum": {"$ifNull": ["$total_pause_seconds", 0]}},
            "avg_duration": {"$avg": "$duration_seconds"},
            "last_session": {"$max": "$started_at"}
        }},
        {"$sort": {"total_sessions": -1}}
    ]
    
    results = await db.workout_sessions.aggregate(pipeline).to_list(100)
    
    # Enrichir avec les infos utilisateur
    for r in results:
        user = await db.users.find_one({"user_id": r["_id"]}, {"_id": 0})
        if user:
            r["user_name"] = user.get("name", "Unknown")
            r["user_email"] = user.get("email", "")
            r["subscription_tier"] = user.get("subscription_tier", "free")
        else:
            r["user_name"] = "Unknown"
            r["user_email"] = ""
            r["subscription_tier"] = "free"
        
        r["user_id"] = r.pop("_id")
        r["avg_duration_formatted"] = f"{int(r['avg_duration'] // 60)}m {int(r['avg_duration'] % 60)}s" if r['avg_duration'] else "0m"
        r["total_duration_formatted"] = f"{r['total_duration'] // 3600}h {(r['total_duration'] % 3600) // 60}m"
        r["completion_rate"] = f"{(r['completed_sessions'] / r['total_sessions'] * 100):.1f}%" if r['total_sessions'] > 0 else "0%"
    
    return {"user_progress": results}

# ==================== MESSAGERIE ====================

class MessageCreate(BaseModel):
    content: str
    recipient_id: Optional[str] = None  # None = message to admin

@api_router.post("/messages/send")
async def send_message(message: MessageCreate, user: User = Depends(get_current_user)):
    """Envoyer un message (utilisateur -> admin ou admin -> utilisateur)"""
    message_id = str(uuid.uuid4())
    
    # Déterminer si c'est un admin qui envoie
    is_admin = user.subscription_tier == 'vip'
    
    message_data = {
        "message_id": message_id,
        "sender_id": user.user_id,
        "sender_name": user.name,
        "sender_email": user.email,
        "recipient_id": message.recipient_id if is_admin else "admin",
        "content": message.content,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "read": False,
        "is_from_admin": is_admin
    }
    
    await db.messages.insert_one(message_data)
    
    return {"message_id": message_id, "status": "sent"}

@api_router.get("/messages/inbox")
async def get_inbox(user: User = Depends(get_current_user)):
    """Récupérer mes messages (inbox)"""
    is_admin = user.subscription_tier == 'vip'
    
    if is_admin:
        # Admin voit tous les messages envoyés à "admin"
        messages = await db.messages.find(
            {"recipient_id": "admin"},
            {"_id": 0}
        ).sort("created_at", -1).to_list(100)
    else:
        # Utilisateur voit ses messages avec l'admin
        messages = await db.messages.find(
            {"$or": [
                {"sender_id": user.user_id},
                {"recipient_id": user.user_id}
            ]},
            {"_id": 0}
        ).sort("created_at", -1).to_list(100)
    
    unread_count = sum(1 for m in messages if not m.get("read") and m.get("recipient_id") == user.user_id)
    
    return {"messages": messages, "unread_count": unread_count}

@api_router.get("/messages/conversation/{user_id}")
async def get_conversation(user_id: str, admin: User = Depends(verify_admin)):
    """Admin: Récupérer la conversation avec un utilisateur spécifique"""
    messages = await db.messages.find(
        {"$or": [
            {"sender_id": user_id, "recipient_id": "admin"},
            {"sender_id": admin.user_id, "recipient_id": user_id}
        ]},
        {"_id": 0}
    ).sort("created_at", 1).to_list(100)
    
    # Marquer comme lus
    await db.messages.update_many(
        {"sender_id": user_id, "recipient_id": "admin", "read": False},
        {"$set": {"read": True}}
    )
    
    user = await db.users.find_one({"user_id": user_id}, {"_id": 0})
    
    return {
        "user": {
            "user_id": user_id,
            "name": user.get("name") if user else "Unknown",
            "email": user.get("email") if user else ""
        },
        "messages": messages
    }

@api_router.post("/messages/mark-read/{message_id}")
async def mark_message_read(message_id: str, user: User = Depends(get_current_user)):
    """Marquer un message comme lu"""
    await db.messages.update_one(
        {"message_id": message_id},
        {"$set": {"read": True}}
    )
    return {"status": "marked as read"}

@api_router.get("/admin/messages/unread-count")
async def admin_get_unread_count(admin: User = Depends(verify_admin)):
    """Admin: Compter les messages non lus"""
    count = await db.messages.count_documents({"recipient_id": "admin", "read": False})
    return {"unread_count": count}

@api_router.get("/admin/messages/users-with-messages")
async def admin_get_users_with_messages(admin: User = Depends(verify_admin)):
    """Admin: Liste des utilisateurs qui ont envoyé des messages"""
    pipeline = [
        {"$match": {"recipient_id": "admin"}},
        {"$group": {
            "_id": "$sender_id",
            "sender_name": {"$first": "$sender_name"},
            "sender_email": {"$first": "$sender_email"},
            "message_count": {"$sum": 1},
            "unread_count": {"$sum": {"$cond": ["$read", 0, 1]}},
            "last_message": {"$max": "$created_at"},
            "last_content": {"$last": "$content"}
        }},
        {"$sort": {"last_message": -1}}
    ]
    
    results = await db.messages.aggregate(pipeline).to_list(50)
    
    for r in results:
        r["user_id"] = r.pop("_id")
    
    return {"users": results}


# ==================== RAPPELS D'ENTRAINEMENT ====================

class ReminderCreate(BaseModel):
    workout_id: str
    workout_title: str
    day_of_week: int  # 0=Lundi, 1=Mardi, etc.
    time: str  # Format "HH:MM"
    repeat_weekly: bool = True
    notes: Optional[str] = None

class ReminderUpdate(BaseModel):
    day_of_week: Optional[int] = None
    time: Optional[str] = None
    repeat_weekly: Optional[bool] = None
    is_active: Optional[bool] = None
    notes: Optional[str] = None

@api_router.post("/reminders")
async def create_reminder(reminder: ReminderCreate, user: User = Depends(get_current_user)):
    """Créer un nouveau rappel d'entraînement"""
    reminder_id = str(uuid.uuid4())
    
    reminder_data = {
        "reminder_id": reminder_id,
        "user_id": user.user_id,
        "workout_id": reminder.workout_id,
        "workout_title": reminder.workout_title,
        "day_of_week": reminder.day_of_week,
        "time": reminder.time,
        "repeat_weekly": reminder.repeat_weekly,
        "is_active": True,
        "notes": reminder.notes,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "last_triggered": None
    }
    
    await db.reminders.insert_one(reminder_data)
    
    return {"reminder_id": reminder_id, "message": "Reminder created successfully"}

@api_router.get("/reminders")
async def get_my_reminders(user: User = Depends(get_current_user)):
    """Récupérer tous mes rappels"""
    reminders = await db.reminders.find(
        {"user_id": user.user_id},
        {"_id": 0}
    ).sort("day_of_week", 1).to_list(50)
    
    # Calculer le prochain rappel pour chaque entrée
    days_fr = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"]
    days_en = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    
    for r in reminders:
        r["day_name_fr"] = days_fr[r["day_of_week"]]
        r["day_name_en"] = days_en[r["day_of_week"]]
    
    active_count = sum(1 for r in reminders if r.get("is_active"))
    
    return {
        "reminders": reminders,
        "total_count": len(reminders),
        "active_count": active_count
    }

@api_router.put("/reminders/{reminder_id}")
async def update_reminder(
    reminder_id: str, 
    update: ReminderUpdate, 
    user: User = Depends(get_current_user)
):
    """Mettre à jour un rappel"""
    reminder = await db.reminders.find_one(
        {"reminder_id": reminder_id, "user_id": user.user_id}
    )
    
    if not reminder:
        raise HTTPException(status_code=404, detail="Reminder not found")
    
    update_data = {k: v for k, v in update.model_dump().items() if v is not None}
    
    if update_data:
        await db.reminders.update_one(
            {"reminder_id": reminder_id},
            {"$set": update_data}
        )
    
    return {"message": "Reminder updated successfully"}

@api_router.delete("/reminders/{reminder_id}")
async def delete_reminder(reminder_id: str, user: User = Depends(get_current_user)):
    """Supprimer un rappel"""
    result = await db.reminders.delete_one(
        {"reminder_id": reminder_id, "user_id": user.user_id}
    )
    
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Reminder not found")
    
    return {"message": "Reminder deleted successfully"}

@api_router.get("/reminders/today")
async def get_today_reminders(user: User = Depends(get_current_user)):
    """Récupérer les rappels d'aujourd'hui"""
    today = datetime.now(timezone.utc).weekday()  # 0=Lundi
    
    reminders = await db.reminders.find(
        {"user_id": user.user_id, "day_of_week": today, "is_active": True},
        {"_id": 0}
    ).to_list(10)
    
    return {"reminders": reminders, "count": len(reminders)}

@api_router.get("/reminders/upcoming")
async def get_upcoming_reminders(user: User = Depends(get_current_user)):
    """Récupérer les 7 prochains jours de rappels"""
    now = datetime.now(timezone.utc)
    current_day = now.weekday()
    current_time = now.strftime("%H:%M")
    
    reminders = await db.reminders.find(
        {"user_id": user.user_id, "is_active": True},
        {"_id": 0}
    ).to_list(50)
    
    days_fr = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"]
    days_en = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    
    upcoming = []
    for r in reminders:
        days_until = (r["day_of_week"] - current_day) % 7
        # Si c'est aujourd'hui mais l'heure est passée, c'est dans 7 jours
        if days_until == 0 and r["time"] < current_time:
            days_until = 7
        
        r["days_until"] = days_until
        r["day_name_fr"] = days_fr[r["day_of_week"]]
        r["day_name_en"] = days_en[r["day_of_week"]]
        upcoming.append(r)
    
    # Trier par jours restants puis par heure
    upcoming.sort(key=lambda x: (x["days_until"], x["time"]))
    
    return {"upcoming": upcoming[:10]}

@api_router.post("/reminders/{reminder_id}/toggle")
async def toggle_reminder(reminder_id: str, user: User = Depends(get_current_user)):
    """Activer/Désactiver un rappel"""
    reminder = await db.reminders.find_one(
        {"reminder_id": reminder_id, "user_id": user.user_id}
    )
    
    if not reminder:
        raise HTTPException(status_code=404, detail="Reminder not found")
    
    new_status = not reminder.get("is_active", True)
    
    await db.reminders.update_one(
        {"reminder_id": reminder_id},
        {"$set": {"is_active": new_status}}
    )
    
    return {"is_active": new_status, "message": f"Reminder {'activated' if new_status else 'deactivated'}"}


# ==================== ROUTINES (ÉCHAUFFEMENT & ÉTIREMENTS) ====================

@api_router.get("/routines/{routine_type}")
async def get_routine(routine_type: str, language: str = "en"):
    """Récupérer une routine (warmup ou stretching)"""
    if routine_type not in ["warmup", "stretching"]:
        raise HTTPException(status_code=400, detail="Invalid routine type. Use 'warmup' or 'stretching'")
    
    routine_id = f"{routine_type}_{language}"
    routine = await db.routines.find_one({"routine_id": routine_id}, {"_id": 0})
    
    if not routine:
        # Fallback to English if not found
        routine = await db.routines.find_one({"routine_id": f"{routine_type}_en"}, {"_id": 0})
    
    return routine if routine else {"exercises": [], "title": routine_type.capitalize()}

@api_router.get("/admin/routines")
async def admin_get_all_routines(admin: User = Depends(verify_admin)):
    """Admin: Récupérer toutes les routines"""
    routines = await db.routines.find({}, {"_id": 0}).to_list(10)
    return {"routines": routines}

class RoutineExerciseUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    duration: Optional[str] = None
    image_url: Optional[str] = None
    video_url: Optional[str] = None

@api_router.put("/admin/routines/{routine_id}/exercises/{exercise_index}")
async def admin_update_routine_exercise(
    routine_id: str,
    exercise_index: int,
    update: RoutineExerciseUpdate,
    admin: User = Depends(verify_admin)
):
    """Admin: Mettre à jour un exercice d'une routine"""
    routine = await db.routines.find_one({"routine_id": routine_id})
    if not routine:
        raise HTTPException(status_code=404, detail="Routine not found")
    
    exercises = routine.get("exercises", [])
    if exercise_index < 0 or exercise_index >= len(exercises):
        raise HTTPException(status_code=400, detail="Invalid exercise index")
    
    update_data = {k: v for k, v in update.model_dump().items() if v is not None}
    
    for key, value in update_data.items():
        exercises[exercise_index][key] = value
    
    await db.routines.update_one(
        {"routine_id": routine_id},
        {"$set": {"exercises": exercises}}
    )
    
    return {"message": "Exercise updated successfully"}

class NewRoutineExercise(BaseModel):
    name: str
    description: str
    duration: str
    image_url: Optional[str] = ""
    video_url: Optional[str] = ""

@api_router.post("/admin/routines/{routine_id}/exercises")
async def admin_add_routine_exercise(
    routine_id: str,
    exercise: NewRoutineExercise,
    admin: User = Depends(verify_admin)
):
    """Admin: Ajouter un exercice à une routine"""
    routine = await db.routines.find_one({"routine_id": routine_id})
    if not routine:
        raise HTTPException(status_code=404, detail="Routine not found")
    
    new_exercise = {
        "name": exercise.name,
        "description": exercise.description,
        "duration": exercise.duration,
        "sets": 1,
        "image_url": exercise.image_url or "",
        "video_url": exercise.video_url or ""
    }
    
    await db.routines.update_one(
        {"routine_id": routine_id},
        {"$push": {"exercises": new_exercise}}
    )
    
    return {"message": "Exercise added successfully"}

@api_router.delete("/admin/routines/{routine_id}/exercises/{exercise_index}")
async def admin_delete_routine_exercise(
    routine_id: str,
    exercise_index: int,
    admin: User = Depends(verify_admin)
):
    """Admin: Supprimer un exercice d'une routine"""
    routine = await db.routines.find_one({"routine_id": routine_id})
    if not routine:
        raise HTTPException(status_code=404, detail="Routine not found")
    
    exercises = routine.get("exercises", [])
    if exercise_index < 0 or exercise_index >= len(exercises):
        raise HTTPException(status_code=400, detail="Invalid exercise index")
    
    exercises.pop(exercise_index)
    
    await db.routines.update_one(
        {"routine_id": routine_id},
        {"$set": {"exercises": exercises}}
    )
    
    return {"message": "Exercise deleted successfully"}

# ==================== ROUTINE SESSION TRACKING ====================

@api_router.post("/routine/start")
async def start_routine_session(
    routine_type: str, 
    workout_session_id: Optional[str] = None,
    user: User = Depends(get_current_user)
):
    """Démarrer une session de routine (échauffement ou étirement)"""
    if routine_type not in ["warmup", "stretching"]:
        raise HTTPException(status_code=400, detail="Invalid routine type")
    
    session_id = str(uuid.uuid4())
    
    session_data = {
        "session_id": session_id,
        "user_id": user.user_id,
        "routine_type": routine_type,
        "workout_session_id": workout_session_id,
        "started_at": datetime.now(timezone.utc).isoformat(),
        "ended_at": None,
        "completed": False,
        "duration_seconds": 0
    }
    
    await db.routine_sessions.insert_one(session_data)
    
    return {
        "session_id": session_id,
        "routine_type": routine_type,
        "message": f"{routine_type.capitalize()} session started"
    }

@api_router.post("/routine/end")
async def end_routine_session(
    session_id: str,
    completed: bool = True,
    user: User = Depends(get_current_user)
):
    """Terminer une session de routine"""
    session = await db.routine_sessions.find_one(
        {"session_id": session_id, "user_id": user.user_id}
    )
    
    if not session:
        raise HTTPException(status_code=404, detail="Routine session not found")
    
    started_at = session.get("started_at")
    if isinstance(started_at, str):
        started_at = datetime.fromisoformat(started_at.replace('Z', '+00:00'))
    
    ended_at = datetime.now(timezone.utc)
    duration_seconds = int((ended_at - started_at).total_seconds())
    
    await db.routine_sessions.update_one(
        {"session_id": session_id},
        {"$set": {
            "ended_at": ended_at.isoformat(),
            "completed": completed,
            "duration_seconds": duration_seconds
        }}
    )
    
    return {
        "session_id": session_id,
        "duration_seconds": duration_seconds,
        "duration_formatted": f"{duration_seconds // 60}m {duration_seconds % 60}s",
        "completed": completed
    }

# ==================== EMAIL REMINDERS ====================

async def send_reminder_email(user_email: str, user_name: str, workout_title: str, reminder_time: str, day_name: str):
    """Envoyer un email de rappel"""
    try:
        html_content = f"""
        <html>
        <body style="font-family: Arial, sans-serif; background-color: #09090b; color: white; padding: 20px;">
            <div style="max-width: 600px; margin: 0 auto; background-color: #121212; border-radius: 10px; padding: 30px;">
                <h1 style="color: #EF4444; text-align: center;">FitMaxPro</h1>
                <h2 style="text-align: center;">Rappel d'Entraînement</h2>
                
                <p style="font-size: 18px;">Bonjour {user_name},</p>
                
                <p>C'est l'heure de votre séance !</p>
                
                <div style="background-color: #1a1a1a; border-radius: 8px; padding: 20px; margin: 20px 0; border-left: 4px solid #EF4444;">
                    <h3 style="margin: 0 0 10px 0; color: #EF4444;">{workout_title}</h3>
                    <p style="margin: 5px 0; color: #888;">📅 {day_name}</p>
                    <p style="margin: 5px 0; color: #888;">⏰ {reminder_time}</p>
                </div>
                
                <div style="text-align: center; margin-top: 30px;">
                    <a href="{APP_URL}/workouts" style="background-color: #EF4444; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; font-weight: bold;">
                        COMMENCER LA SÉANCE
                    </a>
                </div>
                
                <p style="color: #666; font-size: 12px; text-align: center; margin-top: 30px;">
                    FitMaxPro - Transformez votre corps<br>
                    Pour désactiver ces rappels, rendez-vous dans l'application.
                </p>
            </div>
        </body>
        </html>
        """
        
        params = {
            "from": SENDER_EMAIL,
            "to": [user_email],
            "subject": f"⏰ Rappel: {workout_title} - {day_name} {reminder_time}",
            "html": html_content
        }
        
        email = resend.Emails.send(params)
        return {"success": True, "email_id": email.get("id")}
    except Exception as e:
        logging.error(f"Error sending email: {e}")
        return {"success": False, "error": str(e)}

@api_router.post("/reminders/{reminder_id}/send-email")
async def send_reminder_email_now(reminder_id: str, user: User = Depends(get_current_user)):
    """Envoyer un email de rappel maintenant (test)"""
    reminder = await db.reminders.find_one(
        {"reminder_id": reminder_id, "user_id": user.user_id}
    )
    
    if not reminder:
        raise HTTPException(status_code=404, detail="Reminder not found")
    
    days_en = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    day_name = days_en[reminder.get("day_of_week", 0)]
    
    result = await send_reminder_email(
        user_email=user.email,
        user_name=user.name,
        workout_title=reminder.get("workout_title", "Workout"),
        reminder_time=reminder.get("time", "08:00"),
        day_name=day_name
    )
    
    if result.get("success"):
        return {"message": "Email sent successfully", "email_id": result.get("email_id")}
    else:
        raise HTTPException(status_code=500, detail=f"Failed to send email: {result.get('error')}")

@api_router.put("/reminders/{reminder_id}/email-settings")
async def update_reminder_email_settings(
    reminder_id: str, 
    send_email: bool,
    user: User = Depends(get_current_user)
):
    """Activer/Désactiver les emails pour un rappel"""
    reminder = await db.reminders.find_one(
        {"reminder_id": reminder_id, "user_id": user.user_id}
    )
    
    if not reminder:
        raise HTTPException(status_code=404, detail="Reminder not found")
    
    await db.reminders.update_one(
        {"reminder_id": reminder_id},
        {"$set": {"send_email": send_email}}
    )
    
    return {"message": f"Email notifications {'enabled' if send_email else 'disabled'}"}


# ==================== ADMIN ROUTINE SESSIONS TRACKING ====================

@api_router.get("/admin/routine-sessions")
async def admin_get_all_routine_sessions(admin: User = Depends(verify_admin)):
    """Admin: Récupérer toutes les sessions d'échauffement et d'étirements"""
    sessions = await db.routine_sessions.find({}, {"_id": 0}).sort("started_at", -1).to_list(500)
    
    # Enrichir avec les informations utilisateur
    enriched_sessions = []
    for session in sessions:
        user = await db.users.find_one({"user_id": session.get("user_id")}, {"_id": 0, "name": 1, "email": 1})
        enriched_sessions.append({
            **session,
            "user_name": user.get("name", "Unknown") if user else "Unknown",
            "user_email": user.get("email", "") if user else ""
        })
    
    return {"routine_sessions": enriched_sessions}

@api_router.get("/admin/routine-sessions/stats")
async def admin_get_routine_stats(admin: User = Depends(verify_admin)):
    """Admin: Statistiques globales des échauffements et étirements"""
    # Total sessions
    total_warmup = await db.routine_sessions.count_documents({"routine_type": "warmup"})
    total_stretching = await db.routine_sessions.count_documents({"routine_type": "stretching"})
    
    # Completed sessions
    completed_warmup = await db.routine_sessions.count_documents({"routine_type": "warmup", "completed": True})
    completed_stretching = await db.routine_sessions.count_documents({"routine_type": "stretching", "completed": True})
    
    # Average duration
    warmup_pipeline = [
        {"$match": {"routine_type": "warmup", "completed": True, "duration_seconds": {"$gt": 0}}},
        {"$group": {"_id": None, "avg_duration": {"$avg": "$duration_seconds"}}}
    ]
    stretching_pipeline = [
        {"$match": {"routine_type": "stretching", "completed": True, "duration_seconds": {"$gt": 0}}},
        {"$group": {"_id": None, "avg_duration": {"$avg": "$duration_seconds"}}}
    ]
    
    warmup_avg = await db.routine_sessions.aggregate(warmup_pipeline).to_list(1)
    stretching_avg = await db.routine_sessions.aggregate(stretching_pipeline).to_list(1)
    
    # Users with most completed routines (discipline score)
    discipline_pipeline = [
        {"$match": {"completed": True}},
        {"$group": {
            "_id": "$user_id",
            "total_completed": {"$sum": 1},
            "warmup_count": {"$sum": {"$cond": [{"$eq": ["$routine_type", "warmup"]}, 1, 0]}},
            "stretching_count": {"$sum": {"$cond": [{"$eq": ["$routine_type", "stretching"]}, 1, 0]}},
            "total_time": {"$sum": "$duration_seconds"}
        }},
        {"$sort": {"total_completed": -1}},
        {"$limit": 10}
    ]
    
    top_disciplined = await db.routine_sessions.aggregate(discipline_pipeline).to_list(10)
    
    # Enrich with user names
    for entry in top_disciplined:
        user = await db.users.find_one({"user_id": entry["_id"]}, {"name": 1, "email": 1})
        entry["user_name"] = user.get("name", "Unknown") if user else "Unknown"
        entry["user_email"] = user.get("email", "") if user else ""
    
    return {
        "warmup": {
            "total": total_warmup,
            "completed": completed_warmup,
            "completion_rate": round((completed_warmup / total_warmup * 100), 1) if total_warmup > 0 else 0,
            "avg_duration_seconds": round(warmup_avg[0]["avg_duration"], 0) if warmup_avg else 0
        },
        "stretching": {
            "total": total_stretching,
            "completed": completed_stretching,
            "completion_rate": round((completed_stretching / total_stretching * 100), 1) if total_stretching > 0 else 0,
            "avg_duration_seconds": round(stretching_avg[0]["avg_duration"], 0) if stretching_avg else 0
        },
        "top_disciplined_users": top_disciplined
    }

@api_router.get("/admin/user/{user_id}/routine-sessions")
async def admin_get_user_routine_sessions(user_id: str, admin: User = Depends(verify_admin)):
    """Admin: Récupérer les sessions d'échauffement et d'étirements d'un utilisateur"""
    sessions = await db.routine_sessions.find(
        {"user_id": user_id}, 
        {"_id": 0}
    ).sort("started_at", -1).to_list(100)
    
    user = await db.users.find_one({"user_id": user_id}, {"_id": 0, "name": 1, "email": 1})
    
    # Calculer les statistiques
    warmup_sessions = [s for s in sessions if s.get("routine_type") == "warmup"]
    stretching_sessions = [s for s in sessions if s.get("routine_type") == "stretching"]
    
    warmup_completed = len([s for s in warmup_sessions if s.get("completed")])
    stretching_completed = len([s for s in stretching_sessions if s.get("completed")])
    
    total_warmup_time = sum(s.get("duration_seconds", 0) for s in warmup_sessions if s.get("completed"))
    total_stretching_time = sum(s.get("duration_seconds", 0) for s in stretching_sessions if s.get("completed"))
    
    # Score de discipline (% de séances complétées avec échauffement ET étirements)
    workout_sessions = await db.workout_sessions.find({"user_id": user_id, "completed": True}).to_list(100)
    total_workouts = len(workout_sessions)
    
    discipline_score = 0
    if total_workouts > 0:
        # Un utilisateur discipliné fait échauffement + étirements pour chaque séance
        discipline_score = min(100, round((warmup_completed + stretching_completed) / (total_workouts * 2) * 100, 1))
    
    return {
        "user": user,
        "sessions": sessions,
        "stats": {
            "warmup": {
                "total": len(warmup_sessions),
                "completed": warmup_completed,
                "total_time_seconds": total_warmup_time
            },
            "stretching": {
                "total": len(stretching_sessions),
                "completed": stretching_completed,
                "total_time_seconds": total_stretching_time
            },
            "discipline_score": discipline_score,
            "total_workouts": total_workouts
        }
    }

@api_router.get("/admin/analytics/evolution")
async def admin_get_evolution_data(admin: User = Depends(verify_admin)):
    """Admin: Données d'évolution pour les graphiques (7 derniers jours)"""
    from datetime import timedelta
    
    # Get last 7 days
    end_date = datetime.now(timezone.utc)
    start_date = end_date - timedelta(days=7)
    
    # Aggregate workout sessions by day
    workout_pipeline = [
        {"$match": {"started_at": {"$gte": start_date.isoformat()}}},
        {"$addFields": {
            "date": {"$dateToString": {"format": "%Y-%m-%d", "date": {"$dateFromString": {"dateString": "$started_at"}}}}
        }},
        {"$group": {
            "_id": "$date",
            "total_sessions": {"$sum": 1},
            "completed_sessions": {"$sum": {"$cond": ["$completed", 1, 0]}},
            "total_duration": {"$sum": "$duration_seconds"}
        }},
        {"$sort": {"_id": 1}}
    ]
    
    workout_data = await db.workout_sessions.aggregate(workout_pipeline).to_list(30)
    
    # Aggregate routine sessions by day
    routine_pipeline = [
        {"$match": {"started_at": {"$gte": start_date.isoformat()}}},
        {"$addFields": {
            "date": {"$dateToString": {"format": "%Y-%m-%d", "date": {"$dateFromString": {"dateString": "$started_at"}}}}
        }},
        {"$group": {
            "_id": {"date": "$date", "type": "$routine_type"},
            "total": {"$sum": 1},
            "completed": {"$sum": {"$cond": ["$completed", 1, 0]}}
        }},
        {"$sort": {"_id.date": 1}}
    ]
    
    routine_data = await db.routine_sessions.aggregate(routine_pipeline).to_list(60)
    
    # Format data for charts
    days = []
    for i in range(7):
        day = (start_date + timedelta(days=i+1)).strftime("%Y-%m-%d")
        day_name = (start_date + timedelta(days=i+1)).strftime("%a")
        
        workout_day = next((w for w in workout_data if w["_id"] == day), None)
        warmup_day = next((r for r in routine_data if r["_id"]["date"] == day and r["_id"]["type"] == "warmup"), None)
        stretching_day = next((r for r in routine_data if r["_id"]["date"] == day and r["_id"]["type"] == "stretching"), None)
        
        days.append({
            "date": day,
            "day": day_name,
            "workouts": workout_day["total_sessions"] if workout_day else 0,
            "workouts_completed": workout_day["completed_sessions"] if workout_day else 0,
            "warmups": warmup_day["total"] if warmup_day else 0,
            "warmups_completed": warmup_day["completed"] if warmup_day else 0,
            "stretching": stretching_day["total"] if stretching_day else 0,
            "stretching_completed": stretching_day["completed"] if stretching_day else 0,
            "duration_minutes": round(workout_day["total_duration"] / 60, 1) if workout_day else 0
        })
    
    return {"evolution": days}

@api_router.get("/admin/user/{user_id}/evolution")
async def admin_get_user_evolution(user_id: str, admin: User = Depends(verify_admin)):
    """Admin: Données d'évolution d'un utilisateur spécifique"""
    from datetime import timedelta
    
    end_date = datetime.now(timezone.utc)
    start_date = end_date - timedelta(days=30)
    
    user = await db.users.find_one({"user_id": user_id}, {"_id": 0, "name": 1, "email": 1})
    
    # Get all workout sessions for this user
    workout_sessions = await db.workout_sessions.find({
        "user_id": user_id,
        "started_at": {"$gte": start_date.isoformat()}
    }, {"_id": 0}).sort("started_at", 1).to_list(100)
    
    # Get all routine sessions for this user
    routine_sessions = await db.routine_sessions.find({
        "user_id": user_id,
        "started_at": {"$gte": start_date.isoformat()}
    }, {"_id": 0}).sort("started_at", 1).to_list(200)
    
    # Aggregate by week
    weeks_data = {}
    for session in workout_sessions:
        date = datetime.fromisoformat(session["started_at"].replace('Z', '+00:00'))
        week_start = (date - timedelta(days=date.weekday())).strftime("%Y-%m-%d")
        
        if week_start not in weeks_data:
            weeks_data[week_start] = {
                "week": week_start,
                "workouts": 0,
                "workouts_completed": 0,
                "warmups": 0,
                "warmups_completed": 0,
                "stretching": 0,
                "stretching_completed": 0,
                "total_duration": 0,
                "discipline_score": 0
            }
        
        weeks_data[week_start]["workouts"] += 1
        if session.get("completed"):
            weeks_data[week_start]["workouts_completed"] += 1
            weeks_data[week_start]["total_duration"] += session.get("duration_seconds", 0)
    
    for session in routine_sessions:
        date = datetime.fromisoformat(session["started_at"].replace('Z', '+00:00'))
        week_start = (date - timedelta(days=date.weekday())).strftime("%Y-%m-%d")
        
        if week_start not in weeks_data:
            weeks_data[week_start] = {
                "week": week_start,
                "workouts": 0,
                "workouts_completed": 0,
                "warmups": 0,
                "warmups_completed": 0,
                "stretching": 0,
                "stretching_completed": 0,
                "total_duration": 0,
                "discipline_score": 0
            }
        
        if session.get("routine_type") == "warmup":
            weeks_data[week_start]["warmups"] += 1
            if session.get("completed"):
                weeks_data[week_start]["warmups_completed"] += 1
        else:
            weeks_data[week_start]["stretching"] += 1
            if session.get("completed"):
                weeks_data[week_start]["stretching_completed"] += 1
    
    # Calculate discipline score per week
    for week in weeks_data.values():
        if week["workouts_completed"] > 0:
            week["discipline_score"] = min(100, round(
                (week["warmups_completed"] + week["stretching_completed"]) / (week["workouts_completed"] * 2) * 100, 1
            ))
        week["total_duration"] = round(week["total_duration"] / 60, 1)  # Convert to minutes
    
    return {
        "user": user,
        "evolution": sorted(weeks_data.values(), key=lambda x: x["week"])
    }

@api_router.get("/admin/workout/{workout_id}/analytics")
async def admin_get_workout_analytics(workout_id: str, admin: User = Depends(verify_admin)):
    """Admin: Analytiques détaillées d'une séance spécifique"""
    workout = await db.workouts.find_one({"workout_id": workout_id}, {"_id": 0})
    if not workout:
        raise HTTPException(status_code=404, detail="Workout not found")
    
    # Get all sessions for this workout
    sessions = await db.workout_sessions.find(
        {"workout_id": workout_id}, 
        {"_id": 0}
    ).sort("started_at", -1).to_list(200)
    
    # Aggregate stats
    total_sessions = len(sessions)
    completed_sessions = len([s for s in sessions if s.get("completed")])
    total_duration = sum(s.get("duration_seconds", 0) for s in sessions if s.get("completed"))
    avg_duration = round(total_duration / completed_sessions, 0) if completed_sessions > 0 else 0
    
    # Users who did this workout
    user_ids = list(set(s.get("user_id") for s in sessions))
    users_stats = []
    
    for uid in user_ids[:20]:  # Limit to 20 users
        user = await db.users.find_one({"user_id": uid}, {"_id": 0, "name": 1, "email": 1})
        user_sessions = [s for s in sessions if s.get("user_id") == uid]
        user_completed = len([s for s in user_sessions if s.get("completed")])
        user_duration = sum(s.get("duration_seconds", 0) for s in user_sessions if s.get("completed"))
        
        users_stats.append({
            "user_id": uid,
            "name": user.get("name", "Unknown") if user else "Unknown",
            "email": user.get("email", "") if user else "",
            "total_sessions": len(user_sessions),
            "completed": user_completed,
            "total_duration_minutes": round(user_duration / 60, 1)
        })
    
    # Sort by completed sessions
    users_stats.sort(key=lambda x: x["completed"], reverse=True)
    
    return {
        "workout": {
            "workout_id": workout_id,
            "title": workout.get("title", ""),
            "level": workout.get("level", ""),
            "duration": workout.get("duration", 0)
        },
        "stats": {
            "total_sessions": total_sessions,
            "completed_sessions": completed_sessions,
            "completion_rate": round(completed_sessions / total_sessions * 100, 1) if total_sessions > 0 else 0,
            "avg_duration_seconds": avg_duration,
            "total_duration_minutes": round(total_duration / 60, 1)
        },
        "users": users_stats,
        "recent_sessions": sessions[:20]
    }


# ==================== USER EVOLUTION (FOR SUBSCRIBERS) ====================

@api_router.get("/user/evolution")
async def get_user_evolution(current_user: User = Depends(get_current_user)):
    """Get current user's evolution data for personal dashboard"""
    from datetime import timedelta
    
    user_id = current_user.user_id
    end_date = datetime.now(timezone.utc)
    start_date = end_date - timedelta(days=30)
    
    # Get workout sessions
    workout_sessions = await db.workout_sessions.find({
        "user_id": user_id,
        "started_at": {"$gte": start_date.isoformat()}
    }, {"_id": 0}).sort("started_at", 1).to_list(100)
    
    # Get routine sessions
    routine_sessions = await db.routine_sessions.find({
        "user_id": user_id,
        "started_at": {"$gte": start_date.isoformat()}
    }, {"_id": 0}).sort("started_at", 1).to_list(200)
    
    # Daily data for last 7 days
    daily_data = []
    for i in range(7):
        day = (end_date - timedelta(days=6-i)).strftime("%Y-%m-%d")
        day_name = (end_date - timedelta(days=6-i)).strftime("%a")
        
        day_workouts = [s for s in workout_sessions if s.get("started_at", "").startswith(day)]
        day_warmups = [s for s in routine_sessions if s.get("started_at", "").startswith(day) and s.get("routine_type") == "warmup"]
        day_stretching = [s for s in routine_sessions if s.get("started_at", "").startswith(day) and s.get("routine_type") == "stretching"]
        
        daily_data.append({
            "date": day,
            "day": day_name,
            "workouts": len([s for s in day_workouts if s.get("completed")]),
            "warmups": len([s for s in day_warmups if s.get("completed")]),
            "stretching": len([s for s in day_stretching if s.get("completed")]),
            "duration_minutes": round(sum(s.get("duration_seconds", 0) for s in day_workouts if s.get("completed")) / 60, 1)
        })
    
    # Weekly data for last 4 weeks
    weekly_data = []
    for week_num in range(4):
        week_start = end_date - timedelta(days=(3-week_num)*7 + end_date.weekday())
        week_end = week_start + timedelta(days=7)
        week_label = f"Sem {week_num + 1}"
        
        week_workouts = [s for s in workout_sessions 
                        if week_start.strftime("%Y-%m-%d") <= s.get("started_at", "")[:10] < week_end.strftime("%Y-%m-%d")]
        week_warmups = [s for s in routine_sessions 
                       if week_start.strftime("%Y-%m-%d") <= s.get("started_at", "")[:10] < week_end.strftime("%Y-%m-%d") 
                       and s.get("routine_type") == "warmup"]
        week_stretching = [s for s in routine_sessions 
                          if week_start.strftime("%Y-%m-%d") <= s.get("started_at", "")[:10] < week_end.strftime("%Y-%m-%d")
                          and s.get("routine_type") == "stretching"]
        
        completed_workouts = len([s for s in week_workouts if s.get("completed")])
        completed_warmups = len([s for s in week_warmups if s.get("completed")])
        completed_stretching = len([s for s in week_stretching if s.get("completed")])
        
        discipline_score = 0
        if completed_workouts > 0:
            discipline_score = min(100, round((completed_warmups + completed_stretching) / (completed_workouts * 2) * 100, 1))
        
        weekly_data.append({
            "week": week_label,
            "workouts": completed_workouts,
            "warmups": completed_warmups,
            "stretching": completed_stretching,
            "discipline_score": discipline_score,
            "duration_minutes": round(sum(s.get("duration_seconds", 0) for s in week_workouts if s.get("completed")) / 60, 1)
        })
    
    # Overall stats
    total_workouts = len([s for s in workout_sessions if s.get("completed")])
    total_warmups = len([s for s in routine_sessions if s.get("completed") and s.get("routine_type") == "warmup"])
    total_stretching = len([s for s in routine_sessions if s.get("completed") and s.get("routine_type") == "stretching"])
    total_duration = sum(s.get("duration_seconds", 0) for s in workout_sessions if s.get("completed"))
    
    overall_discipline = 0
    if total_workouts > 0:
        overall_discipline = min(100, round((total_warmups + total_stretching) / (total_workouts * 2) * 100, 1))
    
    # Streak calculation
    streak = 0
    for i in range(30):
        day = (end_date - timedelta(days=i)).strftime("%Y-%m-%d")
        day_has_workout = any(s.get("started_at", "").startswith(day) and s.get("completed") for s in workout_sessions)
        if day_has_workout:
            streak += 1
        else:
            break
    
    return {
        "daily": daily_data,
        "weekly": weekly_data,
        "stats": {
            "total_workouts": total_workouts,
            "total_warmups": total_warmups,
            "total_stretching": total_stretching,
            "total_duration_minutes": round(total_duration / 60, 1),
            "discipline_score": overall_discipline,
            "current_streak": streak
        }
    }


# ==================== ADMIN: ALL SUBSCRIBERS EVOLUTION ====================

@api_router.get("/admin/all-subscribers-evolution")
async def admin_get_all_subscribers_evolution(admin: User = Depends(verify_admin)):
    """Admin: Get evolution data for all subscribers"""
    from datetime import timedelta
    
    end_date = datetime.now(timezone.utc)
    start_date = end_date - timedelta(days=30)
    
    # Get all users with subscription
    users = await db.users.find(
        {"subscription": {"$exists": True, "$ne": None}},
        {"_id": 0, "user_id": 1, "name": 1, "email": 1, "subscription": 1}
    ).to_list(100)
    
    subscribers_data = []
    
    for user in users:
        user_id = user.get("user_id")
        
        # Get last activity
        last_workout = await db.workout_sessions.find_one(
            {"user_id": user_id},
            {"_id": 0, "started_at": 1}
        , sort=[("started_at", -1)])
        
        # Count sessions
        workout_count = await db.workout_sessions.count_documents({
            "user_id": user_id,
            "completed": True,
            "started_at": {"$gte": start_date.isoformat()}
        })
        
        warmup_count = await db.routine_sessions.count_documents({
            "user_id": user_id,
            "routine_type": "warmup",
            "completed": True,
            "started_at": {"$gte": start_date.isoformat()}
        })
        
        stretching_count = await db.routine_sessions.count_documents({
            "user_id": user_id,
            "routine_type": "stretching",
            "completed": True,
            "started_at": {"$gte": start_date.isoformat()}
        })
        
        # Calculate discipline score
        discipline_score = 0
        if workout_count > 0:
            discipline_score = min(100, round((warmup_count + stretching_count) / (workout_count * 2) * 100, 1))
        
        # Calculate days since last activity
        days_inactive = 999
        if last_workout:
            last_date = datetime.fromisoformat(last_workout["started_at"].replace('Z', '+00:00'))
            days_inactive = (end_date - last_date).days
        
        subscribers_data.append({
            "user_id": user_id,
            "name": user.get("name", "Unknown"),
            "email": user.get("email", ""),
            "subscription": user.get("subscription", {}).get("plan", "none"),
            "workouts_30d": workout_count,
            "warmups_30d": warmup_count,
            "stretching_30d": stretching_count,
            "discipline_score": discipline_score,
            "days_inactive": days_inactive,
            "last_activity": last_workout.get("started_at") if last_workout else None,
            "status": "active" if days_inactive <= 3 else "warning" if days_inactive <= 7 else "inactive"
        })
    
    # Sort by days inactive (most inactive first)
    subscribers_data.sort(key=lambda x: (-x["days_inactive"] if x["days_inactive"] < 999 else 0, -x["discipline_score"]))
    
    return {"subscribers": subscribers_data}


# ==================== AUTOMATIC INACTIVITY ALERTS ====================

@api_router.post("/admin/send-inactivity-alerts")
async def admin_send_inactivity_alerts(
    days_threshold: int = 3,
    admin: User = Depends(verify_admin)
):
    """Admin: Send email alerts to inactive subscribers"""
    from datetime import timedelta
    
    end_date = datetime.now(timezone.utc)
    threshold_date = end_date - timedelta(days=days_threshold)
    
    # Get all active subscribers
    users = await db.users.find(
        {"subscription": {"$exists": True, "$ne": None}},
        {"_id": 0, "user_id": 1, "name": 1, "email": 1}
    ).to_list(100)
    
    sent_count = 0
    failed_count = 0
    already_sent = 0
    
    for user in users:
        user_id = user.get("user_id")
        user_email = user.get("email")
        user_name = user.get("name", "Membre")
        
        # Check last workout
        last_workout = await db.workout_sessions.find_one(
            {"user_id": user_id},
            {"_id": 0, "started_at": 1}
        , sort=[("started_at", -1)])
        
        # If no workout or last workout is older than threshold
        should_alert = False
        days_inactive = 0
        
        if not last_workout:
            should_alert = True
            days_inactive = 30  # Assume very inactive
        else:
            last_date = datetime.fromisoformat(last_workout["started_at"].replace('Z', '+00:00'))
            days_inactive = (end_date - last_date).days
            if days_inactive >= days_threshold:
                should_alert = True
        
        if should_alert:
            # Check if we already sent an alert recently (within 3 days)
            recent_alert = await db.inactivity_alerts.find_one({
                "user_id": user_id,
                "sent_at": {"$gte": (end_date - timedelta(days=3)).isoformat()}
            })
            
            if recent_alert:
                already_sent += 1
                continue
            
            # Send email
            try:
                email_html = f"""
                <!DOCTYPE html>
                <html>
                <head>
                    <style>
                        body {{ font-family: Arial, sans-serif; background-color: #09090b; color: #ffffff; padding: 20px; }}
                        .container {{ max-width: 600px; margin: 0 auto; background: #121212; border-radius: 12px; padding: 30px; }}
                        .header {{ text-align: center; margin-bottom: 30px; }}
                        .logo {{ font-size: 28px; font-weight: bold; color: #EF4444; }}
                        .message {{ font-size: 16px; line-height: 1.6; color: #d1d5db; }}
                        .highlight {{ color: #EF4444; font-weight: bold; }}
                        .cta-button {{ display: inline-block; background: linear-gradient(to right, #EF4444, #DC2626); color: white; padding: 15px 30px; border-radius: 8px; text-decoration: none; font-weight: bold; margin: 20px 0; }}
                        .stats {{ background: #1a1a1a; border-radius: 8px; padding: 20px; margin: 20px 0; }}
                        .footer {{ text-align: center; color: #6b7280; font-size: 12px; margin-top: 30px; }}
                    </style>
                </head>
                <body>
                    <div class="container">
                        <div class="header">
                            <div class="logo">FITMAXPRO</div>
                        </div>
                        <div class="message">
                            <p>Salut <strong>{user_name}</strong> 👋</p>
                            <p>Nous avons remarqué que tu n'as pas fait d'entraînement depuis <span class="highlight">{days_inactive} jours</span>.</p>
                            <p>Ton corps a besoin de bouger ! Même 15 minutes d'exercice peuvent faire une grande différence. 💪</p>
                            <div class="stats">
                                <p>🔥 <strong>Rappel :</strong> La régularité est la clé du succès !</p>
                                <p>📈 Ne laisse pas ta progression s'arrêter maintenant.</p>
                            </div>
                            <p style="text-align: center;">
                                <a href="{BACKEND_URL.replace('/api', '')}/workouts" class="cta-button">
                                    Reprendre l'entraînement
                                </a>
                            </p>
                            <p>Ton coach est là pour t'aider. N'hésite pas à lui envoyer un message si tu as besoin de conseils !</p>
                        </div>
                        <div class="footer">
                            <p>© 2026 FitMaxPro - Ton partenaire fitness</p>
                        </div>
                    </div>
                </body>
                </html>
                """
                
                email_response = resend.Emails.send({
                    "from": f"FitMaxPro <{os.environ.get('SENDER_EMAIL', 'onboarding@resend.dev')}>",
                    "to": [user_email],
                    "subject": f"💪 {user_name}, tu nous manques ! Reprends ton entraînement",
                    "html": email_html
                })
                
                # Log the alert
                await db.inactivity_alerts.insert_one({
                    "user_id": user_id,
                    "user_email": user_email,
                    "days_inactive": days_inactive,
                    "sent_at": end_date.isoformat(),
                    "email_id": email_response.get("id")
                })
                
                sent_count += 1
                
            except Exception as e:
                print(f"Failed to send alert to {user_email}: {e}")
                failed_count += 1
    
    return {
        "message": f"Alertes envoyées",
        "sent": sent_count,
        "failed": failed_count,
        "already_sent_recently": already_sent,
        "threshold_days": days_threshold
    }

@api_router.get("/admin/inactivity-alerts")
async def admin_get_inactivity_alerts(admin: User = Depends(verify_admin)):
    """Admin: Get history of inactivity alerts sent"""
    alerts = await db.inactivity_alerts.find(
        {},
        {"_id": 0}
    ).sort("sent_at", -1).to_list(100)
    
    return {"alerts": alerts}


# ==================== REVIEWS/AVIS SYSTEM ====================

class ReviewCreate(BaseModel):
    rating: int  # 1-5 stars
    title: str
    content: str
    is_public: bool = True

@api_router.post("/reviews")
async def create_review(review: ReviewCreate, current_user: User = Depends(get_current_user)):
    """Create a new review - Only active subscribers can create reviews"""
    # Vérifier que l'utilisateur a un abonnement actif
    if current_user.subscription_status != "active":
        raise HTTPException(status_code=403, detail="Only active subscribers can leave reviews")
    
    review_data = {
        "review_id": str(uuid.uuid4()),
        "user_id": current_user.user_id,
        "user_name": current_user.name,
        "rating": min(5, max(1, review.rating)),
        "title": review.title,
        "content": review.content,
        "is_public": review.is_public,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "admin_response": None,
        "admin_response_at": None,
        "verified_subscriber": True,  # Marqué comme abonné vérifié
        "subscription_tier": current_user.subscription_tier,
        "likes": [],  # Liste des user_ids qui ont aimé
        "likes_count": 0,
        "admin_liked": False  # Si l'admin a aimé
    }
    await db.reviews.insert_one(review_data)
    
    # Donner des points pour avoir laissé un avis (automatisation des points)
    await add_points(current_user.user_id, 25, "review_created", review_data["review_id"])
    
    return {"message": "Review created", "review_id": review_data["review_id"], "points_earned": 25}

@api_router.get("/reviews")
async def get_public_reviews():
    """Get all public reviews"""
    reviews = await db.reviews.find(
        {"is_public": True},
        {"_id": 0}
    ).sort("created_at", -1).to_list(100)
    
    # Calculate average rating
    all_reviews = await db.reviews.find({}, {"rating": 1}).to_list(1000)
    avg_rating = sum(r.get("rating", 0) for r in all_reviews) / len(all_reviews) if all_reviews else 0
    
    return {
        "reviews": reviews,
        "total_reviews": len(all_reviews),
        "average_rating": round(avg_rating, 1)
    }

@api_router.post("/reviews/{review_id}/like")
async def like_review(review_id: str, current_user: User = Depends(get_current_user)):
    """Like/Unlike a review"""
    review = await db.reviews.find_one({"review_id": review_id})
    if not review:
        raise HTTPException(status_code=404, detail="Review not found")
    
    likes = review.get("likes", [])
    
    if current_user.user_id in likes:
        # Unlike
        likes.remove(current_user.user_id)
        action = "unliked"
    else:
        # Like
        likes.append(current_user.user_id)
        action = "liked"
    
    await db.reviews.update_one(
        {"review_id": review_id},
        {"$set": {"likes": likes, "likes_count": len(likes)}}
    )
    
    return {"message": f"Review {action}", "likes_count": len(likes), "action": action}

@api_router.post("/admin/reviews/{review_id}/like")
async def admin_like_review(review_id: str, admin: User = Depends(verify_admin)):
    """Admin: Like/Unlike a review (special admin like)"""
    review = await db.reviews.find_one({"review_id": review_id})
    if not review:
        raise HTTPException(status_code=404, detail="Review not found")
    
    admin_liked = not review.get("admin_liked", False)
    
    await db.reviews.update_one(
        {"review_id": review_id},
        {"$set": {"admin_liked": admin_liked}}
    )
    
    return {"message": f"Review {'liked by admin' if admin_liked else 'unliked by admin'}", "admin_liked": admin_liked}

@api_router.get("/user/reviews")
async def get_user_reviews(current_user: User = Depends(get_current_user)):
    """Get current user's reviews"""
    reviews = await db.reviews.find(
        {"user_id": current_user.user_id},
        {"_id": 0}
    ).sort("created_at", -1).to_list(50)
    return {"reviews": reviews}

@api_router.get("/admin/reviews")
async def admin_get_all_reviews(admin: User = Depends(verify_admin)):
    """Admin: Get all reviews"""
    reviews = await db.reviews.find({}, {"_id": 0}).sort("created_at", -1).to_list(200)
    
    # Calculate stats
    total = len(reviews)
    avg_rating = sum(r.get("rating", 0) for r in reviews) / total if total else 0
    rating_distribution = {i: len([r for r in reviews if r.get("rating") == i]) for i in range(1, 6)}
    total_likes = sum(r.get("likes_count", 0) for r in reviews)
    
    return {
        "reviews": reviews,
        "stats": {
            "total": total,
            "average_rating": round(avg_rating, 1),
            "distribution": rating_distribution,
            "total_likes": total_likes
        }
    }

@api_router.put("/admin/reviews/{review_id}/respond")
async def admin_respond_to_review(review_id: str, response: str, admin: User = Depends(verify_admin)):
    """Admin: Respond to a review"""
    await db.reviews.update_one(
        {"review_id": review_id},
        {"$set": {
            "admin_response": response,
            "admin_response_at": datetime.now(timezone.utc).isoformat()
        }}
    )
    return {"message": "Response added"}

@api_router.delete("/admin/reviews/{review_id}")
async def admin_delete_review(review_id: str, admin: User = Depends(verify_admin)):
    """Admin: Delete a review"""
    await db.reviews.delete_one({"review_id": review_id})
    return {"message": "Review deleted"}


# ==================== INACTIVE USER ALERTS SYSTEM ====================

class InactiveAlertSettings(BaseModel):
    inactive_days_threshold: int = 7  # Days without activity
    email_enabled: bool = True
    push_enabled: bool = True
    custom_message_fr: Optional[str] = None
    custom_message_en: Optional[str] = None

@api_router.get("/admin/inactive-users")
async def get_inactive_users(days: int = 7, admin: User = Depends(verify_admin)):
    """Admin: Get list of inactive users"""
    threshold_date = datetime.now(timezone.utc) - timedelta(days=days)
    
    # Get all active subscribers
    users = await db.users.find(
        {"subscription_status": "active"},
        {"_id": 0, "password_hash": 0}
    ).to_list(1000)
    
    inactive_users = []
    for user in users:
        # Check last activity (workout, running, login)
        last_workout = await db.workout_history.find_one(
            {"user_id": user["user_id"]},
            sort=[("completed_at", -1)]
        )
        last_run = await db.running_sessions.find_one(
            {"user_id": user["user_id"]},
            sort=[("start_time", -1)]
        )
        last_session = await db.user_sessions.find_one(
            {"user_id": user["user_id"]},
            sort=[("created_at", -1)]
        )
        
        # Find most recent activity
        activities = []
        if last_workout and last_workout.get("completed_at"):
            activities.append(last_workout["completed_at"])
        if last_run and last_run.get("start_time"):
            activities.append(last_run["start_time"])
        if last_session and last_session.get("created_at"):
            activities.append(last_session["created_at"])
        
        if activities:
            # Parse dates and find most recent
            last_activity = None
            for act in activities:
                if isinstance(act, str):
                    act_date = datetime.fromisoformat(act.replace('Z', '+00:00'))
                else:
                    act_date = act
                if act_date.tzinfo is None:
                    act_date = act_date.replace(tzinfo=timezone.utc)
                if last_activity is None or act_date > last_activity:
                    last_activity = act_date
            
            if last_activity < threshold_date:
                days_inactive = (datetime.now(timezone.utc) - last_activity).days
                inactive_users.append({
                    "user_id": user["user_id"],
                    "name": user["name"],
                    "email": user["email"],
                    "subscription_tier": user.get("subscription_tier", "standard"),
                    "last_activity": last_activity.isoformat(),
                    "days_inactive": days_inactive
                })
        else:
            # No activity found at all
            created_at = user.get("created_at")
            if isinstance(created_at, str):
                created_date = datetime.fromisoformat(created_at.replace('Z', '+00:00'))
            else:
                created_date = created_at or datetime.now(timezone.utc)
            
            if created_date.tzinfo is None:
                created_date = created_date.replace(tzinfo=timezone.utc)
            
            if created_date < threshold_date:
                days_inactive = (datetime.now(timezone.utc) - created_date).days
                inactive_users.append({
                    "user_id": user["user_id"],
                    "name": user["name"],
                    "email": user["email"],
                    "subscription_tier": user.get("subscription_tier", "standard"),
                    "last_activity": None,
                    "days_inactive": days_inactive
                })
    
    # Sort by days inactive (most inactive first)
    inactive_users.sort(key=lambda x: x["days_inactive"], reverse=True)
    
    return {
        "inactive_users": inactive_users,
        "total_count": len(inactive_users),
        "threshold_days": days
    }

@api_router.post("/admin/inactive-users/send-reminder")
async def send_inactive_reminder(user_ids: List[str], message_fr: str = None, message_en: str = None, admin: User = Depends(verify_admin)):
    """Admin: Send reminder to inactive users"""
    results = {"sent": 0, "failed": 0, "emails": []}
    
    default_message_fr = "Vous nous manquez ! Revenez sur FitMaxPro pour continuer votre progression. Vos objectifs vous attendent !"
    default_message_en = "We miss you! Come back to FitMaxPro to continue your progress. Your goals are waiting!"
    
    for user_id in user_ids:
        user = await db.users.find_one({"user_id": user_id}, {"_id": 0})
        if user and user.get("email"):
            try:
                # Try to send email via Resend if configured
                resend_api_key = os.environ.get('RESEND_API_KEY')
                if resend_api_key:
                    import resend
                    resend.api_key = resend_api_key
                    
                    # Detect user language preference (default to French)
                    is_french = True  # Could check user preference
                    subject = "On vous attend sur FitMaxPro !" if is_french else "We're waiting for you on FitMaxPro!"
                    message = message_fr or default_message_fr if is_french else message_en or default_message_en
                    
                    html_content = f"""
                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #0a0a0a; color: white; padding: 40px;">
                        <h1 style="color: #EF4444; text-align: center;">FITMAXPRO</h1>
                        <h2 style="text-align: center;">{"Salut" if is_french else "Hey"} {user.get("name", "Champion")} !</h2>
                        <p style="font-size: 16px; line-height: 1.6; text-align: center;">{message}</p>
                        <div style="text-align: center; margin-top: 30px;">
                            <a href="{APP_URL}/dashboard" style="background: #EF4444; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold;">
                                {"Reprendre l'entraînement" if is_french else "Resume Training"}
                            </a>
                        </div>
                        <p style="text-align: center; margin-top: 30px; color: #888; font-size: 12px;">
                            {"L'équipe FitMaxPro" if is_french else "The FitMaxPro Team"}
                        </p>
                    </div>
                    """
                    
                    resend.Emails.send({
                        "from": "FitMaxPro <noreply@fitmax-gains.com>",
                        "to": user["email"],
                        "subject": subject,
                        "html": html_content
                    })
                    results["sent"] += 1
                    results["emails"].append(user["email"])
                else:
                    # Log for manual sending
                    await db.pending_emails.insert_one({
                        "email_id": str(uuid.uuid4()),
                        "to": user["email"],
                        "user_name": user.get("name"),
                        "type": "inactive_reminder",
                        "message_fr": message_fr or default_message_fr,
                        "message_en": message_en or default_message_en,
                        "created_at": datetime.now(timezone.utc).isoformat(),
                        "status": "pending"
                    })
                    results["sent"] += 1
                    results["emails"].append(user["email"])
            except Exception as e:
                print(f"Failed to send email to {user.get('email')}: {e}")
                results["failed"] += 1
    
    return results

@api_router.get("/admin/alert-settings")
async def get_alert_settings(admin: User = Depends(verify_admin)):
    """Get inactive alert settings"""
    settings = await db.settings.find_one({"type": "inactive_alerts"}, {"_id": 0})
    return settings or {
        "type": "inactive_alerts",
        "inactive_days_threshold": 7,
        "email_enabled": True,
        "push_enabled": True,
        "auto_send_enabled": False,
        "custom_message_fr": None,
        "custom_message_en": None
    }

@api_router.put("/admin/alert-settings")
async def update_alert_settings(settings: InactiveAlertSettings, admin: User = Depends(verify_admin)):
    """Update inactive alert settings"""
    await db.settings.update_one(
        {"type": "inactive_alerts"},
        {"$set": {
            "type": "inactive_alerts",
            **settings.dict()
        }},
        upsert=True
    )
    return {"message": "Settings updated"}


# ==================== ANNUAL SUBSCRIPTION LOGIC ====================

@api_router.get("/subscription/can-cancel")
async def check_can_cancel(current_user: User = Depends(get_current_user)):
    """Check if user can cancel their subscription"""
    subscription = await db.subscriptions.find_one(
        {"user_id": current_user.user_id, "status": "active"},
        {"_id": 0}
    )
    
    if not subscription:
        return {"can_cancel": False, "reason": "No active subscription"}
    
    plan_type = subscription.get("plan_type", "monthly")
    
    # Monthly subscriptions can always be cancelled
    if plan_type == "monthly":
        return {
            "can_cancel": True,
            "plan_type": "monthly",
            "message_fr": "Vous pouvez annuler à tout moment",
            "message_en": "You can cancel anytime"
        }
    
    # Annual subscriptions have restrictions
    if plan_type == "annual":
        start_date_str = subscription.get("start_date") or subscription.get("created_at")
        if start_date_str:
            if isinstance(start_date_str, str):
                start_date = datetime.fromisoformat(start_date_str.replace('Z', '+00:00'))
            else:
                start_date = start_date_str
            
            if start_date.tzinfo is None:
                start_date = start_date.replace(tzinfo=timezone.utc)
            
            # Calculate days remaining in commitment
            commitment_end = start_date + timedelta(days=365)
            now = datetime.now(timezone.utc)
            
            if now < commitment_end:
                days_remaining = (commitment_end - now).days
                return {
                    "can_cancel": False,
                    "plan_type": "annual",
                    "commitment_end": commitment_end.isoformat(),
                    "days_remaining": days_remaining,
                    "message_fr": f"Votre engagement annuel se termine dans {days_remaining} jours. L'annulation sera possible après cette date.",
                    "message_en": f"Your annual commitment ends in {days_remaining} days. Cancellation will be possible after this date."
                }
            else:
                return {
                    "can_cancel": True,
                    "plan_type": "annual",
                    "message_fr": "Votre période d'engagement est terminée. Vous pouvez annuler.",
                    "message_en": "Your commitment period has ended. You can cancel."
                }
    
    return {"can_cancel": True, "plan_type": plan_type}

@api_router.post("/subscription/request-cancel")
async def request_subscription_cancel(reason: str = None, current_user: User = Depends(get_current_user)):
    """Request to cancel subscription"""
    can_cancel_response = await check_can_cancel(current_user)
    
    if not can_cancel_response.get("can_cancel"):
        raise HTTPException(
            status_code=400, 
            detail=can_cancel_response.get("message_en", "Cannot cancel subscription at this time")
        )
    
    # Log cancellation request
    await db.cancellation_requests.insert_one({
        "request_id": str(uuid.uuid4()),
        "user_id": current_user.user_id,
        "user_email": current_user.email,
        "reason": reason,
        "plan_type": can_cancel_response.get("plan_type"),
        "created_at": datetime.now(timezone.utc).isoformat(),
        "status": "pending"
    })
    
    # Update subscription status
    await db.subscriptions.update_one(
        {"user_id": current_user.user_id, "status": "active"},
        {"$set": {"status": "pending_cancellation", "cancel_requested_at": datetime.now(timezone.utc).isoformat()}}
    )
    
    return {
        "message": "Cancellation request submitted",
        "message_fr": "Demande d'annulation soumise",
        "message_en": "Cancellation request submitted"
    }

@api_router.get("/admin/cancellation-requests")
async def get_cancellation_requests(admin: User = Depends(verify_admin)):
    """Admin: Get all cancellation requests"""
    requests = await db.cancellation_requests.find(
        {},
        {"_id": 0}
    ).sort("created_at", -1).to_list(100)
    return {"requests": requests}

@api_router.put("/admin/cancellation-requests/{request_id}/process")
async def process_cancellation(request_id: str, action: str, admin: User = Depends(verify_admin)):
    """Admin: Process a cancellation request (approve/reject)"""
    request_doc = await db.cancellation_requests.find_one({"request_id": request_id})
    if not request_doc:
        raise HTTPException(status_code=404, detail="Request not found")
    
    if action == "approve":
        # Cancel the subscription
        await db.subscriptions.update_one(
            {"user_id": request_doc["user_id"]},
            {"$set": {"status": "cancelled", "cancelled_at": datetime.now(timezone.utc).isoformat()}}
        )
        await db.users.update_one(
            {"user_id": request_doc["user_id"]},
            {"$set": {"subscription_status": "inactive", "subscription_tier": "none"}}
        )
        await db.cancellation_requests.update_one(
            {"request_id": request_id},
            {"$set": {"status": "approved", "processed_at": datetime.now(timezone.utc).isoformat()}}
        )
        return {"message": "Subscription cancelled"}
    
    elif action == "reject":
        await db.subscriptions.update_one(
            {"user_id": request_doc["user_id"], "status": "pending_cancellation"},
            {"$set": {"status": "active"}}
        )
        await db.cancellation_requests.update_one(
            {"request_id": request_id},
            {"$set": {"status": "rejected", "processed_at": datetime.now(timezone.utc).isoformat()}}
        )
        return {"message": "Cancellation rejected"}
    
    raise HTTPException(status_code=400, detail="Invalid action")


# ==================== IN-APP PURCHASES PREPARATION (RevenueCat) ====================

class IAPReceipt(BaseModel):
    platform: str  # "ios" or "android"
    receipt_data: str
    product_id: str

class RevenueCatWebhook(BaseModel):
    event: dict
    api_version: str = "1.0"

@api_router.post("/iap/verify-purchase")
async def verify_iap_purchase(receipt: IAPReceipt, current_user: User = Depends(get_current_user)):
    """Verify an in-app purchase receipt via RevenueCat"""
    revenuecat_api_key = os.environ.get('REVENUECAT_API_KEY')
    
    receipt_id = str(uuid.uuid4())
    
    # Store receipt first
    receipt_doc = {
        "receipt_id": receipt_id,
        "user_id": current_user.user_id,
        "platform": receipt.platform,
        "product_id": receipt.product_id,
        "receipt_data": receipt.receipt_data[:500] + "..." if len(receipt.receipt_data) > 500 else receipt.receipt_data,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "status": "pending_verification",
        "verified": False
    }
    await db.iap_receipts.insert_one(receipt_doc)
    
    if not revenuecat_api_key:
        return {
            "status": "pending",
            "receipt_id": receipt_id,
            "message": "Receipt stored - RevenueCat API key not configured",
            "message_fr": "Reçu enregistré - Clé API RevenueCat non configurée",
            "action_required": "Add REVENUECAT_API_KEY to .env file"
        }
    
    # Call RevenueCat API to verify receipt
    try:
        async with httpx.AsyncClient() as client:
            # Create/update subscriber in RevenueCat
            response = await client.post(
                f"https://api.revenuecat.com/v1/receipts",
                headers={
                    "Authorization": f"Bearer {revenuecat_api_key}",
                    "Content-Type": "application/json",
                    "X-Platform": receipt.platform
                },
                json={
                    "app_user_id": current_user.user_id,
                    "fetch_token": receipt.receipt_data,
                    "product_id": receipt.product_id,
                    "is_restore": False
                },
                timeout=30.0
            )
            
            if response.status_code == 200:
                revenuecat_data = response.json()
                subscriber = revenuecat_data.get("subscriber", {})
                entitlements = subscriber.get("entitlements", {})
                
                # Check active entitlements
                active_entitlement = None
                for name, entitlement in entitlements.items():
                    if entitlement.get("expires_date"):
                        expires = datetime.fromisoformat(entitlement["expires_date"].replace("Z", "+00:00"))
                        if expires > datetime.now(timezone.utc):
                            active_entitlement = {
                                "name": name,
                                "expires_date": entitlement["expires_date"],
                                "product_identifier": entitlement.get("product_identifier")
                            }
                            break
                
                if active_entitlement:
                    # Activate subscription
                    tier = "vip" if "vip" in receipt.product_id.lower() else "standard"
                    plan_type = "annual" if "annual" in receipt.product_id.lower() else "monthly"
                    
                    await db.users.update_one(
                        {"user_id": current_user.user_id},
                        {"$set": {
                            "subscription_tier": tier,
                            "subscription_status": "active"
                        }}
                    )
                    
                    await db.subscriptions.update_one(
                        {"user_id": current_user.user_id},
                        {"$set": {
                            "tier": tier,
                            "plan_type": plan_type,
                            "status": "active",
                            "source": "iap",
                            "platform": receipt.platform,
                            "expires_at": active_entitlement["expires_date"],
                            "start_date": datetime.now(timezone.utc).isoformat()
                        }},
                        upsert=True
                    )
                    
                    await db.iap_receipts.update_one(
                        {"receipt_id": receipt_id},
                        {"$set": {
                            "verified": True,
                            "status": "verified",
                            "verified_at": datetime.now(timezone.utc).isoformat(),
                            "revenuecat_response": revenuecat_data
                        }}
                    )
                    
                    return {
                        "status": "success",
                        "receipt_id": receipt_id,
                        "subscription_tier": tier,
                        "expires_at": active_entitlement["expires_date"],
                        "message": "Subscription activated successfully",
                        "message_fr": "Abonnement activé avec succès"
                    }
                else:
                    await db.iap_receipts.update_one(
                        {"receipt_id": receipt_id},
                        {"$set": {"status": "no_active_entitlement", "revenuecat_response": revenuecat_data}}
                    )
                    return {
                        "status": "failed",
                        "receipt_id": receipt_id,
                        "message": "No active subscription found",
                        "message_fr": "Aucun abonnement actif trouvé"
                    }
            else:
                error_detail = response.text
                await db.iap_receipts.update_one(
                    {"receipt_id": receipt_id},
                    {"$set": {"status": "verification_failed", "error": error_detail}}
                )
                return {
                    "status": "failed",
                    "receipt_id": receipt_id,
                    "message": "Receipt verification failed",
                    "message_fr": "Échec de la vérification du reçu"
                }
    except Exception as e:
        await db.iap_receipts.update_one(
            {"receipt_id": receipt_id},
            {"$set": {"status": "error", "error": str(e)}}
        )
        return {
            "status": "error",
            "receipt_id": receipt_id,
            "message": f"Error during verification: {str(e)}",
            "message_fr": f"Erreur lors de la vérification"
        }

@api_router.post("/iap/webhook/revenuecat")
async def revenuecat_webhook(webhook: RevenueCatWebhook):
    """Handle RevenueCat webhook events for subscription status updates"""
    event = webhook.event
    event_type = event.get("type")
    app_user_id = event.get("app_user_id")
    
    # Log webhook
    await db.iap_webhooks.insert_one({
        "webhook_id": str(uuid.uuid4()),
        "event_type": event_type,
        "app_user_id": app_user_id,
        "event_data": event,
        "received_at": datetime.now(timezone.utc).isoformat()
    })
    
    if not app_user_id:
        return {"status": "ok", "message": "No user ID in event"}
    
    # Handle different event types
    if event_type in ["INITIAL_PURCHASE", "RENEWAL", "PRODUCT_CHANGE"]:
        # Subscription activated or renewed
        product_id = event.get("product_id", "")
        tier = "vip" if "vip" in product_id.lower() else "standard"
        plan_type = "annual" if "annual" in product_id.lower() else "monthly"
        expires_at = event.get("expiration_at_ms")
        
        if expires_at:
            expires_at = datetime.fromtimestamp(expires_at / 1000, tz=timezone.utc).isoformat()
        
        await db.users.update_one(
            {"user_id": app_user_id},
            {"$set": {
                "subscription_tier": tier,
                "subscription_status": "active"
            }}
        )
        
        await db.subscriptions.update_one(
            {"user_id": app_user_id},
            {"$set": {
                "tier": tier,
                "plan_type": plan_type,
                "status": "active",
                "source": "iap",
                "expires_at": expires_at,
                "updated_at": datetime.now(timezone.utc).isoformat()
            }},
            upsert=True
        )
        
    elif event_type in ["CANCELLATION", "EXPIRATION"]:
        # Subscription cancelled or expired
        await db.users.update_one(
            {"user_id": app_user_id},
            {"$set": {
                "subscription_tier": "none",
                "subscription_status": "inactive"
            }}
        )
        
        await db.subscriptions.update_one(
            {"user_id": app_user_id},
            {"$set": {
                "status": "cancelled" if event_type == "CANCELLATION" else "expired",
                "ended_at": datetime.now(timezone.utc).isoformat()
            }}
        )
    
    elif event_type == "BILLING_ISSUE":
        # Payment failed - subscription in grace period
        await db.subscriptions.update_one(
            {"user_id": app_user_id},
            {"$set": {
                "status": "grace_period",
                "billing_issue_at": datetime.now(timezone.utc).isoformat()
            }}
        )
    
    return {"status": "ok"}

@api_router.get("/iap/subscription-status")
async def get_iap_subscription_status(current_user: User = Depends(get_current_user)):
    """Get current IAP subscription status from RevenueCat"""
    revenuecat_api_key = os.environ.get('REVENUECAT_API_KEY')
    
    # Get local subscription data
    subscription = await db.subscriptions.find_one(
        {"user_id": current_user.user_id},
        {"_id": 0}
    )
    
    if not revenuecat_api_key:
        return {
            "source": "local",
            "subscription": subscription,
            "message": "RevenueCat not configured - showing local data"
        }
    
    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"https://api.revenuecat.com/v1/subscribers/{current_user.user_id}",
                headers={
                    "Authorization": f"Bearer {revenuecat_api_key}",
                    "Content-Type": "application/json"
                },
                timeout=10.0
            )
            
            if response.status_code == 200:
                revenuecat_data = response.json()
                subscriber = revenuecat_data.get("subscriber", {})
                
                return {
                    "source": "revenuecat",
                    "subscriber": subscriber,
                    "local_subscription": subscription
                }
            else:
                return {
                    "source": "local",
                    "subscription": subscription,
                    "revenuecat_error": response.status_code
                }
    except Exception as e:
        return {
            "source": "local",
            "subscription": subscription,
            "error": str(e)
        }

@api_router.get("/iap/products")
async def get_iap_products():
    """Get available in-app purchase products"""
    return {
        "products": [
            {
                "product_id": "fitmaxpro_standard_monthly",
                "name_fr": "Abonnement Standard Mensuel",
                "name_en": "Standard Monthly Subscription",
                "price_tier": "standard",
                "duration": "monthly",
                "features": ["workouts", "nutrition", "progress_tracking"]
            },
            {
                "product_id": "fitmaxpro_standard_annual",
                "name_fr": "Abonnement Standard Annuel",
                "name_en": "Standard Annual Subscription",
                "price_tier": "standard",
                "duration": "annual",
                "discount_percent": 20,
                "features": ["workouts", "nutrition", "progress_tracking"]
            },
            {
                "product_id": "fitmaxpro_vip_monthly",
                "name_fr": "Abonnement VIP Mensuel",
                "name_en": "VIP Monthly Subscription",
                "price_tier": "vip",
                "duration": "monthly",
                "features": ["all_workouts", "nutrition", "progress_tracking", "coaching", "live_streams", "priority_support"]
            },
            {
                "product_id": "fitmaxpro_vip_annual",
                "name_fr": "Abonnement VIP Annuel",
                "name_en": "VIP Annual Subscription",
                "price_tier": "vip",
                "duration": "annual",
                "discount_percent": 25,
                "features": ["all_workouts", "nutrition", "progress_tracking", "coaching", "live_streams", "priority_support"]
            }
        ]
    }

@api_router.get("/admin/iap-receipts")
async def get_iap_receipts(admin: User = Depends(verify_admin)):
    """Admin: Get all IAP receipts for verification"""
    receipts = await db.iap_receipts.find({}, {"_id": 0}).sort("created_at", -1).to_list(100)
    return {"receipts": receipts}

@api_router.put("/admin/iap-receipts/{receipt_id}/verify")
async def manual_verify_receipt(receipt_id: str, verified: bool, admin: User = Depends(verify_admin)):
    """Admin: Manually verify an IAP receipt"""
    receipt = await db.iap_receipts.find_one({"receipt_id": receipt_id})
    if not receipt:
        raise HTTPException(status_code=404, detail="Receipt not found")
    
    await db.iap_receipts.update_one(
        {"receipt_id": receipt_id},
        {"$set": {
            "verified": verified,
            "status": "verified" if verified else "rejected",
            "verified_at": datetime.now(timezone.utc).isoformat(),
            "verified_by": admin.user_id
        }}
    )
    
    if verified:
        # Activate subscription based on product_id
        product_id = receipt.get("product_id", "")
        tier = "vip" if "vip" in product_id else "standard"
        plan_type = "annual" if "annual" in product_id else "monthly"
        
        await db.users.update_one(
            {"user_id": receipt["user_id"]},
            {"$set": {
                "subscription_tier": tier,
                "subscription_status": "active"
            }}
        )
        
        await db.subscriptions.update_one(
            {"user_id": receipt["user_id"]},
            {"$set": {
                "user_id": receipt["user_id"],
                "tier": tier,
                "plan_type": plan_type,
                "status": "active",
                "source": "iap",
                "start_date": datetime.now(timezone.utc).isoformat()
            }},
            upsert=True
        )
    
    return {"message": "Receipt verified" if verified else "Receipt rejected"}


# ==================== WEEKLY MOTIVATION EMAILS ====================

class WeeklyEmailSettings(BaseModel):
    enabled: bool = True
    send_day: str = "monday"  # day of the week
    include_running_stats: bool = True
    include_workout_stats: bool = True
    include_points_earned: bool = True
    include_leaderboard_position: bool = True
    custom_intro_fr: Optional[str] = None
    custom_intro_en: Optional[str] = None

@api_router.get("/admin/weekly-email-settings")
async def get_weekly_email_settings(admin: User = Depends(verify_admin)):
    """Get weekly email settings"""
    settings = await db.settings.find_one({"type": "weekly_emails"}, {"_id": 0})
    return settings or {
        "type": "weekly_emails",
        "enabled": True,
        "send_day": "monday",
        "include_running_stats": True,
        "include_workout_stats": True,
        "include_points_earned": True,
        "include_leaderboard_position": True,
        "custom_intro_fr": None,
        "custom_intro_en": None
    }

@api_router.put("/admin/weekly-email-settings")
async def update_weekly_email_settings(settings: WeeklyEmailSettings, admin: User = Depends(verify_admin)):
    """Update weekly email settings"""
    await db.settings.update_one(
        {"type": "weekly_emails"},
        {"$set": {"type": "weekly_emails", **settings.dict()}},
        upsert=True
    )
    return {"message": "Settings updated"}

@api_router.get("/user/weekly-stats")
async def get_user_weekly_stats(current_user: User = Depends(get_current_user)):
    """Get user's weekly statistics for motivation"""
    week_ago = datetime.now(timezone.utc) - timedelta(days=7)
    week_ago_str = week_ago.isoformat()
    
    # Running stats for the week
    running_sessions = await db.running_sessions.find({
        "user_id": current_user.user_id,
        "start_time": {"$gte": week_ago_str}
    }, {"_id": 0}).to_list(100)
    
    total_distance = sum(s.get("distance", 0) for s in running_sessions)
    total_running_time = sum(s.get("duration", 0) for s in running_sessions)
    total_calories = sum(s.get("calories", 0) for s in running_sessions)
    
    # Workout stats for the week
    workout_history = await db.workout_history.find({
        "user_id": current_user.user_id,
        "completed_at": {"$gte": week_ago_str}
    }, {"_id": 0}).to_list(100)
    
    completed_workouts = len([w for w in workout_history if w.get("completed")])
    total_workout_time = sum(w.get("duration_seconds", 0) for w in workout_history)
    
    # Points earned this week
    point_transactions = await db.point_transactions.find({
        "user_id": current_user.user_id,
        "created_at": {"$gte": week_ago_str},
        "type": "earned"
    }, {"_id": 0}).to_list(100)
    
    points_earned = sum(t.get("points", 0) for t in point_transactions)
    
    # Leaderboard position
    leaderboard = await db.running_sessions.aggregate([
        {"$group": {
            "_id": "$user_id",
            "total_distance": {"$sum": "$distance"}
        }},
        {"$sort": {"total_distance": -1}}
    ]).to_list(1000)
    
    position = 0
    for i, entry in enumerate(leaderboard):
        if entry["_id"] == current_user.user_id:
            position = i + 1
            break
    
    return {
        "period": "weekly",
        "running": {
            "sessions": len(running_sessions),
            "total_distance_km": round(total_distance, 2),
            "total_time_minutes": round(total_running_time / 60, 1),
            "calories_burned": total_calories
        },
        "workouts": {
            "completed": completed_workouts,
            "total_time_minutes": round(total_workout_time / 60, 1)
        },
        "points": {
            "earned_this_week": points_earned
        },
        "leaderboard": {
            "position": position,
            "total_participants": len(leaderboard)
        }
    }

@api_router.post("/admin/send-weekly-emails")
async def admin_send_weekly_emails(admin: User = Depends(verify_admin)):
    """Admin: Manually trigger weekly motivation emails to all active subscribers"""
    # Get all active subscribers
    active_users = await db.users.find(
        {"subscription_status": "active"},
        {"_id": 0, "password_hash": 0}
    ).to_list(1000)
    
    settings = await db.settings.find_one({"type": "weekly_emails"}, {"_id": 0}) or {}
    
    results = {"sent": 0, "failed": 0, "emails": []}
    week_ago = datetime.now(timezone.utc) - timedelta(days=7)
    week_ago_str = week_ago.isoformat()
    
    for user in active_users:
        try:
            user_id = user["user_id"]
            email = user.get("email")
            name = user.get("name", "Champion")
            
            if not email:
                continue
            
            # Get user's weekly stats
            running_sessions = await db.running_sessions.find({
                "user_id": user_id,
                "start_time": {"$gte": week_ago_str}
            }, {"_id": 0}).to_list(100)
            
            total_distance = sum(s.get("distance", 0) for s in running_sessions)
            total_running_time = sum(s.get("duration", 0) for s in running_sessions)
            
            workout_history = await db.workout_history.find({
                "user_id": user_id,
                "completed_at": {"$gte": week_ago_str}
            }, {"_id": 0}).to_list(100)
            completed_workouts = len([w for w in workout_history if w.get("completed")])
            
            point_transactions = await db.point_transactions.find({
                "user_id": user_id,
                "created_at": {"$gte": week_ago_str},
                "type": "earned"
            }, {"_id": 0}).to_list(100)
            points_earned = sum(t.get("points", 0) for t in point_transactions)
            
            # Build motivational message
            is_french = True  # Could be based on user preference
            
            achievements = []
            if total_distance > 0:
                achievements.append(f"🏃 {total_distance:.1f} km parcourus" if is_french else f"🏃 {total_distance:.1f} km run")
            if completed_workouts > 0:
                achievements.append(f"💪 {completed_workouts} séances complétées" if is_french else f"💪 {completed_workouts} workouts completed")
            if points_earned > 0:
                achievements.append(f"⭐ {points_earned} points gagnés" if is_french else f"⭐ {points_earned} points earned")
            
            # Custom intro or default
            intro = settings.get("custom_intro_fr") if is_french else settings.get("custom_intro_en")
            if not intro:
                intro = f"Voici votre résumé hebdomadaire FitMaxPro !" if is_french else "Here's your weekly FitMaxPro summary!"
            
            # Determine motivation message based on activity
            if total_distance >= 10 or completed_workouts >= 5:
                motivation = "🔥 INCROYABLE ! Vous êtes sur une lancée exceptionnelle !" if is_french else "🔥 AMAZING! You're on an incredible streak!"
            elif total_distance > 0 or completed_workouts > 0:
                motivation = "👏 Bien joué ! Continuez sur cette voie !" if is_french else "👏 Well done! Keep it up!"
            else:
                motivation = "💪 Cette semaine est une nouvelle opportunité de briller !" if is_french else "💪 This week is a new opportunity to shine!"
            
            subject = f"🎯 {name}, votre semaine FitMaxPro !" if is_french else f"🎯 {name}, your FitMaxPro week!"
            
            html_content = f"""
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #0a0a0a; color: white; padding: 40px;">
                <h1 style="color: #EF4444; text-align: center; margin-bottom: 10px;">FITMAXPRO</h1>
                <p style="text-align: center; color: #888; margin-bottom: 30px;">{"Résumé Hebdomadaire" if is_french else "Weekly Summary"}</p>
                
                <h2 style="text-align: center; margin-bottom: 20px;">{"Salut" if is_french else "Hey"} {name} ! 👋</h2>
                
                <p style="font-size: 16px; text-align: center; margin-bottom: 30px;">{intro}</p>
                
                <div style="background: #1a1a1a; border-radius: 12px; padding: 20px; margin-bottom: 20px;">
                    <h3 style="color: #EF4444; margin-bottom: 15px;">{"Vos accomplissements" if is_french else "Your achievements"}</h3>
                    {"".join(f'<p style="margin: 10px 0; font-size: 18px;">{a}</p>' for a in achievements) if achievements else f'<p style="color: #888;">{"Pas encore d activité cette semaine - commencez dès maintenant !" if is_french else "No activity yet this week - start now!"}</p>'}
                </div>
                
                <p style="font-size: 20px; text-align: center; margin: 30px 0; color: #EF4444; font-weight: bold;">
                    {motivation}
                </p>
                
                <div style="text-align: center; margin-top: 30px;">
                    <a href="{APP_URL}/dashboard" style="background: #EF4444; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">
                        {"Continuer l'entraînement" if is_french else "Continue Training"}
                    </a>
                </div>
                
                <p style="text-align: center; margin-top: 40px; color: #888; font-size: 12px;">
                    {"À la semaine prochaine, Champion !" if is_french else "See you next week, Champion!"}
                    <br>{"L'équipe FitMaxPro" if is_french else "The FitMaxPro Team"}
                </p>
            </div>
            """
            
            # Try to send via Resend
            resend_api_key = os.environ.get('RESEND_API_KEY')
            if resend_api_key:
                try:
                    resend.api_key = resend_api_key
                    resend.Emails.send({
                        "from": "FitMaxPro <noreply@fitmax-gains.com>",
                        "to": email,
                        "subject": subject,
                        "html": html_content
                    })
                    results["sent"] += 1
                    results["emails"].append(email)
                except Exception as e:
                    print(f"Email send error: {e}")
                    results["failed"] += 1
            else:
                # Store for manual sending
                await db.pending_emails.insert_one({
                    "email_id": str(uuid.uuid4()),
                    "to": email,
                    "user_name": name,
                    "type": "weekly_motivation",
                    "subject": subject,
                    "html_content": html_content,
                    "created_at": datetime.now(timezone.utc).isoformat(),
                    "status": "pending"
                })
                results["sent"] += 1
                results["emails"].append(email)
                
        except Exception as e:
            print(f"Error processing user {user.get('email')}: {e}")
            results["failed"] += 1
    
    # Log the batch send
    await db.email_batches.insert_one({
        "batch_id": str(uuid.uuid4()),
        "type": "weekly_motivation",
        "sent_at": datetime.now(timezone.utc).isoformat(),
        "sent_by": admin.user_id,
        "results": results
    })
    
    return results

@api_router.get("/admin/email-history")
async def get_email_history(admin: User = Depends(verify_admin)):
    """Get history of sent email batches"""
    batches = await db.email_batches.find(
        {},
        {"_id": 0}
    ).sort("sent_at", -1).to_list(50)
    
    pending = await db.pending_emails.find(
        {"status": "pending"},
        {"_id": 0}
    ).sort("created_at", -1).to_list(100)
    
    return {
        "batches": batches,
        "pending_count": len(pending)
    }


# ==================== SOCIAL MEDIA LINKS ====================

class SocialLinkUpdate(BaseModel):
    platform: str
    url: str

@api_router.get("/social-links")
async def get_social_links():
    """Get social media links"""
    links = await db.settings.find_one({"type": "social_links"}, {"_id": 0})
    return links or {"type": "social_links", "links": {}}

@api_router.put("/admin/social-links")
async def admin_update_social_links(links: dict, admin: User = Depends(verify_admin)):
    """Admin: Update all social media links at once"""
    await db.settings.update_one(
        {"type": "social_links"},
        {"$set": {"type": "social_links", "links": links}},
        upsert=True
    )
    return {"message": "Social links updated"}

@api_router.put("/admin/social-link")
async def admin_update_single_social_link(data: SocialLinkUpdate, admin: User = Depends(verify_admin)):
    """Admin: Update a single social media link individually"""
    # Get current links
    current = await db.settings.find_one({"type": "social_links"})
    links = current.get("links", {}) if current else {}
    
    # Update or remove the specific platform
    if data.url.strip():
        links[data.platform] = data.url.strip()
    else:
        links.pop(data.platform, None)  # Remove if empty
    
    await db.settings.update_one(
        {"type": "social_links"},
        {"$set": {"type": "social_links", "links": links}},
        upsert=True
    )
    return {"message": f"{data.platform} updated", "platform": data.platform, "url": data.url}

@api_router.delete("/admin/social-link/{platform}")
async def admin_delete_social_link(platform: str, admin: User = Depends(verify_admin)):
    """Admin: Delete a single social media link"""
    current = await db.settings.find_one({"type": "social_links"})
    links = current.get("links", {}) if current else {}
    
    if platform in links:
        del links[platform]
        await db.settings.update_one(
            {"type": "social_links"},
            {"$set": {"links": links}}
        )
        return {"message": f"{platform} deleted", "platform": platform}
    
    return {"message": f"{platform} not found", "platform": platform}


# ==================== PROGRESS PHOTOS (BEFORE/AFTER) ====================

class ProgressPhotoCreate(BaseModel):
    photo_type: str  # "before" or "after"
    photo_url: str
    weight_kg: Optional[float] = None
    notes: Optional[str] = None

@api_router.post("/progress-photos")
async def create_progress_photo(photo: ProgressPhotoCreate, current_user: User = Depends(get_current_user)):
    """Upload a progress photo"""
    photo_data = {
        "photo_id": str(uuid.uuid4()),
        "user_id": current_user.user_id,
        "user_name": current_user.name,
        "photo_type": photo.photo_type,
        "photo_url": photo.photo_url,
        "weight_kg": photo.weight_kg,
        "notes": photo.notes,
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.progress_photos.insert_one(photo_data)
    return {"message": "Photo saved", "photo_id": photo_data["photo_id"]}

@api_router.get("/progress-photos")
async def get_user_progress_photos(current_user: User = Depends(get_current_user)):
    """Get current user's progress photos"""
    photos = await db.progress_photos.find(
        {"user_id": current_user.user_id},
        {"_id": 0}
    ).sort("created_at", -1).to_list(50)
    return {"photos": photos}

@api_router.delete("/progress-photos/{photo_id}")
async def delete_progress_photo(photo_id: str, current_user: User = Depends(get_current_user)):
    """Delete a progress photo"""
    await db.progress_photos.delete_one({
        "photo_id": photo_id,
        "user_id": current_user.user_id
    })
    return {"message": "Photo deleted"}

@api_router.get("/admin/progress-photos")
async def admin_get_all_progress_photos(admin: User = Depends(verify_admin)):
    """Admin: Get all users' progress photos"""
    photos = await db.progress_photos.find({}, {"_id": 0}).sort("created_at", -1).to_list(200)
    
    # Group by user
    users_photos = {}
    for photo in photos:
        user_id = photo.get("user_id")
        if user_id not in users_photos:
            users_photos[user_id] = {
                "user_id": user_id,
                "user_name": photo.get("user_name", "Unknown"),
                "before_photos": [],
                "after_photos": []
            }
        if photo.get("photo_type") == "before":
            users_photos[user_id]["before_photos"].append(photo)
        else:
            users_photos[user_id]["after_photos"].append(photo)
    
    return {"users": list(users_photos.values())}

@api_router.get("/admin/user/{user_id}/progress-photos")
async def admin_get_user_progress_photos(user_id: str, admin: User = Depends(verify_admin)):
    """Admin: Get specific user's progress photos"""
    photos = await db.progress_photos.find(
        {"user_id": user_id},
        {"_id": 0}
    ).sort("created_at", 1).to_list(50)
    
    user = await db.users.find_one({"user_id": user_id}, {"_id": 0, "name": 1, "email": 1})
    
    before_photos = [p for p in photos if p.get("photo_type") == "before"]
    after_photos = [p for p in photos if p.get("photo_type") == "after"]
    
    return {
        "user": user,
        "before_photos": before_photos,
        "after_photos": after_photos
    }


logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

# ==================== LIVE STREAMING ENDPOINTS ====================

class LiveCreate(BaseModel):
    title: str
    description: str = ""
    vip_only: bool = False
    scheduled_at: str = None  # ISO datetime for scheduled lives
    category: str = "general"  # workout, yoga, nutrition, motivation, qa

class LiveChat(BaseModel):
    message: str

class LiveSettings(BaseModel):
    max_viewers: int = 1000
    chat_enabled: bool = True
    reactions_enabled: bool = True
    quality: str = "720p"  # 480p, 720p, 1080p

# Live streaming configuration
LIVE_SETTINGS = {
    "max_duration_hours": 4,
    "max_viewers_free": 100,
    "max_viewers_premium": 1000,
    "chat_rate_limit": 5,  # messages per minute
    "recording_enabled": True,
    "qualities": ["480p", "720p", "1080p"]
}

@api_router.get("/lives")
async def get_active_lives(current_user: User = Depends(get_current_user)):
    """Get all active and upcoming live sessions"""
    now = datetime.now(timezone.utc).isoformat()
    
    # Get active lives
    active_lives = await db.lives.find({"status": "active"}).to_list(100)
    
    # Get upcoming scheduled lives (next 24 hours)
    tomorrow = (datetime.now(timezone.utc) + timedelta(hours=24)).isoformat()
    scheduled_lives = await db.lives.find({
        "status": "scheduled",
        "scheduled_at": {"$gte": now, "$lte": tomorrow}
    }).sort("scheduled_at", 1).to_list(20)
    
    all_lives = active_lives + scheduled_lives
    
    for live in all_lives:
        live['live_id'] = str(live.get('live_id', live.get('_id')))
        live.pop('_id', None)
        
        # Add LiveKit info if available
        if LIVEKIT_AVAILABLE and live.get('status') == 'active':
            live['streaming_ready'] = True
            live['livekit_room'] = live.get('livekit_room_name')
        else:
            live['streaming_ready'] = False
    
    return {
        "active": [l for l in all_lives if l.get('status') == 'active'],
        "scheduled": [l for l in all_lives if l.get('status') == 'scheduled'],
        "total_active": len(active_lives)
    }

@api_router.post("/lives")
async def create_live(live: LiveCreate, current_user: User = Depends(get_current_user)):
    """Create a new live session (admin only)"""
    if current_user.role != 'admin':
        raise HTTPException(status_code=403, detail="Only admin can start lives")
    
    live_id = f"live_{uuid.uuid4().hex[:12]}"
    livekit_room_name = f"fitmaxpro_live_{live_id}"
    
    # Determine if scheduled or immediate
    is_scheduled = live.scheduled_at is not None
    status = "scheduled" if is_scheduled else "active"
    
    live_doc = {
        "live_id": live_id,
        "title": live.title,
        "description": live.description,
        "category": live.category,
        "vip_only": live.vip_only,
        "host_id": current_user.user_id,
        "host_name": current_user.name,
        "status": status,
        "viewer_count": 0,
        "peak_viewers": 0,
        "viewers": [],
        "chat_messages": [],
        "reactions": {"fire": 0, "heart": 0, "muscle": 0, "clap": 0},
        "livekit_room_name": livekit_room_name,
        "settings": {
            "chat_enabled": True,
            "reactions_enabled": True,
            "quality": "720p",
            "max_viewers": LIVE_SETTINGS["max_viewers_premium"]
        },
        "scheduled_at": live.scheduled_at,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "started_at": None if is_scheduled else datetime.now(timezone.utc).isoformat()
    }
    
    await db.lives.insert_one(live_doc)
    live_doc.pop('_id', None)
    
    # Generate host token for LiveKit if available and live is starting now
    host_token = None
    if LIVEKIT_AVAILABLE and not is_scheduled:
        try:
            livekit_url = os.environ.get('LIVEKIT_URL')
            livekit_api_key = os.environ.get('LIVEKIT_API_KEY')
            livekit_api_secret = os.environ.get('LIVEKIT_API_SECRET')
            
            if livekit_url and livekit_api_key and livekit_api_secret:
                token = livekit_api.AccessToken(livekit_api_key, livekit_api_secret)
                token.with_identity(current_user.user_id)
                token.with_name(current_user.name)
                token.with_grants(livekit_api.VideoGrants(
                    room_join=True,
                    room=livekit_room_name,
                    can_publish=True,
                    can_subscribe=True,
                    can_publish_data=True
                ))
                host_token = token.to_jwt()
                live_doc['host_token'] = host_token
                live_doc['livekit_url'] = livekit_url
        except Exception as e:
            print(f"LiveKit token generation error: {e}")
    
    # Send push notifications
    if is_scheduled:
        # Notify about upcoming live
        asyncio.create_task(notify_live_scheduled(live.title, live.scheduled_at, live.vip_only, live_id))
    else:
        # Notify live starting now
        asyncio.create_task(notify_live_started(live.title, live.vip_only, live_id))
    
    return live_doc

async def notify_live_scheduled(title: str, scheduled_at: str, vip_only: bool, live_id: str):
    """Send push notifications when a live is scheduled"""
    try:
        subs = await db.push_subscriptions.find({"enabled": True}).to_list(1000)
        
        # Parse scheduled time
        scheduled_dt = datetime.fromisoformat(scheduled_at.replace('Z', '+00:00'))
        time_str = scheduled_dt.strftime("%H:%M")
        
        for sub in subs:
            user_id = sub.get("user_id")
            
            if vip_only:
                user = await db.users.find_one({"user_id": user_id})
                if user and user.get("subscription_tier") != "vip" and user.get("role") != "admin":
                    continue
            
            await send_push_notification(
                user_id,
                "📅 Live Programmé !",
                f"'{title}' commence à {time_str} - Ne manquez pas !",
                {"url": "/live", "type": "live_scheduled", "live_id": live_id}
            )
    except Exception as e:
        print(f"Error sending scheduled live notifications: {e}")

async def notify_live_started(title: str, vip_only: bool, live_id: str):
    """Send push notifications when a live starts"""
    try:
        subs = await db.push_subscriptions.find({"enabled": True}).to_list(1000)
        
        for sub in subs:
            user_id = sub.get("user_id")
            
            if vip_only:
                user = await db.users.find_one({"user_id": user_id})
                if user:
                    if user.get("subscription_tier") != "vip" and user.get("role") != "admin":
                        continue
            
            user_requests = await db.live_requests.find({
                "user_id": user_id,
                "status": "pending"
            }).to_list(10)
            
            if user_requests:
                body = f"🎉 Le coach est EN DIRECT maintenant ! '{title}' - Votre demande a peut-être été entendue !"
            else:
                body = f"🔴 EN DIRECT maintenant ! '{title}' - Rejoignez la session !"
            
            await send_push_notification(
                user_id,
                "📺 Live en cours !",
                body,
                {"url": "/live", "type": "live_started", "live_id": live_id}
            )
    except Exception as e:
        print(f"Error sending live notifications: {e}")

@api_router.post("/lives/{live_id}/start")
async def start_scheduled_live(live_id: str, current_user: User = Depends(get_current_user)):
    """Start a scheduled live session"""
    if current_user.role != 'admin':
        raise HTTPException(status_code=403, detail="Only admin can start lives")
    
    live = await db.lives.find_one({"live_id": live_id})
    if not live:
        raise HTTPException(status_code=404, detail="Live not found")
    
    if live.get('status') != 'scheduled':
        raise HTTPException(status_code=400, detail="Live is not in scheduled status")
    
    # Update to active
    await db.lives.update_one(
        {"live_id": live_id},
        {"$set": {
            "status": "active",
            "started_at": datetime.now(timezone.utc).isoformat()
        }}
    )
    
    # Generate host token
    host_token = None
    livekit_url = None
    if LIVEKIT_AVAILABLE:
        try:
            livekit_url = os.environ.get('LIVEKIT_URL')
            livekit_api_key = os.environ.get('LIVEKIT_API_KEY')
            livekit_api_secret = os.environ.get('LIVEKIT_API_SECRET')
            
            if livekit_url and livekit_api_key and livekit_api_secret:
                token = livekit_api.AccessToken(livekit_api_key, livekit_api_secret)
                token.with_identity(current_user.user_id)
                token.with_name(current_user.name)
                token.with_grants(livekit_api.VideoGrants(
                    room_join=True,
                    room=live.get('livekit_room_name'),
                    can_publish=True,
                    can_subscribe=True,
                    can_publish_data=True
                ))
                host_token = token.to_jwt()
        except Exception as e:
            print(f"LiveKit error: {e}")
    
    # Send notifications
    asyncio.create_task(notify_live_started(live.get('title'), live.get('vip_only', False), live_id))
    
    return {
        "success": True,
        "live_id": live_id,
        "host_token": host_token,
        "livekit_url": livekit_url,
        "room_name": live.get('livekit_room_name')
    }

@api_router.post("/lives/{live_id}/join")
async def join_live(live_id: str, current_user: User = Depends(get_current_user)):
    """Join a live session as viewer"""
    live = await db.lives.find_one({"live_id": live_id, "status": "active"})
    if not live:
        raise HTTPException(status_code=404, detail="Live session not found or not active")
    
    # Check VIP access
    if live.get('vip_only'):
        if current_user.subscription_tier != 'vip' and current_user.role != 'admin':
            raise HTTPException(status_code=403, detail="This session is VIP only")
    
    # Check max viewers
    settings = live.get('settings', {})
    max_viewers = settings.get('max_viewers', LIVE_SETTINGS['max_viewers_premium'])
    if live.get('viewer_count', 0) >= max_viewers:
        raise HTTPException(status_code=429, detail="Live session is full")
    
    # Update viewer count
    new_count = live.get('viewer_count', 0) + 1
    peak = max(live.get('peak_viewers', 0), new_count)
    
    await db.lives.update_one(
        {"live_id": live_id},
        {
            "$addToSet": {"viewers": current_user.user_id},
            "$set": {"viewer_count": new_count, "peak_viewers": peak}
        }
    )
    
    # Generate viewer token for LiveKit
    viewer_token = None
    livekit_url = None
    
    if LIVEKIT_AVAILABLE:
        try:
            livekit_url = os.environ.get('LIVEKIT_URL')
            livekit_api_key = os.environ.get('LIVEKIT_API_KEY')
            livekit_api_secret = os.environ.get('LIVEKIT_API_SECRET')
            
            if livekit_url and livekit_api_key and livekit_api_secret:
                token = livekit_api.AccessToken(livekit_api_key, livekit_api_secret)
                token.with_identity(current_user.user_id)
                token.with_name(current_user.name)
                token.with_grants(livekit_api.VideoGrants(
                    room_join=True,
                    room=live.get('livekit_room_name'),
                    can_publish=False,  # Viewers can't publish
                    can_subscribe=True,
                    can_publish_data=True  # For chat/reactions
                ))
                viewer_token = token.to_jwt()
        except Exception as e:
            print(f"LiveKit viewer token error: {e}")
    
    return {
        "success": True,
        "viewer_token": viewer_token,
        "livekit_url": livekit_url,
        "room_name": live.get('livekit_room_name'),
        "settings": live.get('settings', {}),
        "viewer_count": new_count
    }

@api_router.post("/lives/{live_id}/leave")
async def leave_live(live_id: str, current_user: User = Depends(get_current_user)):
    """Leave a live session"""
    live = await db.lives.find_one({"live_id": live_id})
    if live and current_user.user_id in live.get('viewers', []):
        new_count = max(0, live.get('viewer_count', 1) - 1)
        await db.lives.update_one(
            {"live_id": live_id},
            {
                "$pull": {"viewers": current_user.user_id},
                "$set": {"viewer_count": new_count}
            }
        )
    return {"success": True}

@api_router.post("/lives/{live_id}/reaction")
async def send_reaction(live_id: str, reaction_type: str, current_user: User = Depends(get_current_user)):
    """Send a reaction to a live (fire, heart, muscle, clap)"""
    valid_reactions = ["fire", "heart", "muscle", "clap"]
    if reaction_type not in valid_reactions:
        raise HTTPException(status_code=400, detail=f"Invalid reaction. Use: {valid_reactions}")
    
    await db.lives.update_one(
        {"live_id": live_id, "status": "active"},
        {"$inc": {f"reactions.{reaction_type}": 1}}
    )
    
    return {"success": True, "reaction": reaction_type}

@api_router.get("/lives/{live_id}/stats")
async def get_live_stats(live_id: str, current_user: User = Depends(get_current_user)):
    """Get real-time stats for a live session"""
    live = await db.lives.find_one({"live_id": live_id}, {"_id": 0})
    if not live:
        raise HTTPException(status_code=404, detail="Live not found")
    
    return {
        "viewer_count": live.get('viewer_count', 0),
        "peak_viewers": live.get('peak_viewers', 0),
        "reactions": live.get('reactions', {}),
        "chat_count": len(live.get('chat_messages', [])),
        "duration_minutes": 0 if not live.get('started_at') else 
            int((datetime.now(timezone.utc) - datetime.fromisoformat(live['started_at'].replace('Z', '+00:00'))).total_seconds() / 60),
        "status": live.get('status')
    }

@api_router.post("/lives/{live_id}/end")
async def end_live(live_id: str, current_user: User = Depends(get_current_user)):
    """End a live session (admin only)"""
    if current_user.role != 'admin':
        raise HTTPException(status_code=403, detail="Only admin can end lives")
    
    live = await db.lives.find_one({"live_id": live_id})
    if not live:
        raise HTTPException(status_code=404, detail="Live not found")
    
    # Calculate duration
    started_at = live.get('started_at')
    duration_minutes = 0
    if started_at:
        started_dt = datetime.fromisoformat(started_at.replace('Z', '+00:00'))
        duration_minutes = int((datetime.now(timezone.utc) - started_dt).total_seconds() / 60)
    
    result = await db.lives.update_one(
        {"live_id": live_id},
        {
            "$set": {
                "status": "ended",
                "ended_at": datetime.now(timezone.utc).isoformat(),
                "duration_minutes": duration_minutes,
                "final_viewer_count": live.get('viewer_count', 0)
            }
        }
    )
    
    # Notify viewers that live ended
    for viewer_id in live.get('viewers', []):
        await send_push_notification(
            viewer_id,
            "📺 Live terminé",
            f"'{live.get('title')}' est terminé. Merci d'avoir regardé !",
            {"type": "live_ended", "live_id": live_id}
        )
    
    return {
        "success": True,
        "duration_minutes": duration_minutes,
        "peak_viewers": live.get('peak_viewers', 0),
        "total_reactions": sum(live.get('reactions', {}).values())
    }

@api_router.post("/lives/{live_id}/chat")
async def send_chat_message(live_id: str, chat: LiveChat, current_user: User = Depends(get_current_user)):
    """Send a chat message in a live session"""
    live = await db.lives.find_one({"live_id": live_id, "status": "active"})
    if not live:
        raise HTTPException(status_code=404, detail="Live not found or ended")
    
    # Check if chat is enabled
    if not live.get('settings', {}).get('chat_enabled', True):
        raise HTTPException(status_code=403, detail="Chat is disabled for this live")
    
    message_doc = {
        "message_id": f"msg_{uuid.uuid4().hex[:8]}",
        "user_id": current_user.user_id,
        "user_name": current_user.name,
        "message": chat.message[:500],  # Limit message length
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "is_host": current_user.user_id == live.get('host_id')
    }
    
    await db.lives.update_one(
        {"live_id": live_id},
        {"$push": {"chat_messages": message_doc}}
    )
    
    return {"success": True, "message": message_doc}

@api_router.get("/lives/{live_id}/chat")
async def get_chat_messages(live_id: str, since: str = None, current_user: User = Depends(get_current_user)):
    """Get chat messages for a live session"""
    live = await db.lives.find_one({"live_id": live_id}, {"chat_messages": 1})
    if not live:
        raise HTTPException(status_code=404, detail="Live not found")
    
    messages = live.get('chat_messages', [])
    
    # Filter messages if 'since' timestamp provided
    if since:
        messages = [m for m in messages if m.get('timestamp', '') > since]
    
    # Return last 100 messages
    return messages[-100:]

@api_router.get("/admin/lives/history")
async def get_live_history(current_user: User = Depends(get_current_user)):
    """Get live session history (admin only)"""
    if current_user.role != 'admin':
        raise HTTPException(status_code=403, detail="Admin access required")
    
    lives = await db.lives.find().sort("created_at", -1).to_list(50)
    for live in lives:
        live['live_id'] = str(live.get('live_id', live.get('_id')))
        live.pop('_id', None)
    
    # Stats summary
    total_lives = len(lives)
    total_viewers = sum(l.get('peak_viewers', 0) for l in lives)
    total_duration = sum(l.get('duration_minutes', 0) for l in lives)
    
    return {
        "lives": lives,
        "stats": {
            "total_lives": total_lives,
            "total_peak_viewers": total_viewers,
            "total_duration_minutes": total_duration,
            "average_viewers": total_viewers // total_lives if total_lives > 0 else 0
        }
    }

@api_router.get("/lives/livekit-status")
async def get_livekit_live_status():
    """Check if LiveKit is configured for live streaming"""
    livekit_url = os.environ.get('LIVEKIT_URL')
    livekit_api_key = os.environ.get('LIVEKIT_API_KEY')
    livekit_api_secret = os.environ.get('LIVEKIT_API_SECRET')
    
    configured = bool(livekit_url and livekit_api_key and livekit_api_secret and LIVEKIT_AVAILABLE)
    
    return {
        "livekit_available": LIVEKIT_AVAILABLE,
        "configured": configured,
        "server_url": livekit_url if configured else None,
        "features": {
            "video_streaming": configured,
            "audio_streaming": configured,
            "screen_sharing": configured,
            "recording": False,  # Requires additional setup
            "chat": True,  # Always available via API
            "reactions": True
        },
        "message": "LiveKit is ready for live streaming" if configured else "Configure LIVEKIT_URL, LIVEKIT_API_KEY, LIVEKIT_API_SECRET in .env to enable real-time streaming"
    }
    return lives

# ==================== LIVEKIT WEBRTC REAL-TIME COMMUNICATION ====================

# LiveKit Configuration
LIVEKIT_URL = os.environ.get('LIVEKIT_URL', '')
LIVEKIT_API_KEY = os.environ.get('LIVEKIT_API_KEY', '')
LIVEKIT_API_SECRET = os.environ.get('LIVEKIT_API_SECRET', '')

class LiveKitTokenRequest(BaseModel):
    room_name: str
    participant_name: Optional[str] = None
    can_publish: bool = True
    can_subscribe: bool = True
    room_type: str = "live"  # "live" for streaming, "call" for 1-to-1

class LiveKitRoomRequest(BaseModel):
    room_name: str
    room_type: str = "live"  # "live" or "call"
    max_participants: Optional[int] = None
    empty_timeout: Optional[int] = 300

@api_router.get("/livekit/status")
async def livekit_status():
    """Check if LiveKit is configured"""
    configured = bool(LIVEKIT_URL and LIVEKIT_API_KEY and LIVEKIT_API_SECRET and LIVEKIT_AVAILABLE)
    return {
        "configured": configured,
        "server_url": LIVEKIT_URL if configured else None,
        "message": "LiveKit WebRTC is ready" if configured else "LiveKit not configured - add LIVEKIT_URL, LIVEKIT_API_KEY, LIVEKIT_API_SECRET to .env"
    }

@api_router.post("/livekit/token")
async def get_livekit_token(request: LiveKitTokenRequest, current_user: User = Depends(get_current_user)):
    """Generate a LiveKit JWT token for room access"""
    if not LIVEKIT_AVAILABLE:
        raise HTTPException(status_code=503, detail="LiveKit not available")
    
    if not all([LIVEKIT_URL, LIVEKIT_API_KEY, LIVEKIT_API_SECRET]):
        raise HTTPException(status_code=503, detail="LiveKit not configured - please add API keys")
    
    try:
        # Create access token
        token = livekit_api.AccessToken(
            api_key=LIVEKIT_API_KEY,
            api_secret=LIVEKIT_API_SECRET,
        )
        
        token.identity = current_user.user_id
        token.name = request.participant_name or current_user.name
        
        # Set video grants
        token.video_grants = livekit_api.VideoGrants(
            room_join=True,
            room=request.room_name,
            can_publish=request.can_publish,
            can_subscribe=request.can_subscribe,
            can_publish_data=True,  # Enable chat
            can_update_own_metadata=True,
        )
        
        jwt_token = token.to_jwt()
        
        # Log the connection
        await db.livekit_sessions.insert_one({
            "session_id": str(uuid.uuid4()),
            "user_id": current_user.user_id,
            "user_name": current_user.name,
            "room_name": request.room_name,
            "room_type": request.room_type,
            "can_publish": request.can_publish,
            "created_at": datetime.now(timezone.utc).isoformat()
        })
        
        return {
            "token": jwt_token,
            "server_url": LIVEKIT_URL,
            "room_name": request.room_name,
            "identity": current_user.user_id
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/livekit/rooms")
async def create_livekit_room(request: LiveKitRoomRequest, current_user: User = Depends(verify_admin)):
    """Create a new LiveKit room (admin only)"""
    if not LIVEKIT_AVAILABLE:
        raise HTTPException(status_code=503, detail="LiveKit not available")
    
    if not all([LIVEKIT_URL, LIVEKIT_API_KEY, LIVEKIT_API_SECRET]):
        raise HTTPException(status_code=503, detail="LiveKit not configured")
    
    try:
        lkapi = livekit_api.LiveKitAPI(LIVEKIT_URL, LIVEKIT_API_KEY, LIVEKIT_API_SECRET)
        
        max_participants = 2 if request.room_type == "call" else (request.max_participants or 100)
        
        room_info = await lkapi.room.create_room(
            livekit_api.CreateRoomRequest(
                name=request.room_name,
                max_participants=max_participants,
                empty_timeout=request.empty_timeout or 300,
            )
        )
        
        await lkapi.aclose()
        
        # Store room in database
        await db.livekit_rooms.update_one(
            {"room_name": request.room_name},
            {"$set": {
                "room_name": request.room_name,
                "room_type": request.room_type,
                "max_participants": max_participants,
                "created_by": current_user.user_id,
                "created_at": datetime.now(timezone.utc).isoformat(),
                "status": "active"
            }},
            upsert=True
        )
        
        return {
            "room_name": room_info.name,
            "max_participants": room_info.max_participants,
            "num_participants": room_info.num_participants,
            "room_type": request.room_type
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/livekit/rooms/{room_name}/participants")
async def list_room_participants(room_name: str, current_user: User = Depends(get_current_user)):
    """List all participants in a room"""
    if not LIVEKIT_AVAILABLE or not all([LIVEKIT_URL, LIVEKIT_API_KEY, LIVEKIT_API_SECRET]):
        return {"participants": [], "message": "LiveKit not configured"}
    
    try:
        lkapi = livekit_api.LiveKitAPI(LIVEKIT_URL, LIVEKIT_API_KEY, LIVEKIT_API_SECRET)
        
        participants = await lkapi.room.list_participants(
            livekit_api.ListParticipantsRequest(room=room_name)
        )
        
        await lkapi.aclose()
        
        return {
            "participants": [
                {
                    "identity": p.identity,
                    "name": p.name,
                    "state": str(p.state),
                    "joined_at": p.joined_at,
                }
                for p in participants.participants
            ]
        }
    except Exception as e:
        return {"participants": [], "error": str(e)}

@api_router.delete("/livekit/rooms/{room_name}")
async def delete_livekit_room(room_name: str, current_user: User = Depends(verify_admin)):
    """Delete a LiveKit room (admin only)"""
    if not LIVEKIT_AVAILABLE or not all([LIVEKIT_URL, LIVEKIT_API_KEY, LIVEKIT_API_SECRET]):
        raise HTTPException(status_code=503, detail="LiveKit not configured")
    
    try:
        lkapi = livekit_api.LiveKitAPI(LIVEKIT_URL, LIVEKIT_API_KEY, LIVEKIT_API_SECRET)
        
        await lkapi.room.delete_room(livekit_api.DeleteRoomRequest(room=room_name))
        
        await lkapi.aclose()
        
        # Update database
        await db.livekit_rooms.update_one(
            {"room_name": room_name},
            {"$set": {"status": "deleted", "deleted_at": datetime.now(timezone.utc).isoformat()}}
        )
        
        return {"success": True, "message": f"Room {room_name} deleted"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/livekit/active-rooms")
async def get_active_livekit_rooms(current_user: User = Depends(get_current_user)):
    """Get all active LiveKit rooms"""
    rooms = await db.livekit_rooms.find(
        {"status": "active"},
        {"_id": 0}
    ).sort("created_at", -1).to_list(50)
    
    return {"rooms": rooms}

# One-to-One Call Management
@api_router.post("/livekit/calls/initiate")
async def initiate_call(callee_id: str, call_type: str = "video", current_user: User = Depends(get_current_user)):
    """Initiate a one-to-one call"""
    call_id = f"call_{uuid.uuid4().hex[:12]}"
    room_name = f"call_{current_user.user_id}_{callee_id}_{call_id[-8:]}"
    
    # Store call request
    call_doc = {
        "call_id": call_id,
        "room_name": room_name,
        "caller_id": current_user.user_id,
        "caller_name": current_user.name,
        "callee_id": callee_id,
        "call_type": call_type,
        "status": "pending",
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.livekit_calls.insert_one(call_doc)
    
    # Get caller token
    if LIVEKIT_AVAILABLE and all([LIVEKIT_URL, LIVEKIT_API_KEY, LIVEKIT_API_SECRET]):
        token = livekit_api.AccessToken(
            api_key=LIVEKIT_API_KEY,
            api_secret=LIVEKIT_API_SECRET,
        )
        token.identity = current_user.user_id
        token.name = current_user.name
        token.video_grants = livekit_api.VideoGrants(
            room_join=True,
            room=room_name,
            can_publish=True,
            can_subscribe=True,
            can_publish_data=True,
        )
        jwt_token = token.to_jwt()
        
        return {
            "call_id": call_id,
            "room_name": room_name,
            "token": jwt_token,
            "server_url": LIVEKIT_URL,
            "status": "pending"
        }
    
    return {
        "call_id": call_id,
        "room_name": room_name,
        "status": "pending",
        "message": "LiveKit not configured - call is mocked"
    }

@api_router.get("/livekit/calls/pending")
async def get_pending_calls(current_user: User = Depends(get_current_user)):
    """Get pending calls for the current user"""
    calls = await db.livekit_calls.find(
        {"callee_id": current_user.user_id, "status": "pending"},
        {"_id": 0}
    ).to_list(10)
    
    return {"calls": calls}

@api_router.post("/livekit/calls/{call_id}/answer")
async def answer_call(call_id: str, accept: bool = True, current_user: User = Depends(get_current_user)):
    """Answer a pending call"""
    call = await db.livekit_calls.find_one({"call_id": call_id, "callee_id": current_user.user_id})
    if not call:
        raise HTTPException(status_code=404, detail="Call not found")
    
    if not accept:
        await db.livekit_calls.update_one(
            {"call_id": call_id},
            {"$set": {"status": "declined", "answered_at": datetime.now(timezone.utc).isoformat()}}
        )
        return {"status": "declined"}
    
    # Accept call - generate token for callee
    await db.livekit_calls.update_one(
        {"call_id": call_id},
        {"$set": {"status": "active", "answered_at": datetime.now(timezone.utc).isoformat()}}
    )
    
    if LIVEKIT_AVAILABLE and all([LIVEKIT_URL, LIVEKIT_API_KEY, LIVEKIT_API_SECRET]):
        token = livekit_api.AccessToken(
            api_key=LIVEKIT_API_KEY,
            api_secret=LIVEKIT_API_SECRET,
        )
        token.identity = current_user.user_id
        token.name = current_user.name
        token.video_grants = livekit_api.VideoGrants(
            room_join=True,
            room=call["room_name"],
            can_publish=True,
            can_subscribe=True,
            can_publish_data=True,
        )
        jwt_token = token.to_jwt()
        
        return {
            "status": "active",
            "room_name": call["room_name"],
            "token": jwt_token,
            "server_url": LIVEKIT_URL,
            "caller_name": call["caller_name"]
        }
    
    return {
        "status": "active",
        "room_name": call["room_name"],
        "message": "LiveKit not configured"
    }

@api_router.post("/livekit/calls/{call_id}/end")
async def end_call(call_id: str, duration: int = 0, current_user: User = Depends(get_current_user)):
    """End an active call"""
    result = await db.livekit_calls.update_one(
        {"call_id": call_id, "$or": [{"caller_id": current_user.user_id}, {"callee_id": current_user.user_id}]},
        {"$set": {
            "status": "ended",
            "ended_at": datetime.now(timezone.utc).isoformat(),
            "duration": duration
        }}
    )
    
    if result.modified_count == 0:
        raise HTTPException(status_code=404, detail="Call not found")
    
    return {"status": "ended", "duration": duration}


# ==================== CALL LOGGING ENDPOINTS ====================

class CallLog(BaseModel):
    call_type: str  # 'audio' or 'video'
    duration: int
    callee_id: str

@api_router.post("/calls/log")
async def log_call(call: CallLog, current_user: User = Depends(get_current_user)):
    """Log a call for analytics"""
    call_doc = {
        "call_id": f"call_{uuid.uuid4().hex[:12]}",
        "caller_id": current_user.user_id,
        "caller_name": current_user.name,
        "callee_id": call.callee_id,
        "call_type": call.call_type,
        "duration": call.duration,
        "status": "completed",
        "created_at": datetime.utcnow().isoformat()
    }
    
    await db.calls.insert_one(call_doc)
    call_doc.pop('_id', None)
    return {"success": True, "call_id": call_doc["call_id"]}

@api_router.get("/admin/calls/history")
async def get_call_history(current_user: User = Depends(get_current_user)):
    """Get call history (admin only)"""
    if current_user.role != 'admin':
        raise HTTPException(status_code=403, detail="Admin access required")
    
    calls = await db.calls.find().sort("created_at", -1).to_list(100)
    for call in calls:
        call['call_id'] = str(call.get('call_id', call.get('_id')))
        call.pop('_id', None)
    return calls


# ==================== RUNNING / COURSE À PIED ====================

class RunningSession(BaseModel):
    distance: float  # en km
    duration: int  # en secondes
    pace: Optional[float] = None  # min/km
    calories: Optional[int] = None
    route_points: Optional[List[Dict]] = None  # [{lat, lng}]
    notes: Optional[str] = None

@api_router.post("/running/log")
async def log_running_session(run: RunningSession, current_user: User = Depends(get_current_user)):
    """Enregistrer une session de course"""
    run_id = f"run_{uuid.uuid4().hex[:12]}"
    
    # Calculer l'allure si non fournie
    pace = run.pace
    if not pace and run.distance > 0:
        pace = (run.duration / 60) / run.distance  # min/km
    
    # Calculer les calories si non fournies (estimation: ~60 cal/km)
    calories = run.calories
    if not calories:
        calories = int(run.distance * 60)
    
    run_doc = {
        "run_id": run_id,
        "user_id": current_user.user_id,
        "user_name": current_user.name,
        "distance": run.distance,
        "duration": run.duration,
        "pace": pace,
        "calories": calories,
        "route_points": run.route_points or [],
        "notes": run.notes,
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.running_sessions.insert_one(run_doc)
    
    # Automatisation des points pour les courses
    points_earned = 0
    points_reasons = []
    
    # Points de base: 10 points par course
    points_earned += 10
    points_reasons.append("course_completed")
    
    # Bonus distance: 5 points par km
    distance_bonus = int(run.distance * 5)
    points_earned += distance_bonus
    if distance_bonus > 0:
        points_reasons.append(f"+{distance_bonus} pts (distance)")
    
    # Bonus grande distance (5+ km)
    if run.distance >= 5:
        points_earned += 25
        points_reasons.append("+25 pts (5km+)")
    
    # Bonus marathon (10+ km)
    if run.distance >= 10:
        points_earned += 50
        points_reasons.append("+50 pts (10km+)")
    
    # Attribuer les points
    await add_points(current_user.user_id, points_earned, "running_session", run_id)
    
    # Trigger notifications in background
    try:
        # Calculate weekly stats for challenge notifications
        today = datetime.now(timezone.utc)
        start_of_week = today - timedelta(days=today.weekday())
        start_of_week = start_of_week.replace(hour=0, minute=0, second=0, microsecond=0)
        
        week_runs = await db.running_sessions.find({
            "user_id": current_user.user_id,
            "created_at": {"$gte": start_of_week.isoformat()}
        }).to_list(100)
        
        weekly_stats = {
            "distance": sum(r.get("distance", 0) for r in week_runs),
            "runs": len(week_runs),
            "calories": sum(r.get("calories", 0) for r in week_runs)
        }
        
        # Check challenge progress notifications
        asyncio.create_task(check_and_notify_challenges(current_user.user_id, weekly_stats))
        
        # Check leaderboard changes
        total_distance = sum(r.get("distance", 0) for r in await db.running_sessions.find({"user_id": current_user.user_id}).to_list(500))
        asyncio.create_task(check_leaderboard_changes(current_user.user_id, current_user.name, total_distance))
    except Exception as e:
        print(f"Notification check error: {e}")
    
    return {
        "success": True,
        "run_id": run_id,
        "distance": run.distance,
        "duration": run.duration,
        "pace": pace,
        "calories": calories,
        "points_earned": points_earned,
        "points_breakdown": points_reasons
    }

@api_router.get("/running/history")
async def get_running_history(current_user: User = Depends(get_current_user)):
    """Récupérer l'historique des courses de l'utilisateur"""
    runs = await db.running_sessions.find(
        {"user_id": current_user.user_id},
        {"_id": 0}
    ).sort("created_at", -1).to_list(100)
    
    return runs

@api_router.get("/running/stats")
async def get_running_stats(current_user: User = Depends(get_current_user)):
    """Récupérer les statistiques de course de l'utilisateur"""
    runs = await db.running_sessions.find(
        {"user_id": current_user.user_id},
        {"_id": 0}
    ).to_list(500)
    
    if not runs:
        return {
            "total_runs": 0,
            "total_distance": 0,
            "total_time": 0,
            "total_calories": 0,
            "avg_pace": None,
            "best_pace": None,
            "best_distance": 0,
            "avg_distance": 0
        }
    
    total_runs = len(runs)
    total_distance = sum(r.get("distance", 0) for r in runs)
    total_time = sum(r.get("duration", 0) for r in runs)
    total_calories = sum(r.get("calories", 0) for r in runs)
    
    # Meilleures performances
    paces = [r.get("pace") for r in runs if r.get("pace") and r.get("pace") > 0]
    best_pace = min(paces) if paces else None
    avg_pace = sum(paces) / len(paces) if paces else None
    
    distances = [r.get("distance", 0) for r in runs]
    best_distance = max(distances) if distances else 0
    avg_distance = sum(distances) / len(distances) if distances else 0
    
    # Stats par semaine (7 derniers jours)
    week_ago = datetime.now(timezone.utc) - timedelta(days=7)
    week_runs = [r for r in runs if datetime.fromisoformat(r.get("created_at", "2000-01-01").replace('Z', '+00:00')) > week_ago]
    weekly_distance = sum(r.get("distance", 0) for r in week_runs)
    weekly_runs = len(week_runs)
    
    return {
        "total_runs": total_runs,
        "total_distance": round(total_distance, 2),
        "total_time": total_time,
        "total_calories": total_calories,
        "avg_pace": round(avg_pace, 2) if avg_pace else None,
        "best_pace": round(best_pace, 2) if best_pace else None,
        "best_distance": round(best_distance, 2),
        "avg_distance": round(avg_distance, 2),
        "weekly_distance": round(weekly_distance, 2),
        "weekly_runs": weekly_runs
    }


# ==================== LEADERBOARD & CHALLENGES ====================

# Définition des défis hebdomadaires
WEEKLY_CHALLENGES = [
    {"id": "distance_5k", "name_fr": "5 km cette semaine", "name_en": "5 km this week", "type": "distance", "target": 5, "badge": "🏃", "points": 50},
    {"id": "distance_10k", "name_fr": "10 km cette semaine", "name_en": "10 km this week", "type": "distance", "target": 10, "badge": "🏅", "points": 100},
    {"id": "distance_20k", "name_fr": "20 km cette semaine", "name_en": "20 km this week", "type": "distance", "target": 20, "badge": "🏆", "points": 200},
    {"id": "runs_3", "name_fr": "3 courses cette semaine", "name_en": "3 runs this week", "type": "runs", "target": 3, "badge": "⭐", "points": 75},
    {"id": "runs_5", "name_fr": "5 courses cette semaine", "name_en": "5 runs this week", "type": "runs", "target": 5, "badge": "🌟", "points": 150},
    {"id": "calories_500", "name_fr": "500 calories brûlées", "name_en": "500 calories burned", "type": "calories", "target": 500, "badge": "🔥", "points": 60},
    {"id": "calories_1000", "name_fr": "1000 calories brûlées", "name_en": "1000 calories burned", "type": "calories", "target": 1000, "badge": "💪", "points": 120},
]

# Badges permanents
ACHIEVEMENT_BADGES = [
    {"id": "first_run", "name_fr": "Première course", "name_en": "First Run", "badge": "🎯", "description_fr": "Complétez votre première course", "description_en": "Complete your first run", "requirement": {"type": "total_runs", "value": 1}},
    {"id": "marathon_total", "name_fr": "Marathon", "name_en": "Marathon", "badge": "🏃‍♂️", "description_fr": "42 km cumulés", "description_en": "42 km total", "requirement": {"type": "total_distance", "value": 42}},
    {"id": "century", "name_fr": "Centenaire", "name_en": "Century", "badge": "💯", "description_fr": "100 km cumulés", "description_en": "100 km total", "requirement": {"type": "total_distance", "value": 100}},
    {"id": "dedicated", "name_fr": "Assidu", "name_en": "Dedicated", "badge": "📅", "description_fr": "10 courses complétées", "description_en": "10 runs completed", "requirement": {"type": "total_runs", "value": 10}},
    {"id": "speed_demon", "name_fr": "Éclair", "name_en": "Speed Demon", "badge": "⚡", "description_fr": "Allure sous 5 min/km", "description_en": "Pace under 5 min/km", "requirement": {"type": "best_pace", "value": 5}},
    {"id": "long_runner", "name_fr": "Endurant", "name_en": "Long Runner", "badge": "🦵", "description_fr": "Course de 10+ km", "description_en": "10+ km run", "requirement": {"type": "single_run_distance", "value": 10}},
    {"id": "calorie_burner", "name_fr": "Brûleur", "name_en": "Calorie Burner", "badge": "🔥", "description_fr": "5000 calories brûlées", "description_en": "5000 calories burned", "requirement": {"type": "total_calories", "value": 5000}},
]

@api_router.get("/running/leaderboard")
async def get_leaderboard(current_user: User = Depends(get_current_user)):
    """Classement public des coureurs"""
    pipeline = [
        {"$group": {
            "_id": "$user_id",
            "user_name": {"$first": "$user_name"},
            "total_distance": {"$sum": "$distance"},
            "total_runs": {"$sum": 1},
            "total_calories": {"$sum": "$calories"},
            "avg_pace": {"$avg": "$pace"},
            "best_pace": {"$min": "$pace"}
        }},
        {"$sort": {"total_distance": -1}},
        {"$limit": 50}
    ]
    
    leaderboard = await db.running_sessions.aggregate(pipeline).to_list(50)
    
    result = []
    for idx, runner in enumerate(leaderboard):
        result.append({
            "rank": idx + 1,
            "user_id": runner["_id"],
            "user_name": runner["user_name"],
            "total_distance": round(runner.get("total_distance", 0), 2),
            "total_runs": runner.get("total_runs", 0),
            "total_calories": runner.get("total_calories", 0),
            "avg_pace": round(runner.get("avg_pace", 0), 2) if runner.get("avg_pace") else None,
            "best_pace": round(runner.get("best_pace", 0), 2) if runner.get("best_pace") else None,
            "is_current_user": runner["_id"] == current_user.user_id
        })
    
    current_user_rank = None
    current_user_in_list = any(r["is_current_user"] for r in result)
    
    if not current_user_in_list:
        user_stats = await db.running_sessions.aggregate([
            {"$match": {"user_id": current_user.user_id}},
            {"$group": {"_id": None, "total_distance": {"$sum": "$distance"}}}
        ]).to_list(1)
        
        if user_stats:
            user_distance = user_stats[0].get("total_distance", 0)
            rank = await db.running_sessions.aggregate([
                {"$group": {"_id": "$user_id", "total_distance": {"$sum": "$distance"}}},
                {"$match": {"total_distance": {"$gt": user_distance}}},
                {"$count": "count"}
            ]).to_list(1)
            current_user_rank = (rank[0]["count"] if rank else 0) + 1
    
    return {
        "leaderboard": result,
        "current_user_rank": current_user_rank,
        "total_runners": await db.running_sessions.aggregate([{"$group": {"_id": "$user_id"}}, {"$count": "count"}]).to_list(1)
    }

@api_router.get("/running/challenges")
async def get_challenges(current_user: User = Depends(get_current_user)):
    """Récupérer les défis hebdomadaires et la progression"""
    today = datetime.now(timezone.utc)
    start_of_week = today - timedelta(days=today.weekday())
    start_of_week = start_of_week.replace(hour=0, minute=0, second=0, microsecond=0)
    
    week_runs = await db.running_sessions.find({
        "user_id": current_user.user_id,
        "created_at": {"$gte": start_of_week.isoformat()}
    }).to_list(100)
    
    weekly_distance = sum(r.get("distance", 0) for r in week_runs)
    weekly_runs = len(week_runs)
    weekly_calories = sum(r.get("calories", 0) for r in week_runs)
    
    challenges_progress = []
    for challenge in WEEKLY_CHALLENGES:
        if challenge["type"] == "distance":
            progress = weekly_distance
        elif challenge["type"] == "runs":
            progress = weekly_runs
        elif challenge["type"] == "calories":
            progress = weekly_calories
        else:
            progress = 0
        
        completed = progress >= challenge["target"]
        percentage = min(100, int((progress / challenge["target"]) * 100))
        
        challenges_progress.append({
            "id": challenge["id"],
            "name_fr": challenge["name_fr"],
            "name_en": challenge["name_en"],
            "badge": challenge["badge"],
            "points": challenge["points"],
            "target": challenge["target"],
            "progress": round(progress, 2),
            "percentage": percentage,
            "completed": completed,
            "type": challenge["type"]
        })
    
    challenges_progress.sort(key=lambda x: (x["completed"], -x["points"]))
    
    return {
        "challenges": challenges_progress,
        "weekly_stats": {
            "distance": round(weekly_distance, 2),
            "runs": weekly_runs,
            "calories": weekly_calories
        },
        "week_start": start_of_week.isoformat(),
        "week_end": (start_of_week + timedelta(days=6, hours=23, minutes=59, seconds=59)).isoformat()
    }

@api_router.get("/running/badges")
async def get_user_badges(current_user: User = Depends(get_current_user)):
    """Récupérer les badges de l'utilisateur"""
    pipeline = [
        {"$match": {"user_id": current_user.user_id}},
        {"$group": {
            "_id": None,
            "total_distance": {"$sum": "$distance"},
            "total_runs": {"$sum": 1},
            "total_calories": {"$sum": "$calories"},
            "best_pace": {"$min": "$pace"},
            "max_single_distance": {"$max": "$distance"}
        }}
    ]
    
    user_stats = await db.running_sessions.aggregate(pipeline).to_list(1)
    stats = user_stats[0] if user_stats else {
        "total_distance": 0,
        "total_runs": 0,
        "total_calories": 0,
        "best_pace": None,
        "max_single_distance": 0
    }
    
    badges = []
    for badge in ACHIEVEMENT_BADGES:
        req = badge["requirement"]
        unlocked = False
        progress = 0
        
        if req["type"] == "total_distance":
            progress = stats.get("total_distance", 0)
            unlocked = progress >= req["value"]
        elif req["type"] == "total_runs":
            progress = stats.get("total_runs", 0)
            unlocked = progress >= req["value"]
        elif req["type"] == "total_calories":
            progress = stats.get("total_calories", 0)
            unlocked = progress >= req["value"]
        elif req["type"] == "best_pace":
            progress = stats.get("best_pace") or 999
            unlocked = progress <= req["value"] and stats.get("total_runs", 0) > 0
        elif req["type"] == "single_run_distance":
            progress = stats.get("max_single_distance", 0)
            unlocked = progress >= req["value"]
        
        badges.append({
            "id": badge["id"],
            "name_fr": badge["name_fr"],
            "name_en": badge["name_en"],
            "badge": badge["badge"],
            "description_fr": badge["description_fr"],
            "description_en": badge["description_en"],
            "unlocked": unlocked,
            "progress": round(progress, 2) if isinstance(progress, float) else progress,
            "target": req["value"]
        })
    
    badges.sort(key=lambda x: (not x["unlocked"], x["id"]))
    unlocked_count = sum(1 for b in badges if b["unlocked"])
    
    return {
        "badges": badges,
        "unlocked_count": unlocked_count,
        "total_badges": len(badges),
        "user_stats": {
            "total_distance": round(stats.get("total_distance", 0), 2),
            "total_runs": stats.get("total_runs", 0),
            "total_calories": stats.get("total_calories", 0),
            "best_pace": round(stats.get("best_pace", 0), 2) if stats.get("best_pace") else None
        }
    }


# Routes with path parameters must come AFTER static routes
@api_router.get("/running/{run_id}")
async def get_running_session(run_id: str, current_user: User = Depends(get_current_user)):
    """Récupérer les détails d'une course spécifique"""
    run = await db.running_sessions.find_one(
        {"run_id": run_id, "user_id": current_user.user_id},
        {"_id": 0}
    )
    
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")
    
    return run

@api_router.delete("/running/{run_id}")
async def delete_running_session(run_id: str, current_user: User = Depends(get_current_user)):
    """Supprimer une course"""
    result = await db.running_sessions.delete_one(
        {"run_id": run_id, "user_id": current_user.user_id}
    )
    
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Run not found")
    
    return {"success": True, "message": "Run deleted"}

# ==================== ADMIN - RUNNING ANALYTICS ====================

@api_router.get("/admin/running/all")
async def admin_get_all_running(admin: User = Depends(verify_admin)):
    """Admin: Récupérer toutes les courses de tous les utilisateurs"""
    runs = await db.running_sessions.find(
        {},
        {"_id": 0}
    ).sort("created_at", -1).to_list(500)
    
    return {"runs": runs, "total": len(runs)}

@api_router.get("/admin/running/stats")
async def admin_get_running_stats(admin: User = Depends(verify_admin)):
    """Admin: Statistiques globales de course"""
    # Stats globales
    total_runs = await db.running_sessions.count_documents({})
    
    pipeline = [
        {"$group": {
            "_id": None,
            "total_distance": {"$sum": "$distance"},
            "total_time": {"$sum": "$duration"},
            "total_calories": {"$sum": "$calories"},
            "avg_distance": {"$avg": "$distance"},
            "avg_duration": {"$avg": "$duration"}
        }}
    ]
    
    global_stats = await db.running_sessions.aggregate(pipeline).to_list(1)
    
    if global_stats:
        stats = global_stats[0]
        stats.pop("_id", None)
        stats["total_runs"] = total_runs
        stats["total_distance"] = round(stats.get("total_distance", 0), 2)
        stats["avg_distance"] = round(stats.get("avg_distance", 0), 2)
    else:
        stats = {
            "total_runs": 0,
            "total_distance": 0,
            "total_time": 0,
            "total_calories": 0,
            "avg_distance": 0,
            "avg_duration": 0
        }
    
    # Top runners
    top_runners_pipeline = [
        {"$group": {
            "_id": "$user_id",
            "user_name": {"$first": "$user_name"},
            "total_distance": {"$sum": "$distance"},
            "total_runs": {"$sum": 1},
            "avg_pace": {"$avg": "$pace"}
        }},
        {"$sort": {"total_distance": -1}},
        {"$limit": 10}
    ]
    
    top_runners = await db.running_sessions.aggregate(top_runners_pipeline).to_list(10)
    
    for runner in top_runners:
        runner["user_id"] = runner.pop("_id")
        runner["total_distance"] = round(runner.get("total_distance", 0), 2)
        if runner.get("avg_pace"):
            runner["avg_pace"] = round(runner["avg_pace"], 2)
    
    return {
        "global_stats": stats,
        "top_runners": top_runners
    }

@api_router.get("/admin/running/user/{user_id}")
async def admin_get_user_running(user_id: str, admin: User = Depends(verify_admin)):
    """Admin: Historique de course d'un utilisateur spécifique"""
    runs = await db.running_sessions.find(
        {"user_id": user_id},
        {"_id": 0}
    ).sort("created_at", -1).to_list(100)
    
    user = await db.users.find_one({"user_id": user_id}, {"_id": 0, "password": 0})
    
    # Stats de l'utilisateur
    total_distance = sum(r.get("distance", 0) for r in runs)
    total_time = sum(r.get("duration", 0) for r in runs)
    total_calories = sum(r.get("calories", 0) for r in runs)
    
    return {
        "user": {
            "user_id": user_id,
            "name": user.get("name") if user else "Unknown",
            "email": user.get("email") if user else ""
        },
        "runs": runs,
        "stats": {
            "total_runs": len(runs),
            "total_distance": round(total_distance, 2),
            "total_time": total_time,
            "total_calories": total_calories
        }
    }


# ==================== PUSH NOTIFICATIONS ====================

class PushSubscription(BaseModel):
    subscription: Dict

@api_router.post("/notifications/subscribe")
async def subscribe_notifications(data: PushSubscription, current_user: User = Depends(get_current_user)):
    """Subscribe user to push notifications"""
    subscription = data.subscription
    
    # Store subscription in database
    await db.push_subscriptions.update_one(
        {"user_id": current_user.user_id},
        {
            "$set": {
                "user_id": current_user.user_id,
                "subscription": subscription,
                "enabled": True,
                "updated_at": datetime.now(timezone.utc).isoformat()
            }
        },
        upsert=True
    )
    
    return {"success": True, "message": "Subscribed to notifications"}

@api_router.post("/notifications/unsubscribe")
async def unsubscribe_notifications(current_user: User = Depends(get_current_user)):
    """Unsubscribe user from push notifications"""
    await db.push_subscriptions.update_one(
        {"user_id": current_user.user_id},
        {"$set": {"enabled": False}}
    )
    
    return {"success": True, "message": "Unsubscribed from notifications"}

@api_router.get("/notifications/status")
async def get_notification_status(current_user: User = Depends(get_current_user)):
    """Get user's notification subscription status"""
    sub = await db.push_subscriptions.find_one(
        {"user_id": current_user.user_id},
        {"_id": 0}
    )
    
    return {
        "subscribed": sub is not None and sub.get("enabled", False),
        "subscription": sub.get("subscription") if sub else None
    }

async def send_push_notification(user_id: str, title: str, body: str, data: dict = None):
    """Send push notification to a specific user"""
    if not WEBPUSH_AVAILABLE:
        print(f"[Notification] Would send to {user_id}: {title} - {body}")
        return False
    
    sub = await db.push_subscriptions.find_one({"user_id": user_id, "enabled": True})
    if not sub:
        return False
    
    try:
        subscription_info = sub.get("subscription")
        payload = json.dumps({
            "title": title,
            "body": body,
            "icon": "/logo192.png",
            "badge": "/logo192.png",
            "data": data or {},
            "tag": f"fitmaxpro-{uuid.uuid4().hex[:8]}"
        })
        
        webpush(
            subscription_info=subscription_info,
            data=payload,
            vapid_private_key=VAPID_PRIVATE_KEY,
            vapid_claims=VAPID_CLAIMS
        )
        
        # Log notification
        await db.notification_logs.insert_one({
            "user_id": user_id,
            "title": title,
            "body": body,
            "sent_at": datetime.now(timezone.utc).isoformat(),
            "success": True
        })
        
        return True
    except WebPushException as e:
        print(f"Push notification failed: {e}")
        if e.response and e.response.status_code in [404, 410]:
            # Subscription expired, remove it
            await db.push_subscriptions.delete_one({"user_id": user_id})
        return False
    except Exception as e:
        print(f"Push notification error: {e}")
        return False

async def check_and_notify_challenges(user_id: str, weekly_stats: dict):
    """Check if user is close to completing challenges and send notifications"""
    challenges = [
        {"name": "5 km", "type": "distance", "target": 5, "threshold": 4},
        {"name": "10 km", "type": "distance", "target": 10, "threshold": 8},
        {"name": "20 km", "type": "distance", "target": 20, "threshold": 18},
        {"name": "3 courses", "type": "runs", "target": 3, "threshold": 2},
        {"name": "5 courses", "type": "runs", "target": 5, "threshold": 4},
        {"name": "500 calories", "type": "calories", "target": 500, "threshold": 400},
        {"name": "1000 calories", "type": "calories", "target": 1000, "threshold": 900},
    ]
    
    for challenge in challenges:
        progress = weekly_stats.get(challenge["type"], 0)
        
        # Check if close to completing (at threshold but not yet complete)
        if challenge["threshold"] <= progress < challenge["target"]:
            remaining = challenge["target"] - progress
            
            # Check if we already sent this notification
            recent_notif = await db.notification_logs.find_one({
                "user_id": user_id,
                "title": {"$regex": challenge["name"]},
                "sent_at": {"$gte": (datetime.now(timezone.utc) - timedelta(hours=24)).isoformat()}
            })
            
            if not recent_notif:
                if challenge["type"] == "distance":
                    body = f"Plus que {remaining:.1f} km pour compléter le défi '{challenge['name']}' ! 🏃"
                elif challenge["type"] == "runs":
                    body = f"Plus qu'1 course pour compléter le défi '{challenge['name']}' ! 💪"
                else:
                    body = f"Plus que {int(remaining)} calories pour le défi '{challenge['name']}' ! 🔥"
                
                await send_push_notification(
                    user_id,
                    f"🎯 Défi presque complété !",
                    body,
                    {"url": "/running", "type": "challenge_progress"}
                )

async def check_leaderboard_changes(user_id: str, user_name: str, new_distance: float):
    """Check if user passed someone in the leaderboard and notify them"""
    # Get users who were just passed
    passed_users = await db.running_sessions.aggregate([
        {"$group": {
            "_id": "$user_id",
            "user_name": {"$first": "$user_name"},
            "total_distance": {"$sum": "$distance"}
        }},
        {"$match": {
            "_id": {"$ne": user_id},
            "total_distance": {"$lt": new_distance, "$gt": new_distance - 10}  # Recently passed
        }}
    ]).to_list(10)
    
    for passed in passed_users:
        passed_id = passed["_id"]
        
        # Check if already notified recently
        recent = await db.notification_logs.find_one({
            "user_id": passed_id,
            "title": {"$regex": "classement"},
            "sent_at": {"$gte": (datetime.now(timezone.utc) - timedelta(hours=6)).isoformat()}
        })
        
        if not recent:
            await send_push_notification(
                passed_id,
                "📊 Changement au classement !",
                f"{user_name} vient de vous dépasser ! Courez pour reprendre votre place ! 🏃",
                {"url": "/running", "type": "leaderboard_change"}
            )

# Test notification endpoint
@api_router.post("/notifications/test")
async def test_notification(current_user: User = Depends(get_current_user)):
    """Send a test notification to the current user"""
    success = await send_push_notification(
        current_user.user_id,
        "🎉 Test de notification FitMaxPro",
        "Les notifications fonctionnent parfaitement ! Continuez à vous dépasser !",
        {"url": "/running", "type": "test"}
    )
    
    return {"success": success, "message": "Test notification sent" if success else "Failed to send"}

# Admin: Send notification to all users
class BroadcastNotification(BaseModel):
    title: str
    body: str
    url: Optional[str] = "/running"

@api_router.post("/admin/notifications/broadcast")
async def broadcast_notification(notif: BroadcastNotification, admin: User = Depends(verify_admin)):
    """Admin: Broadcast notification to all subscribed users"""
    subs = await db.push_subscriptions.find({"enabled": True}).to_list(1000)
    
    sent_count = 0
    for sub in subs:
        success = await send_push_notification(
            sub["user_id"],
            notif.title,
            notif.body,
            {"url": notif.url, "type": "broadcast"}
        )
        if success:
            sent_count += 1
    
    return {
        "success": True,
        "sent": sent_count,
        "total_subscribed": len(subs)
    }


# ==================== REWARDS SYSTEM ====================

# Available rewards
REWARDS_CATALOG = [
    {
        "id": "vip_1_day",
        "name_fr": "Accès VIP 1 jour",
        "name_en": "VIP Access 1 day",
        "description_fr": "Accédez à tous les contenus VIP pendant 24h",
        "description_en": "Access all VIP content for 24h",
        "points_cost": 200,
        "icon": "👑",
        "type": "vip_access",
        "duration_hours": 24
    },
    {
        "id": "vip_7_days",
        "name_fr": "Accès VIP 7 jours",
        "name_en": "VIP Access 7 days",
        "description_fr": "Accédez à tous les contenus VIP pendant 1 semaine",
        "description_en": "Access all VIP content for 1 week",
        "points_cost": 1000,
        "icon": "🏆",
        "type": "vip_access",
        "duration_hours": 168
    },
    {
        "id": "coaching_session",
        "name_fr": "Session coaching gratuite",
        "name_en": "Free coaching session",
        "description_fr": "15 minutes de coaching personnalisé avec le coach",
        "description_en": "15 minutes of personalized coaching",
        "points_cost": 500,
        "icon": "💪",
        "type": "coaching",
        "duration_minutes": 15
    },
    {
        "id": "nutrition_plan",
        "name_fr": "Plan nutrition personnalisé",
        "name_en": "Personalized nutrition plan",
        "description_fr": "Un plan alimentaire adapté à vos objectifs",
        "description_en": "A meal plan tailored to your goals",
        "points_cost": 750,
        "icon": "🥗",
        "type": "nutrition"
    },
    {
        "id": "badge_gold",
        "name_fr": "Badge Or Exclusif",
        "name_en": "Exclusive Gold Badge",
        "description_fr": "Affichez un badge Or à côté de votre nom",
        "description_en": "Display a Gold badge next to your name",
        "points_cost": 300,
        "icon": "🥇",
        "type": "badge"
    },
    {
        "id": "priority_live",
        "name_fr": "Priorité Live",
        "name_en": "Live Priority",
        "description_fr": "Vos questions seront traitées en priorité pendant les lives",
        "description_en": "Your questions will be prioritized during lives",
        "points_cost": 150,
        "icon": "⭐",
        "type": "live_priority",
        "duration_hours": 168
    }
]

@api_router.get("/rewards/catalog")
async def get_rewards_catalog(current_user: User = Depends(get_current_user)):
    """Get available rewards catalog"""
    return {"rewards": REWARDS_CATALOG}

@api_router.get("/rewards/points")
async def get_user_points(current_user: User = Depends(get_current_user)):
    """Get user's current points balance and history"""
    user_data = await db.user_points.find_one({"user_id": current_user.user_id})
    
    if not user_data:
        # Initialize user points
        user_data = {
            "user_id": current_user.user_id,
            "total_points": 0,
            "lifetime_points": 0,
            "created_at": datetime.now(timezone.utc).isoformat()
        }
        await db.user_points.insert_one(user_data)
    
    # Get recent transactions
    transactions = await db.points_transactions.find(
        {"user_id": current_user.user_id},
        {"_id": 0}
    ).sort("created_at", -1).limit(20).to_list(20)
    
    # Get active rewards
    active_rewards = await db.user_rewards.find({
        "user_id": current_user.user_id,
        "expires_at": {"$gt": datetime.now(timezone.utc).isoformat()}
    }, {"_id": 0}).to_list(10)
    
    return {
        "total_points": user_data.get("total_points", 0),
        "lifetime_points": user_data.get("lifetime_points", 0),
        "transactions": transactions,
        "active_rewards": active_rewards
    }

# Badge System Configuration
POINT_BADGES = [
    {"id": "starter", "name_fr": "Débutant", "name_en": "Starter", "threshold": 0, "emoji": "🔘"},
    {"id": "bronze", "name_fr": "Bronze", "name_en": "Bronze", "threshold": 100, "emoji": "🥉"},
    {"id": "silver", "name_fr": "Argent", "name_en": "Silver", "threshold": 500, "emoji": "🥈"},
    {"id": "gold", "name_fr": "Or", "name_en": "Gold", "threshold": 1000, "emoji": "🥇"},
    {"id": "platinum", "name_fr": "Platine", "name_en": "Platinum", "threshold": 2500, "emoji": "💎"},
    {"id": "diamond", "name_fr": "Diamant", "name_en": "Diamond", "threshold": 5000, "emoji": "💠"},
    {"id": "legend", "name_fr": "Légende", "name_en": "Legend", "threshold": 10000, "emoji": "👑"}
]

def get_badge_for_points(points: int) -> dict:
    """Get the badge for a given point amount"""
    current_badge = POINT_BADGES[0]
    for badge in POINT_BADGES:
        if points >= badge["threshold"]:
            current_badge = badge
        else:
            break
    return current_badge

async def add_points(user_id: str, points: int, reason: str, reason_id: str = None):
    """Add points to user's balance and check for badge upgrades"""
    
    # Get current points before update
    user_data = await db.user_points.find_one({"user_id": user_id})
    old_lifetime_points = user_data.get("lifetime_points", 0) if user_data else 0
    old_badge = get_badge_for_points(old_lifetime_points)
    
    # Update or create user points
    result = await db.user_points.update_one(
        {"user_id": user_id},
        {
            "$inc": {"total_points": points, "lifetime_points": max(0, points)},
            "$setOnInsert": {"created_at": datetime.now(timezone.utc).isoformat()}
        },
        upsert=True
    )
    
    # Log transaction
    await db.points_transactions.insert_one({
        "user_id": user_id,
        "points": points,
        "reason": reason,
        "reason_id": reason_id,
        "type": "earned" if points > 0 else "spent",
        "created_at": datetime.now(timezone.utc).isoformat()
    })
    
    # Check for badge upgrade (only for positive points)
    if points > 0:
        new_lifetime_points = old_lifetime_points + points
        new_badge = get_badge_for_points(new_lifetime_points)
        
        if new_badge["id"] != old_badge["id"] and new_badge["threshold"] > old_badge["threshold"]:
            # Badge upgraded! Send notification
            await send_push_notification(
                user_id,
                f"{new_badge['emoji']} Nouveau Badge Débloqué !",
                f"Félicitations ! Vous avez atteint le niveau {new_badge['name_fr']} ! Continuez comme ça ! 💪",
                {"url": "/rewards", "type": "badge_unlocked", "badge_id": new_badge["id"]}
            )
            
            # Log badge unlock
            await db.badge_unlocks.insert_one({
                "user_id": user_id,
                "badge_id": new_badge["id"],
                "badge_name": new_badge["name_fr"],
                "points_at_unlock": new_lifetime_points,
                "unlocked_at": datetime.now(timezone.utc).isoformat()
            })
    
    return True

@api_router.post("/rewards/redeem/{reward_id}")
async def redeem_reward(reward_id: str, current_user: User = Depends(get_current_user)):
    """Redeem a reward using points"""
    # Find reward in catalog
    reward = next((r for r in REWARDS_CATALOG if r["id"] == reward_id), None)
    if not reward:
        raise HTTPException(status_code=404, detail="Reward not found")
    
    # Check user points
    user_data = await db.user_points.find_one({"user_id": current_user.user_id})
    current_points = user_data.get("total_points", 0) if user_data else 0
    
    if current_points < reward["points_cost"]:
        raise HTTPException(status_code=400, detail="Not enough points")
    
    # Deduct points
    await add_points(current_user.user_id, -reward["points_cost"], f"Redeemed: {reward['name_en']}", reward_id)
    
    # Calculate expiration if applicable
    expires_at = None
    if reward.get("duration_hours"):
        expires_at = (datetime.now(timezone.utc) + timedelta(hours=reward["duration_hours"])).isoformat()
    
    # Create user reward
    user_reward = {
        "reward_id": f"ur_{uuid.uuid4().hex[:12]}",
        "user_id": current_user.user_id,
        "catalog_id": reward_id,
        "name": reward["name_en"],
        "type": reward["type"],
        "status": "active",
        "expires_at": expires_at,
        "redeemed_at": datetime.now(timezone.utc).isoformat()
    }
    await db.user_rewards.insert_one(user_reward)
    
    # Send notification
    await send_push_notification(
        current_user.user_id,
        f"🎁 Récompense débloquée !",
        f"Vous avez échangé {reward['points_cost']} points contre : {reward['name_fr']}",
        {"url": "/rewards", "type": "reward_redeemed"}
    )
    
    return {
        "success": True,
        "reward": reward,
        "remaining_points": current_points - reward["points_cost"]
    }

@api_router.get("/rewards/my-rewards")
async def get_my_rewards(current_user: User = Depends(get_current_user)):
    """Get user's redeemed rewards"""
    rewards = await db.user_rewards.find(
        {"user_id": current_user.user_id},
        {"_id": 0}
    ).sort("redeemed_at", -1).to_list(50)
    
    return {"rewards": rewards}

@api_router.get("/rewards/badges")
async def get_user_badges(current_user: User = Depends(get_current_user)):
    """Get user's badge status and unlocked badges"""
    # Get user points
    user_data = await db.user_points.find_one({"user_id": current_user.user_id})
    lifetime_points = user_data.get("lifetime_points", 0) if user_data else 0
    
    current_badge = get_badge_for_points(lifetime_points)
    
    # Get next badge
    next_badge = None
    for badge in POINT_BADGES:
        if lifetime_points < badge["threshold"]:
            next_badge = badge
            break
    
    # Calculate progress to next badge
    progress = 100
    points_to_next = 0
    if next_badge:
        prev_threshold = current_badge["threshold"]
        points_to_next = next_badge["threshold"] - lifetime_points
        progress = ((lifetime_points - prev_threshold) / (next_badge["threshold"] - prev_threshold)) * 100
    
    # Get unlocked badges history
    badge_unlocks = await db.badge_unlocks.find(
        {"user_id": current_user.user_id},
        {"_id": 0}
    ).sort("unlocked_at", -1).to_list(20)
    
    # Build badges list with unlock status
    badges_status = []
    for badge in POINT_BADGES:
        is_unlocked = lifetime_points >= badge["threshold"]
        unlock_info = next((u for u in badge_unlocks if u["badge_id"] == badge["id"]), None)
        badges_status.append({
            **badge,
            "unlocked": is_unlocked,
            "unlocked_at": unlock_info["unlocked_at"] if unlock_info else None
        })
    
    return {
        "lifetime_points": lifetime_points,
        "current_badge": current_badge,
        "next_badge": next_badge,
        "progress_to_next": round(progress, 1),
        "points_to_next": points_to_next,
        "all_badges": badges_status,
        "unlock_history": badge_unlocks
    }

@api_router.get("/rewards/hall-of-fame")
async def get_hall_of_fame(limit: int = 50):
    """Get the Hall of Fame - Top users ranked by badges and points"""
    # Get all users with points
    users_with_points = await db.user_points.find(
        {"lifetime_points": {"$gt": 0}},
        {"_id": 0}
    ).sort("lifetime_points", -1).limit(limit).to_list(limit)
    
    # Enrich with user info and badge data
    hall_of_fame = []
    for i, user_data in enumerate(users_with_points):
        user_id = user_data.get("user_id")
        lifetime_points = user_data.get("lifetime_points", 0)
        
        # Get user info
        user = await db.users.find_one({"user_id": user_id}, {"_id": 0, "password_hash": 0})
        if not user:
            continue
        
        # Get badge info
        current_badge = get_badge_for_points(lifetime_points)
        
        # Get badge unlock count
        badges_unlocked = sum(1 for b in POINT_BADGES if lifetime_points >= b["threshold"])
        
        # Get recent activity
        recent_workout = await db.workout_sessions.find_one(
            {"user_id": user_id, "completed": True},
            {"_id": 0},
            sort=[("ended_at", -1)]
        )
        
        hall_of_fame.append({
            "rank": i + 1,
            "user_id": user_id,
            "name": user.get("name", "Anonymous"),
            "picture": user.get("picture"),
            "lifetime_points": lifetime_points,
            "total_points": user_data.get("total_points", 0),
            "badge": current_badge,
            "badges_unlocked": badges_unlocked,
            "total_badges": len(POINT_BADGES),
            "subscription_tier": user.get("subscription_tier", "none"),
            "last_active": recent_workout.get("ended_at") if recent_workout else None
        })
    
    # Get badge distribution stats
    badge_distribution = {}
    for badge in POINT_BADGES:
        count = await db.user_points.count_documents({
            "lifetime_points": {"$gte": badge["threshold"]}
        })
        badge_distribution[badge["id"]] = count
    
    return {
        "hall_of_fame": hall_of_fame,
        "total_users": len(hall_of_fame),
        "badge_distribution": badge_distribution,
        "badges_info": POINT_BADGES
    }

# ==================== WEEKLY CHALLENGES SYSTEM ====================

WEEKLY_CHALLENGES = [
    {
        "id": "workout_warrior",
        "name_fr": "Guerrier du Workout",
        "name_en": "Workout Warrior",
        "description_fr": "Complétez 5 séances d'entraînement cette semaine",
        "description_en": "Complete 5 workout sessions this week",
        "target": 5,
        "type": "workouts",
        "points_reward": 100,
        "emoji": "💪"
    },
    {
        "id": "daily_dedication",
        "name_fr": "Dévouement Quotidien",
        "name_en": "Daily Dedication",
        "description_fr": "Entraînez-vous 7 jours consécutifs",
        "description_en": "Train for 7 consecutive days",
        "target": 7,
        "type": "streak",
        "points_reward": 150,
        "emoji": "🔥"
    },
    {
        "id": "distance_runner",
        "name_fr": "Coureur de Distance",
        "name_en": "Distance Runner",
        "description_fr": "Courez 20 km au total cette semaine",
        "description_en": "Run 20 km total this week",
        "target": 20,
        "type": "running_distance",
        "points_reward": 120,
        "emoji": "🏃"
    },
    {
        "id": "early_bird",
        "name_fr": "Lève-tôt",
        "name_en": "Early Bird",
        "description_fr": "Complétez 3 séances avant 9h du matin",
        "description_en": "Complete 3 sessions before 9am",
        "target": 3,
        "type": "early_workouts",
        "points_reward": 80,
        "emoji": "🌅"
    },
    {
        "id": "variety_master",
        "name_fr": "Maître de la Variété",
        "name_en": "Variety Master",
        "description_fr": "Essayez 3 types d'entraînement différents",
        "description_en": "Try 3 different workout types",
        "target": 3,
        "type": "workout_types",
        "points_reward": 75,
        "emoji": "🎯"
    },
    {
        "id": "community_star",
        "name_fr": "Star de la Communauté",
        "name_en": "Community Star",
        "description_fr": "Laissez 2 avis sur des programmes",
        "description_en": "Leave 2 reviews on programs",
        "target": 2,
        "type": "reviews",
        "points_reward": 50,
        "emoji": "⭐"
    }
]

def get_week_start_end():
    """Get the start and end of the current week (Monday to Sunday)"""
    today = datetime.now(timezone.utc)
    # Get Monday of current week
    start_of_week = today - timedelta(days=today.weekday())
    start_of_week = start_of_week.replace(hour=0, minute=0, second=0, microsecond=0)
    # Get Sunday end
    end_of_week = start_of_week + timedelta(days=7)
    return start_of_week, end_of_week

@api_router.get("/challenges/weekly")
async def get_weekly_challenges(current_user: User = Depends(get_current_user)):
    """Get current weekly challenges with user progress"""
    week_start, week_end = get_week_start_end()
    week_start_iso = week_start.isoformat()
    week_end_iso = week_end.isoformat()
    
    challenges_with_progress = []
    
    for challenge in WEEKLY_CHALLENGES:
        progress = 0
        
        if challenge["type"] == "workouts":
            # Count completed workouts this week
            progress = await db.workout_sessions.count_documents({
                "user_id": current_user.user_id,
                "completed": True,
                "ended_at": {"$gte": week_start_iso, "$lt": week_end_iso}
            })
        
        elif challenge["type"] == "streak":
            # Calculate current streak
            streak = 0
            check_date = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
            for i in range(7):
                day_start = check_date - timedelta(days=i)
                day_end = day_start + timedelta(days=1)
                has_workout = await db.workout_sessions.count_documents({
                    "user_id": current_user.user_id,
                    "completed": True,
                    "ended_at": {"$gte": day_start.isoformat(), "$lt": day_end.isoformat()}
                })
                if has_workout > 0:
                    streak += 1
                elif i > 0:
                    break
            progress = streak
        
        elif challenge["type"] == "running_distance":
            # Sum running distance this week
            runs = await db.running_sessions.aggregate([
                {"$match": {
                    "user_id": current_user.user_id,
                    "created_at": {"$gte": week_start_iso, "$lt": week_end_iso}
                }},
                {"$group": {"_id": None, "total": {"$sum": "$distance"}}}
            ]).to_list(1)
            progress = round(runs[0]["total"], 1) if runs else 0
        
        elif challenge["type"] == "early_workouts":
            # Count workouts before 9am
            early_sessions = await db.workout_sessions.find({
                "user_id": current_user.user_id,
                "completed": True,
                "started_at": {"$gte": week_start_iso, "$lt": week_end_iso}
            }).to_list(100)
            progress = sum(1 for s in early_sessions 
                         if datetime.fromisoformat(s["started_at"].replace("Z", "+00:00")).hour < 9)
        
        elif challenge["type"] == "workout_types":
            # Count distinct workout types
            types = await db.workout_sessions.distinct("workout_type", {
                "user_id": current_user.user_id,
                "completed": True,
                "ended_at": {"$gte": week_start_iso, "$lt": week_end_iso}
            })
            progress = len(types)
        
        elif challenge["type"] == "reviews":
            # Count reviews this week
            progress = await db.reviews.count_documents({
                "user_id": current_user.user_id,
                "created_at": {"$gte": week_start_iso, "$lt": week_end_iso}
            })
        
        is_completed = progress >= challenge["target"]
        
        # Check if already claimed
        claimed = await db.challenge_completions.find_one({
            "user_id": current_user.user_id,
            "challenge_id": challenge["id"],
            "week_start": week_start_iso
        })
        
        challenges_with_progress.append({
            **challenge,
            "progress": min(progress, challenge["target"]),
            "is_completed": is_completed,
            "is_claimed": claimed is not None,
            "percentage": min(round((progress / challenge["target"]) * 100), 100)
        })
    
    # Sort by completion status (unclaimed completed first, then in-progress, then claimed)
    challenges_with_progress.sort(key=lambda x: (
        x["is_claimed"],  # Claimed last
        not x["is_completed"],  # Completed first
        -x["percentage"]  # Higher percentage first
    ))
    
    return {
        "challenges": challenges_with_progress,
        "week_start": week_start_iso,
        "week_end": week_end_iso,
        "days_remaining": (week_end - datetime.now(timezone.utc)).days
    }

@api_router.post("/challenges/claim/{challenge_id}")
async def claim_challenge_reward(challenge_id: str, current_user: User = Depends(get_current_user)):
    """Claim reward for a completed challenge"""
    # Find challenge
    challenge = next((c for c in WEEKLY_CHALLENGES if c["id"] == challenge_id), None)
    if not challenge:
        raise HTTPException(status_code=404, detail="Challenge not found")
    
    week_start, week_end = get_week_start_end()
    week_start_iso = week_start.isoformat()
    
    # Check if already claimed
    existing = await db.challenge_completions.find_one({
        "user_id": current_user.user_id,
        "challenge_id": challenge_id,
        "week_start": week_start_iso
    })
    if existing:
        raise HTTPException(status_code=400, detail="Challenge already claimed this week")
    
    # Verify completion (simplified check - frontend should verify too)
    # Record completion
    await db.challenge_completions.insert_one({
        "user_id": current_user.user_id,
        "challenge_id": challenge_id,
        "week_start": week_start_iso,
        "points_awarded": challenge["points_reward"],
        "completed_at": datetime.now(timezone.utc).isoformat()
    })
    
    # Award points
    await add_points(
        current_user.user_id, 
        challenge["points_reward"], 
        f"Challenge completed: {challenge['name_en']}", 
        challenge_id
    )
    
    # Send notification
    await send_push_notification(
        current_user.user_id,
        f"{challenge['emoji']} Défi Complété !",
        f"Vous avez gagné {challenge['points_reward']} points pour '{challenge['name_fr']}' !",
        {"url": "/rewards", "type": "challenge_completed"}
    )
    
    return {
        "success": True,
        "points_awarded": challenge["points_reward"],
        "message": f"Congratulations! You earned {challenge['points_reward']} points!"
    }

# Admin: Give points to user
class GivePointsRequest(BaseModel):
    user_id: str
    points: int
    reason: str

@api_router.post("/admin/rewards/give-points")
async def admin_give_points(data: GivePointsRequest, admin: User = Depends(verify_admin)):
    """Admin: Give points to a user"""
    await add_points(data.user_id, data.points, f"Admin gift: {data.reason}")
    
    # Notify user
    await send_push_notification(
        data.user_id,
        "🎉 Bonus de points !",
        f"Vous avez reçu {data.points} points ! Raison: {data.reason}",
        {"url": "/rewards", "type": "points_gift"}
    )
    
    return {"success": True, "message": f"Gave {data.points} points to user"}

@api_router.get("/admin/rewards/stats")
async def admin_rewards_stats(admin: User = Depends(verify_admin)):
    """Admin: Get rewards statistics"""
    total_points_issued = await db.points_transactions.aggregate([
        {"$match": {"points": {"$gt": 0}}},
        {"$group": {"_id": None, "total": {"$sum": "$points"}}}
    ]).to_list(1)
    
    total_points_spent = await db.points_transactions.aggregate([
        {"$match": {"points": {"$lt": 0}}},
        {"$group": {"_id": None, "total": {"$sum": "$points"}}}
    ]).to_list(1)
    
    rewards_redeemed = await db.user_rewards.count_documents({})
    
    top_earners = await db.user_points.find(
        {},
        {"_id": 0, "user_id": 1, "total_points": 1, "lifetime_points": 1}
    ).sort("lifetime_points", -1).limit(10).to_list(10)
    
    # Get user names
    for earner in top_earners:
        user = await db.users.find_one({"user_id": earner["user_id"]}, {"name": 1})
        earner["name"] = user.get("name", "Unknown") if user else "Unknown"
    
    return {
        "total_points_issued": total_points_issued[0]["total"] if total_points_issued else 0,
        "total_points_spent": abs(total_points_spent[0]["total"]) if total_points_spent else 0,
        "rewards_redeemed": rewards_redeemed,
        "top_earners": top_earners
    }


# ==================== LIVE STREAMING IMPROVEMENTS ====================

class LiveRequest(BaseModel):
    title: Optional[str] = None
    message: Optional[str] = None
    category: Optional[str] = None
    exercise_type: Optional[str] = None
    category_label: Optional[str] = None
    exercise_label: Optional[str] = None

@api_router.post("/live/request")
async def request_live_session(data: LiveRequest, current_user: User = Depends(get_current_user)):
    """Subscriber requests a live session from admin"""
    request_id = f"lr_{uuid.uuid4().hex[:12]}"
    
    live_request = {
        "request_id": request_id,
        "user_id": current_user.user_id,
        "user_name": current_user.name,
        "title": data.title or data.category_label or "Demande de Live",
        "message": data.message or "Je souhaiterais une session live avec le coach",
        "category": data.category,
        "category_label": data.category_label,
        "exercise_type": data.exercise_type,
        "exercise_label": data.exercise_label,
        "status": "pending",
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.live_requests.insert_one(live_request)
    
    # Build notification message with category info
    topic = data.category_label or data.title or "Coaching"
    if data.exercise_label:
        topic += f" ({data.exercise_label})"
    
    # Notify admin
    admins = await db.users.find({"role": "admin"}).to_list(10)
    for admin in admins:
        await send_push_notification(
            admin.get("user_id"),
            "📺 Demande de Live !",
            f"{current_user.name} demande : {topic}",
            {"url": "/admin", "type": "live_request"}
        )
    
    return {"success": True, "request_id": request_id}

@api_router.get("/live/requests")
async def get_live_requests(current_user: User = Depends(get_current_user)):
    """Get live session requests (admin sees all, user sees own)"""
    if current_user.role == "admin":
        requests = await db.live_requests.find(
            {},
            {"_id": 0}
        ).sort("created_at", -1).to_list(50)
    else:
        requests = await db.live_requests.find(
            {"user_id": current_user.user_id},
            {"_id": 0}
        ).sort("created_at", -1).to_list(20)
    
    return {"requests": requests}

@api_router.post("/live/requests/{request_id}/respond")
async def respond_to_live_request(
    request_id: str, 
    response: str,  # accepted, declined, scheduled
    scheduled_time: Optional[str] = None,
    admin: User = Depends(verify_admin)
):
    """Admin responds to a live request"""
    request = await db.live_requests.find_one({"request_id": request_id})
    if not request:
        raise HTTPException(status_code=404, detail="Request not found")
    
    await db.live_requests.update_one(
        {"request_id": request_id},
        {"$set": {
            "status": response,
            "scheduled_time": scheduled_time,
            "responded_at": datetime.now(timezone.utc).isoformat(),
            "responded_by": admin.user_id
        }}
    )
    
    # Notify requester
    if response == "accepted":
        message = "Votre demande de live a été acceptée ! Le coach sera bientôt en ligne."
    elif response == "scheduled":
        message = f"Votre live est programmé pour : {scheduled_time}"
    else:
        message = "Votre demande de live n'a pas pu être acceptée pour le moment."
    
    await send_push_notification(
        request["user_id"],
        "📺 Réponse à votre demande de Live",
        message,
        {"url": "/live", "type": "live_response"}
    )
    
    return {"success": True}

@api_router.get("/live/schedule")
async def get_live_schedule(current_user: User = Depends(get_current_user)):
    """Get upcoming scheduled lives"""
    now = datetime.now(timezone.utc).isoformat()
    
    # Get scheduled lives
    scheduled = await db.lives.find({
        "status": "scheduled",
        "scheduled_time": {"$gte": now}
    }, {"_id": 0}).sort("scheduled_time", 1).to_list(10)
    
    # Get active lives
    active = await db.lives.find({
        "status": "active"
    }, {"_id": 0}).to_list(5)
    
    return {
        "active_lives": active,
        "scheduled_lives": scheduled
    }

# Modify create live to support scheduling
class CreateScheduledLive(BaseModel):
    title: str
    description: Optional[str] = None
    is_vip: bool = False
    scheduled_time: Optional[str] = None  # ISO format

@api_router.post("/live/schedule")
async def schedule_live(data: CreateScheduledLive, admin: User = Depends(verify_admin)):
    """Admin: Schedule a live session"""
    live_id = f"live_{uuid.uuid4().hex[:12]}"
    
    live = {
        "live_id": live_id,
        "title": data.title,
        "description": data.description,
        "created_by": admin.user_id,
        "creator_name": admin.name,
        "is_vip": data.is_vip,
        "status": "scheduled" if data.scheduled_time else "active",
        "scheduled_time": data.scheduled_time,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "viewer_count": 0,
        "chat_messages": []
    }
    
    await db.lives.insert_one(live)
    
    # Notify all subscribers if scheduled
    if data.scheduled_time:
        asyncio.create_task(notify_live_scheduled(data.title, data.scheduled_time, data.is_vip, live_id))
    
    return {"success": True, "live_id": live_id, "status": live["status"]}


async def notify_live_scheduled(title: str, scheduled_time: str, is_vip: bool, live_id: str):
    """Send push notifications when a live is scheduled"""
    try:
        # Format the scheduled time nicely
        try:
            dt = datetime.fromisoformat(scheduled_time.replace('Z', '+00:00'))
            formatted_time = dt.strftime("%d/%m à %H:%M")
        except:
            formatted_time = scheduled_time
        
        subs = await db.push_subscriptions.find({"enabled": True}).to_list(1000)
        
        notified_count = 0
        for sub in subs:
            user_id = sub.get("user_id")
            
            # Check VIP restriction
            if is_vip:
                user = await db.users.find_one({"user_id": user_id})
                if user:
                    user_sub = user.get("subscription", {})
                    if user_sub.get("type") != "vip" and user.get("role") != "admin":
                        continue
            
            # Check if user has pending requests (personalize message)
            user_requests = await db.live_requests.find({
                "user_id": user_id,
                "status": "pending"
            }).to_list(10)
            
            if user_requests:
                body = f"🎉 '{title}' prévu le {formatted_time} ! Votre demande a été prise en compte !"
            else:
                body = f"📅 '{title}' prévu le {formatted_time}. Ne le manquez pas !"
            
            success = await send_push_notification(
                user_id,
                "📺 Live programmé !",
                body,
                {"url": "/live", "type": "live_scheduled", "live_id": live_id}
            )
            if success:
                notified_count += 1
        
        print(f"Live scheduled notifications sent to {notified_count} users")
    except Exception as e:
        print(f"Error sending scheduled live notifications: {e}")


# Include router after all endpoints are defined
app.include_router(api_router)

logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()